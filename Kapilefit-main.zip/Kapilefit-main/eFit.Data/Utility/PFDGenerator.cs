﻿using HiQPdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace OHES.eFit.Data.Utility
{
    public static class PFDGenerator
    {
        //6,2 version
        //static string SerialNumber = "76eGvr+L-iaOGjZ2O-nZbZwd/P-3s/dz9/P-3N7B3t3B-1tbW1g==";

        //8.2 version
        static string SerialNumber = "NHxdZWRQ-UnhdVkZV-Rk0MGgQU-BRQGFAQU-BwUaBQYa-DQ0NDQ==";

        public static Byte[] GetPDFFromURL(string url, bool addpageNumber = true, string orientation = "Landscape")
        {

            #region Generate PDF from the URL
            try
            {
                int footerHeight = 50;
                // create the HTML to PDF converter
                HtmlToPdf htmlToPdfConverter = new HtmlToPdf();
                // set HTML Load timeout
                // htmlToPdfConverter.HtmlLoadedTimeout = 10;
                htmlToPdfConverter.TriggerMode = ConversionTriggerMode.WaitTime;
                htmlToPdfConverter.WaitBeforeConvert = 3;
                // set a demo serial number
                htmlToPdfConverter.SerialNumber = SerialNumber;

                if (string.IsNullOrEmpty(orientation) == false)
                {
                    htmlToPdfConverter.Document.PageOrientation = GetPageOrientation(orientation);
                }
                if (addpageNumber)
                {
                    htmlToPdfConverter.Document.Footer.Enabled = true;
                    // set footer height

                    htmlToPdfConverter.Document.Footer.Height = footerHeight;

                    // add page numbering
                    System.Drawing.Font pageNumberingFont = new System.Drawing.Font(new System.Drawing.FontFamily("Arial"),
                                                10, System.Drawing.GraphicsUnit.Point);
                    PdfText pageNumberingText = new PdfText(10, footerHeight - 15, "Page {CrtPage} of {PageCount}  ", pageNumberingFont);
                    pageNumberingText.HorizontalAlign = PdfTextHAlign.Right;
                    pageNumberingText.EmbedSystemFont = true;
                    pageNumberingText.ForeColor = System.Drawing.Color.Black;
                    htmlToPdfConverter.Document.Footer.Layout(pageNumberingText);
                }

                byte[] pdfBuffer = htmlToPdfConverter.ConvertUrlToMemory(url);
                return pdfBuffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            #endregion
        }

        public static Byte[] GetPNGfromUrl(string url, string header, int headerHeight, string footer, int footerHeight, string pagesize, string orientation, bool addpageNumber, bool fitHeight)
        {
            try
            {

                HtmlToImage htmlToImageConverter = new HtmlToImage();
                htmlToImageConverter.SerialNumber = SerialNumber;

                htmlToImageConverter.TriggerMode = ConversionTriggerMode.WaitTime;
                htmlToImageConverter.WaitBeforeConvert = 6;

                byte[] imageBuffer = htmlToImageConverter.ConvertUrlToMemory(url);
                return imageBuffer;
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
                return null;

                
            }


        }

        public static Byte[] GetPDFFromURL(string url, string header, int headerHeight, string footer, int footerHeight, string pagesize, string orientation, bool addpageNumber, bool fitHeight, bool marginNeeded)
        {
            #region Generate PDF from the URL
            try
            {
                // create the HTML to PDF converter
                HtmlToPdf htmlToPdfConverter = new HtmlToPdf();
                if (string.IsNullOrEmpty(pagesize) == false)
                {
                    htmlToPdfConverter.Document.PageSize = GetPageSize(pagesize);
                }
                // set HTML Load timeout
                htmlToPdfConverter.HtmlLoadedTimeout = 20;
                htmlToPdfConverter.TriggerMode = ConversionTriggerMode.WaitTime;
                htmlToPdfConverter.WaitBeforeConvert = 6;
                // set a demo serial number
                htmlToPdfConverter.SerialNumber = SerialNumber;
                htmlToPdfConverter.Document.FitPageHeight = fitHeight;
                //htmlToPdfConverter.Document.FitPageWidth = false;
                // set PDF page size and orientation

                if (string.IsNullOrEmpty(orientation) == false)
                {
                    htmlToPdfConverter.Document.PageOrientation = GetPageOrientation(orientation);
                }

                if (string.IsNullOrEmpty(header) == false)
                {
                    //if (headerHeight != 0)
                    //{
                    // set header height
                    htmlToPdfConverter.Document.Header.Enabled = true;
                    htmlToPdfConverter.Document.Header.Height = headerHeight;

                    // layout HTML in header
                    // PdfHtml headerHtml = new PdfHtml(header, null);
                    PdfHtml headerHtml = new PdfHtml(5, 5, 0, headerHeight, header, null);
                    //  htmlToPdfConverter.Document.FitDestHeight = true;
                    htmlToPdfConverter.Document.FontEmbedding = true;
                    htmlToPdfConverter.Document.Header.Layout(headerHtml);
                    //}
                }

                if (marginNeeded)
                {
                    // htmlToPdfConverter.Document.Margins.Right = 20;
                    //htmlToPdfConverter.Document.Margins.Left = 35;
                    //htmlToPdfConverter.Document.Margins.Right = 5;
                }

                if (string.IsNullOrEmpty(footer) == false)
                {
                    if (footerHeight != 0)
                    {
                        htmlToPdfConverter.Document.Footer.Enabled = true;
                        // set footer height // set footer height
                        htmlToPdfConverter.Document.Footer.Height = footerHeight;
                        // layout HTML in Footer
                        PdfHtml headerHtml = new PdfHtml(5, 5, 0, footerHeight, footer, null);
                        //  htmlToPdfConverter.Document.FitDestHeight = true;
                        htmlToPdfConverter.Document.FontEmbedding = true;
                        htmlToPdfConverter.Document.Footer.Layout(headerHtml);
                    }
                }


                if (addpageNumber)
                {
                    htmlToPdfConverter.Document.Footer.Enabled = true;
                    // set footer height// set footer height
                    if (htmlToPdfConverter.Document.Footer.Height != footerHeight)
                    {
                        htmlToPdfConverter.Document.Footer.Height = footerHeight;
                    }
                    // add page numbering
                    System.Drawing.Font pageNumberingFont = new System.Drawing.Font(new System.Drawing.FontFamily("Arial"),
                                                7, System.Drawing.GraphicsUnit.Point);
                    PdfText pageNumberingText = new PdfText(10, footerHeight - 15, "", pageNumberingFont);
                    pageNumberingText.HorizontalAlign = PdfTextHAlign.Left;
                    pageNumberingText.EmbedSystemFont = true;
                    pageNumberingText.ForeColor = System.Drawing.Color.Black;

                    htmlToPdfConverter.Document.Footer.Layout(pageNumberingText);
                }


                byte[] pdfBuffer = htmlToPdfConverter.ConvertUrlToMemory(url);
                return pdfBuffer;
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
                throw ex;
            }
            #endregion
        }

        public static Byte[] GetPDFFromURLLongWait(string url, string header, int headerHeight, string footer, int footerHeight, string pagesize, string orientation, bool addpageNumber, bool fitHeight, bool marginNeeded)
        {
            #region Generate PDF from the URL
            try
            {
                // create the HTML to PDF converter
                HtmlToPdf htmlToPdfConverter = new HtmlToPdf();
                if (string.IsNullOrEmpty(pagesize) == false)
                {
                    htmlToPdfConverter.Document.PageSize = GetPageSize(pagesize);
                }
                // set HTML Load timeout
                htmlToPdfConverter.HtmlLoadedTimeout = Convert.ToInt32(WebConfigurationManager.AppSettings["HTMLLoadedTimeout"]);//40;
                htmlToPdfConverter.TriggerMode = ConversionTriggerMode.WaitTime;
                htmlToPdfConverter.WaitBeforeConvert = Convert.ToInt32(WebConfigurationManager.AppSettings["PDFConvertTime"]);


                // set a demo serial number
                htmlToPdfConverter.SerialNumber = SerialNumber;
                htmlToPdfConverter.Document.FitPageHeight = fitHeight;
                // set PDF page size and orientation

                if (string.IsNullOrEmpty(orientation) == false)
                {
                    htmlToPdfConverter.Document.PageOrientation = GetPageOrientation(orientation);
                }

                if (htmlToPdfConverter.Document.PageOrientation == PdfPageOrientation.Portrait)
                {
                    htmlToPdfConverter.BrowserWidth = 820;
                }

                if (string.IsNullOrEmpty(header) == false)
                {
                    // set header height
                    htmlToPdfConverter.Document.Footer.Height = headerHeight;

                    // layout HTML in header
                    PdfHtml headerHtml = new PdfHtml(header, null);
                    //  htmlToPdfConverter.Document.FitDestHeight = true;
                    htmlToPdfConverter.Document.FontEmbedding = true;
                    htmlToPdfConverter.Document.Header.Layout(headerHtml);
                }

                if (marginNeeded)
                {
                    // htmlToPdfConverter.Document.Margins.Right = 20;
                    //htmlToPdfConverter.Document.Margins.Left = 35;
                    //htmlToPdfConverter.Document.Margins.Right = 5;
                }

                if (string.IsNullOrEmpty(footer) == false)
                {
                    htmlToPdfConverter.Document.Footer.Enabled = true;
                    // set footer height // set footer height
                    htmlToPdfConverter.Document.Footer.Height = footerHeight;



                    // layout HTML in header
                    PdfHtml headerHtml = new PdfHtml(5, 5, 0, footerHeight, footer, null);
                    //  htmlToPdfConverter.Document.FitDestHeight = true;
                    htmlToPdfConverter.Document.FontEmbedding = true;
                    htmlToPdfConverter.Document.Footer.Layout(headerHtml);
                }


                if (addpageNumber)
                {
                    htmlToPdfConverter.Document.Footer.Enabled = true;
                    // set footer height// set footer height
                    if (htmlToPdfConverter.Document.Footer.Height != footerHeight)
                    {
                        htmlToPdfConverter.Document.Footer.Height = footerHeight;
                    }
                    // add page numbering
                    System.Drawing.Font pageNumberingFont = new System.Drawing.Font(new System.Drawing.FontFamily("Arial"),
                                                7, System.Drawing.GraphicsUnit.Point);
                    PdfText pageNumberingText = new PdfText(10, footerHeight - 15, "Page {CrtPage} of {PageCount}  ", pageNumberingFont);
                    pageNumberingText.HorizontalAlign = PdfTextHAlign.Right;
                    pageNumberingText.EmbedSystemFont = true;
                    pageNumberingText.ForeColor = System.Drawing.Color.Black;

                    htmlToPdfConverter.Document.Footer.Layout(pageNumberingText);
                }


                byte[] pdfBuffer = htmlToPdfConverter.ConvertUrlToMemory(url);
                return pdfBuffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            #endregion
        }




        public static int PdfPageCount(PDFParams pdfParam)
        {
            int pageNo = 0;

            // int footerHeight = 20;

            PdfDocument document = new PdfDocument();
            document.SerialNumber = SerialNumber;

            if (string.IsNullOrEmpty(pdfParam.url) == false)
            {
                PdfHtml pdfhtml = new PdfHtml();

                //pdfhtml.TriggerMode = ConversionTriggerMode.WaitTime;
                //pdfhtml.WaitBeforeConvert = 5;
                pdfhtml.UrlToConvert = pdfParam.url;

                PdfPage page = null;
                if (string.IsNullOrEmpty(pdfParam.pagesize) == false)
                {
                    page = document.AddPage(GetPageSize(pdfParam.pagesize), new PdfDocumentMargins(2));
                }
                else
                {
                    page = document.AddPage(new PdfDocumentMargins(2));
                }
                if (string.IsNullOrEmpty(pdfParam.orientation) == false)
                {
                    page.Orientation = GetPageOrientation(pdfParam.orientation);
                }
                if (pdfParam.fit)
                {
                    pdfhtml.DestHeight = page.Size.Height - 30;
                    pdfhtml.FitDestHeight = true;
                }
                else
                {
                    pdfhtml.FitDestHeight = false;
                }
                page.Layout(pdfhtml);
            }

            pageNo = document.Pages.Count;
            //byte[] pdfBuffer = document.WriteToMemory();

            return pageNo;
        }

        public static Byte[] GetPDF(List<PDFParams> pdfParams, bool addpageNumber)
        {
            int footerHeight = 25;
            // create an empty PDF document
            PdfDocument document = new PdfDocument();
            document.SerialNumber = SerialNumber;


            foreach (PDFParams pdfParam in pdfParams)
            {
                if (string.IsNullOrEmpty(pdfParam.url) == false)
                {
                    PdfHtml pdfhtml = new PdfHtml();

                    pdfhtml.TriggerMode = ConversionTriggerMode.WaitTime;
                    pdfhtml.WaitBeforeConvert = 5;
                    pdfhtml.UrlToConvert = pdfParam.url;

                    PdfPage page = null;
                    if (string.IsNullOrEmpty(pdfParam.pagesize) == false)
                    {
                        page = document.AddPage(GetPageSize(pdfParam.pagesize), new PdfDocumentMargins(2), GetPageOrientation(pdfParam.orientation));
                    }
                    else
                    {
                        page = document.AddPage(new PdfDocumentMargins(2));
                    }


                    if (document.Pages.Count == 1)
                    {
                        if (addpageNumber)
                        {
                            //document.Footer = null;
                            // set footer height
                            document.Footer = document.CreateFooterCanvas(page.DrawableRectangle.Width, footerHeight);
                            //document.Footer.RepeatInBackground = true;


                            // add page numbering
                            System.Drawing.Font pageNumberingFont = new System.Drawing.Font(new System.Drawing.FontFamily("Arial"),
                                                        7, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
                            PdfText pageNumberingText = new PdfText(10, footerHeight - 15, "Page {CrtPage} of {PageCount}  ", pageNumberingFont);
                            pageNumberingText.HorizontalAlign = PdfTextHAlign.Right;
                            pageNumberingText.EmbedSystemFont = true;
                            pageNumberingText.ForeColor = System.Drawing.Color.Black;
                            document.Footer.Layout(pageNumberingText);
                        }
                    }




                    if (pdfParam.fit)
                    {
                        pdfhtml.DestHeight = page.Size.Height - 30;
                        pdfhtml.DestWidth = page.Size.Width;
                        pdfhtml.FitDestHeight = true;

                        pdfhtml.FitDestWidth = true;

                    }
                    else
                    {
                        pdfhtml.FitDestHeight = false;
                    }
                    page.Layout(pdfhtml);
                }
            }

            byte[] pdfBuffer = document.WriteToMemory();
            return pdfBuffer;

        }

        public static string GetPDFSavedPath(List<PDFParams> pdfParams, bool addpageNumber, int RequestID, string HotelName, string period)
        {
            int footerHeight = 25;
            // create an empty PDF document
            PdfDocument document = new PdfDocument();
            document.SerialNumber = SerialNumber;


            foreach (PDFParams pdfParam in pdfParams)
            {
                if (string.IsNullOrEmpty(pdfParam.url) == false)
                {
                    PdfHtml pdfhtml = new PdfHtml();

                    pdfhtml.TriggerMode = ConversionTriggerMode.WaitTime;
                    pdfhtml.WaitBeforeConvert = 5;
                    pdfhtml.UrlToConvert = pdfParam.url;

                    PdfPage page = null;
                    if (string.IsNullOrEmpty(pdfParam.pagesize) == false)
                    {
                        page = document.AddPage(GetPageSize(pdfParam.pagesize), new PdfDocumentMargins(2), GetPageOrientation(pdfParam.orientation));
                    }
                    else
                    {
                        page = document.AddPage(new PdfDocumentMargins(2));
                    }


                    if (document.Pages.Count == 1)
                    {
                        if (addpageNumber)
                        {
                            //document.Footer = null;
                            // set footer height
                            document.Footer = document.CreateFooterCanvas(page.DrawableRectangle.Width, footerHeight);
                            //document.Footer.RepeatInBackground = true;


                            // add page numbering
                            System.Drawing.Font pageNumberingFont = new System.Drawing.Font(new System.Drawing.FontFamily("Arial"),
                                                        7, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
                            PdfText pageNumberingText = new PdfText(10, footerHeight - 15, "Page {CrtPage} of {PageCount}  ", pageNumberingFont);
                            pageNumberingText.HorizontalAlign = PdfTextHAlign.Right;
                            pageNumberingText.EmbedSystemFont = true;
                            pageNumberingText.ForeColor = System.Drawing.Color.Black;
                            document.Footer.Layout(pageNumberingText);
                        }
                    }



                    if (pdfParam.fit)
                    {
                        pdfhtml.DestHeight = page.Size.Height - 30;
                        pdfhtml.DestWidth = page.Size.Width;
                        pdfhtml.FitDestHeight = true;

                        pdfhtml.FitDestWidth = true;

                    }
                    else
                    {
                        pdfhtml.FitDestHeight = false;
                    }
                    page.Layout(pdfhtml);
                }
            }


            string rootPath = System.Configuration.ConfigurationManager.AppSettings["ReportFolder"];



            string createdPath = rootPath + "\\" + RequestID;

            if (System.IO.Directory.Exists(createdPath) == false)
            {
                System.IO.Directory.CreateDirectory(createdPath);
            }

            string filePath = createdPath + "\\PPM_" + HotelName + " - Performance Planning Meeting - " + period + ".pdf";


            document.WriteToFile(filePath);
            return filePath;
        }


        private static PdfPageOrientation GetPageOrientation(string orientation)
        {
            return (orientation.ToLower() == "portrait") ?
                PdfPageOrientation.Portrait : PdfPageOrientation.Landscape;
        }

        private static PdfPageSize GetPageSize(string pagesize)
        {
            switch (pagesize)
            {
                case "A0":
                    return PdfPageSize.A0;
                case "A1":
                    return PdfPageSize.A1;
                case "A10":
                    return PdfPageSize.A10;
                case "A2":
                    return PdfPageSize.A2;
                case "A3":
                    return PdfPageSize.A3;
                case "A4":
                    return PdfPageSize.A4;
                case "A5":
                    return PdfPageSize.A5;
                case "A6":
                    return PdfPageSize.A6;
                case "A7":
                    return PdfPageSize.A7;
                case "A8":
                    return PdfPageSize.A8;
                case "A9":
                    return PdfPageSize.A9;
                case "ArchA":
                    return PdfPageSize.ArchA;
                case "ArchB":
                    return PdfPageSize.ArchB;
                case "ArchC":
                    return PdfPageSize.ArchC;
                case "ArchD":
                    return PdfPageSize.ArchD;
                case "ArchE":
                    return PdfPageSize.ArchE;
                case "B0":
                    return PdfPageSize.B0;
                case "B1":
                    return PdfPageSize.B1;
                case "B2":
                    return PdfPageSize.B2;
                case "B3":
                    return PdfPageSize.B3;
                case "B4":
                    return PdfPageSize.B4;
                case "B5":
                    return PdfPageSize.B5;
                case "Flsa":
                    return PdfPageSize.Flsa;
                case "HalfLetter":
                    return PdfPageSize.HalfLetter;
                case "Ledger":
                    return PdfPageSize.Ledger;
                case "Legal":
                    return PdfPageSize.Legal;
                case "Letter":
                    return PdfPageSize.Letter;
                case "Letter11x17":
                    return PdfPageSize.Letter11x17;
                case "Note":
                    return PdfPageSize.Note;
                default:
                    return PdfPageSize.A4;
            }
        }
    }

    public class PDFParams
    {
        public string url { get; set; }
        public string pagesize { get; set; }
        public string orientation { get; set; }
        public bool fit { get; set; }
        public string footer { get; set; }
        public float footerHeight { get; set; }

    }
}