﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Configuration;

namespace OHES.eFit.Data.Utility
{
   public class Utility
    {
        public static void AppLog(string message)
        {
            try
            {
                string mainPath = "";
                if (System.Web.HttpContext.Current != null)
                {
                    mainPath = System.Web.HttpContext.Current.Server.MapPath("~/Log");
                }

                string path = Path.Combine(mainPath + @"\AppLog_" + DateTime.Now.ToShortDateString().Replace(@"/", "-") + ".txt");
                using (StreamWriter sw = File.Exists(path) ? File.AppendText(path) : File.CreateText(path))
                {
                    sw.WriteLine("Date/Time : " + DateTime.Now);

                    sw.WriteLine("Message : " + message);

                }
            }
            catch (Exception ex)
            {
                //Utility.LogException(ex);
            }

        }
        public static void LogException(Exception e)
        {
            string path = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/Log/") + "Log" + DateTime.Now.ToShortDateString().Replace(@"/", "") + ".txt");

            using (StreamWriter sw = File.Exists(path) ? File.AppendText(path) : File.CreateText(path))
            {
                sw.WriteLine("Date/Time : " + DateTime.Now);
                string errmsg = "";
                errmsg = e.Message;
                Exception le = e.InnerException;
                while (le != null)
                {
                    errmsg = errmsg + '\n' + le.Message;
                    le = le.InnerException;

                }
                sw.WriteLine("Exception : " + errmsg);
                sw.WriteLine("StackTrace : " + e.StackTrace);

            }

        }
    }
}
