﻿using OHES.eFit.Data.Repository;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Linq.Expressions;
using OHES.eFit.Data.DataModel;

namespace OHES.eFit.Data.DataContext
{
    public class eFitContext: DbContext, IDisposedTracker
    {
        public DbSet<User> Users { get; set; }
        public DbSet<User_Deleted> UsersDeleted { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<HitCountT> HitCount { get; set; }
        public DbSet<Distributors> CompaniesList { get; set; }
        public DbSet<TrainingType> TrainingType { get; set; }
        public DbSet<CompanyType> CompanyType { get; set; }

        public DbSet<TrainingAttendance> TrainingAttendance { get; set; }
        public DbSet<TrainingRecord> TrainingRecord { get; set; }

        public DbSet<Attachments> T_Trainers_Attachments { get; set; }
        public DbSet<TempAttachments> T_Trainers_Temp_Pic_Attachments { get; set; }

        public DbSet<TempPrint> T_Temp_PrintData { get; set; }
        public DbSet<QuickLinksDetails> T_QuickLinks { get; set; }

        public eFitContext(): base("eFitContext")   {  }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().ToTable("T_Users");
            modelBuilder.Entity<User_Deleted>().ToTable("T_Users_Deleted");
            modelBuilder.Entity<HitCountT>().ToTable("T_HitCount");
            modelBuilder.Entity<Role>().ToTable("T_UserRoles");
            modelBuilder.Entity<Distributors>().ToTable("T_Company");
            modelBuilder.Entity<TrainingType>().ToTable("T_TrainingType");
            modelBuilder.Entity<CompanyType>().ToTable("T_CompanyType");
            modelBuilder.Entity<TrainingAttendance>().ToTable("T_TrainingAttendanceRoster");
            modelBuilder.Entity<TrainingRecord>().ToTable("T_TrainingRecordForm");
            modelBuilder.Entity<Attachments>().ToTable("T_Trainers_Attachments");
            modelBuilder.Entity<TempAttachments>().ToTable("T_Trainers_Temp_Pic_Attachments");
            modelBuilder.Entity<TempPrint>().ToTable("T_Temp_PrintData");
            modelBuilder.Entity<QuickLinksDetails>().ToTable("T_QuickLinks");
        }

        public bool IsDisposed
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

    }



}

