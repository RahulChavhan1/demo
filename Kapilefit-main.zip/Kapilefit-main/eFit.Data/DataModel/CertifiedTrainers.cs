﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.DataModel
{
    public class ActiveTrainers
    {
        public string TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public string RefNo { get; set; }
        public string TrainerPicField { get; set; }

        public Int64 TotalRecords { get; set; }
    }
    public class DueOfRenewalTrainers
    {
        public string TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public string RefNo { get; set; }
        public Int64 TotalRecords { get; set; }
        public string TraineeType { get; set; }
    }
    public class ExpiredTrainers
    {
        public string TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public string RefNo { get; set; }
        public Int64 TotalRecords { get; set; }
        public string TraineeType { get; set; }
    }
    public class CompaniesLists
    {
        public string CompanyName { get; set; }
        public int CompanyID { get; set; }
        public string traineeType { get; set; }
    }
    public class companyLi
    {
        public ICollection<string> companyName { get; set; }
        public companyLi()
        {
            companyName = new List<string>();
        }

    }
}
