﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.DataModel
{
    public class ActiveTrainees
    {
        public string TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public string RefNo { get; set; }
        public Int64 TotalRecords { get; set; }
        public Int64 TraineesCount { get; set; }
    }
    public class DueOfRenewalTrainees
    {
        public DateTime TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public int IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public int RefNo { get; set; }
        public Int64 TotalRecords { get; set; }
        public string traineeType { get; set; }
    }
    public class ExpiredTrainees
    {
        public DateTime TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public int IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public int RefNo { get; set; }
        public Int64 TotalRecords { get; set; }
        public string traineeType { get; set; }
    }
    public class CompaniesList
    {
        public string CompanyName { get; set; }
        public int CompanyID { get; set; }
        public string traineeType { get; set; }
    }
    public class companyL
    {
        public ICollection<string> companyName { get; set; }
        public companyL()
        {
            companyName = new List<string>();
        }
    }
    public class trainingCompanyL
    {
        public ICollection<string> companyName { get; set; }
        public trainingCompanyL()
        {
            companyName = new List<string>();
        }
    }

    public class refNoList
    {
        public ICollection<Int64> refNo { get; set; }
        public refNoList()
        {
            refNo = new List<Int64>();
        }
    }


    public class printInput
    {
        public List<checkInput> refNo { get; set; }
        public printInput()
        {
            refNo = new List<checkInput>();
        }
    }

    public class InputDetails
    {
        public string Name { get; set; }
        public string TrainerName { get; set; }
        public string TraineeName { get; set; }
        public string NRIC { get; set; }
        public string searchText { get; set; }
        public int pageSize { get; set; }
        public int pageIndex { get; set; }
        public string sortColumn { get; set; }
        public string sortOrder { get; set; }
        public string companyName { get; set; }
        public string disCompanyName { get; set; }
        public string trainingDate { get; set; }
        public int traineeType { get; set; }
        public int trainingTypeID { get; set; }
        public int companyTypeID { get; set; }
        public int companyId { get; set; }
        public int companyPriId { get; set; }
        public string trainerId { get; set; }
        public int adminId { get; set; }
    }
    public class checkInput
    {
        public string RefNo { get; set; }
    }
    public class MarksCard
    {
        public int RollNo { get; set; }
        public string Subject { get; set; }
        public int FullMarks { get; set; }
        public int Obtained { get; set; }
    }

    public class JavascriptModel
    {
        public string Status { get; set; }
        public string msg { get; set; }
    }

    //public class PrintCerificateModal
    //{
    //    public ICollection<Int64> refNo { get; set; }
    //    public PrintCerificateModal()
    //    {
    //        refNo = new List<Int64>();
    //    }
    //}

    public class PrintCerificateModal
    {
        public string name { get; set; }
        public string IDNo { get; set; }
        public string company { get; set; }
    }
}
