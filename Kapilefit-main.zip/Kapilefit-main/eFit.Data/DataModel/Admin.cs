﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.DataModel
{
    public class UploadFormVM
    {
        public TrainingRecordVM trainingRecord { get; set; }
        public CompaniesDetailsVM companiesDetails { get; set; }
        public List<TrainingAttendanceVM> trainingAttendance { get; set; }
        //public ICollection<MemberPubCompanysToDelete> membePpubCompanysToDelete { get; set; }
        public UploadFormVM()
        {
            trainingRecord = new TrainingRecordVM();
            trainingAttendance = new List<TrainingAttendanceVM>();
            companiesDetails = new CompaniesDetailsVM();
            //membePpubCompanysToDelete = new List<MemberPubCompanysToDelete>();
        }
    }

    public class UploadForm
    {
        public TrainingRecord trainingRecord { get; set; }
        public List<TrainingAttendance> trainingAttendance { get; set; }
        public UploadForm()
        {
            trainingRecord = new TrainingRecord();
            trainingAttendance = new List<TrainingAttendance>();
        }
    }

    
    public class TrainingAttendance
    {
        [Key, Column(Order = 0)]        
        public int RefNo { get; set; }
        [Key, Column(Order = 1)]
        public string Name { get; set; }
        public string Designation { get; set; }
        public string Department { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string Outcome { get; set; }
    }
    public class TrainingRecord
    {
        [Key]
        public Int32 RefNo { get; set; }
        public string FileName { get; set; }
        public int CompanyID { get; set; }
        public DateTime TRFDate { get; set; }
        public string TopicsCovered { get; set; }
        public string TrainerName { get; set; }
        public Nullable<Guid> TrainerPicFileId { get; set; }
        public Int32 TrainerCompanyID { get; set; }
        public string Email { get; set; }
        public Int32 TrainingTypeID { get; set; }
        public string modifiedBy { get; set; }
        public DateTime? modifiedDate { get; set; }
        
    }

    public class QuickLinksDetails
    {
        [Key]
        public int SNo { get; set; }
        public string Name { get; set; }
        public string URL { get; set; }
        public String Target { get; set; }    
    }
    public class Attachments
    {
        [Key]
        public Guid fileId { get; set; }
        public Int32 RefNo { get; set; }

        public string TrainerName { get; set; }
        public Int32 TrainerCompanyID { get; set; }


        public string fileName { get; set; }
        public byte[] fileContent { get; set; }
        public string fileType { get; set; }
        public string fileExtension { get; set; }
        public string createdBy { get; set; }
        public DateTime? createdDate { get; set; }
        public Int64 fileSize { get; set; }
    }

    public class TempAttachments
    {
        [Key]
        public Guid fileId { get; set; }
        public Int32 RefNo { get; set; }
        public string fileName { get; set; }
        public byte[] fileContent { get; set; }
        public string fileType { get; set; }
        public string fileExtension { get; set; }
        public string createdBy { get; set; }
        public DateTime? createdDate { get; set; }
        public Int64 fileSize { get; set; }
    }

    public class TempPrint
    {
        [Key]
        public Guid Id { get; set; }
        public string PrintData { get; set; }
    }

    public class TempPrintVM
    {
        public Nullable<Guid> Id { get; set; }
        public string PrintData { get; set; }
    }



    public class TrainingAttendanceVM
    {
        public Int32 RefNo { get; set; }
        public string nameOfTrainee { get; set; }
        public string designation { get; set; }
        public string dept { get; set; }
        public string IDNo { get; set; }
        public string model { get; set; }
        public string outcome { get; set; }
    }
    public class TrainingRecordVM
    {
        public Int32 RefNo { get; set; }
        public string FileName { get; set; }
        public string CompanyName { get; set; }
        public int CompanyId { get; set; }
        public DateTime TRFDate { get; set; }
        public string TRFDateS { get; set; }
        public string TopicsCovered { get; set; }
        public string TrainerName { get; set; }
        public string TrainerCompanyName { get; set; }
        public Int32 TrainerCompanyID { get; set; }
        public string Email { get; set; }
        public int CompanyTypeID { get; set; }
        public int TrainingTypeID { get; set; }
        public Nullable<Guid> TrainerPicFileId { get; set; }
        public Int64 TotalRecords { get; set; }
        public Int64 TotalRecordsExp { get; set; }
    }
    public class CompaniesDetailsVM
    {
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string ContactPerson { get; set; }
        public string ContactDesignation { get; set; }
        public string ContactNumber { get; set; }
    }
    public class ActionStatus
    {
        public string key { get; set; }
        public string message { get; set; }
        public string errorMessage { get; set; }
        public bool success { get; set; }
        public Nullable<Guid> id { get; set; }
    }

    public class CompanyDts
    {
        public string CompanyName { get; set; }
        public string companyName { get; set; }
        public string TrainerName { get; set; }
        public Int32 TrainerCompanyID { get; set; }
        public Int32 RefNo { get; set; }
        public Guid fieldID { get; set; }
        public int tID { get; set; }
        public int disID { get; set; }
    }

    public class QuickLinks
    {        
        public int SNo { get; set; }
        public string Name { get; set; }
        public string URL { get; set; }
        public String Target { get; set; }
        public Int64 TotalRecords { get; set; }
    }

    public class LogoutStatus
    {
        public string Message { get; set; }
    }
   
}
