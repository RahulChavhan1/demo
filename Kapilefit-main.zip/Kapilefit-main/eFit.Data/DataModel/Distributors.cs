﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OHES.eFit.Data.DataModel
{
    public class Distributors
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CompanyID { get; set; }
        public string FileName { get; set; }
        public int CompanyTypeID { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string ContactPerson { get; set; }
        public string ContactDesignation { get; set; }
        public string ContactNumber { get; set; }
        public string Email { get; set; }
        [NotMapped]
        public Int64 TotalRecords { get; set; }
    }
    public class govtCompanies
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Int64 CompanyID { get; set; }
        public Int64 CompanyTypeID { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string ContactPerson { get; set; }
        public string ContactDesignation { get; set; }
        public string ContactNumber { get; set; }
        public string DistributorName { get; set; }
        public Int64 TotalRecords { get; set; }
    }
    public class PrivateCompanies
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Int64 CompanyID { get; set; }
        public Int64 CompanyTypeID { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string ContactPerson { get; set; }
        public string ContactDesignation { get; set; }
        public string ContactNumber { get; set; }
        public string DistributorName { get; set; }
        public Int64 TotalRecords { get; set; }
    }

    public class TrainersListDetails
    {
        public Int64 CompanyID { get; set; }
        public string RefNo { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string ContactPerson { get; set; }
        public string Designation { get; set; }
        public string ContactNo { get; set; }
        public string TrainingDate { get; set; }
        public string TrainerName { get; set; }
        public string TrainerCompany { get; set; }
        public string TrainingType { get; set; }
        public string TopicsCovered { get; set; }
        public string TrainingCompany { get; set; }
        public Int64 TotalRecords { get; set; }
        public string counting { get; set; }
        public bool access { get; set; }
    }


    public class TraineesListDetails
    {
        public Int64 CompanyID { get; set; }
        public string RefNo { get; set; }
        public string CompanyName { get; set; }
        public string CompanyType { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string Cmp_ContactPerson { get; set; }
        public string Cmp_Designation { get; set; }
        public string Cmp_ContactNo { get; set; }
        public string TrainingDate { get; set; }
        public string TrainerName { get; set; }
        public string TrainerCompany { get; set; }
        public string TrainingType { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string Outcome { get; set; }
        public string TopicsCovered { get; set; }
        public string Email { get; set; }
        public Int64 TotalRecords { get; set; }
        public bool access { get; set; }
    }

    public class CompanyType
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        public string Type { get; set; }
    }
}


