﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.DataModel
{
    public class traineeList
    {
        public string TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public string RefNo { get; set; }
        public Int64 TotalRecords { get; set; }
    }
    public class trainerList
    {
        public string TrainingDate { get; set; }
        public string TrainerName { get; set; }
        public string TrainerPicField { get; set; }
        public string TrainerCompanyName { get; set; }
        public string TopicsCovered { get; set; }
        public string Email { get; set; }
        public string CompanyName { get; set; }
        public string TrainingTypeID { get; set; }
        public string TrainingTypeName { get; set; }
        public string RefNo { get; set; }
        
        public Int64 TotalRecords { get; set; }
    }
    public class trainerListPC
    {
        public string TrainingDate { get; set; }
        public string TraineeName { get; set; }
        public string Designation { get; set; }
        public string Dept { get; set; }
        public string IC { get; set; }
        public string Model { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public string TrainerName { get; set; }
        public string TrainerPicField { get; set; }
        public string RefNo { get; set; }
        public Int64 TotalRecords { get; set; }
    }

    public class TraineeList
    {
        public ICollection<string> TraineeName { get; set; }
        public TraineeList()
        {
            TraineeName = new List<string>();
        }
    }
    public class TrainerList
    {
        public bool company { get; set; }
        public ICollection<string> TrainerName { get; set; }
        public TrainerList()
        {
            TrainerName = new List<string>();
        }

    }
}

