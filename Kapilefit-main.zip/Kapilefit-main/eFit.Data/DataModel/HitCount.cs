﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.DataModel
{
   public class HitCounts
    {
        [Key]
       public string PageName { get; set; }
       public Int64 HitCount { get; set; }
    }
}
