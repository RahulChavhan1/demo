﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.DataModel
{
    public class TrainingTypeL
    {
        public string TrainingTypeName { get; set; }
        public int TrainerTypeID { get; set; }
    }

    public class TrainingType
    {
        [Key]
        public int ID { get; set; }
        public string Type { get; set; }
    }
}

