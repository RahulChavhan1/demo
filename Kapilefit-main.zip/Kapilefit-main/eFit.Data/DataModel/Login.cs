﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.DataModel
{
    public class User
    {
        [Key]
        public string UserID { get; set; }
        public string UserName  { get; set; }
        public int CompanyID { get; set; }
        public string EmailID { get; set; }
        public string Password { get; set; }
        public int RoleID { get; set; }
        public int Locked { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string CompanyName { get; set; }
        [NotMapped]
        public bool success { get; set; }
        [NotMapped]
        public string message { get; set; }
        [NotMapped]
        public int companyTypeId { get; set; }
        [NotMapped]
        public string ConfirmPassword { get; set; }
    }

    public class User_Deleted
    {
        [Key]
        public int UserDeletedID { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public int CompanyID { get; set; }
        public string EmailID { get; set; }
        public string Password { get; set; }
        public int RoleID { get; set; }
        public string DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        [NotMapped]
        public bool success { get; set; }
        [NotMapped]
        public string message { get; set; }
        [NotMapped]
        public string ConfirmPassword { get; set; }
    }

    public class UserVM
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public int CompanyID { get; set; }
        public string EmailID { get; set; }
        public string Password { get; set; }
        public string ResetPassword { get; set; }
        public int RoleID { get; set; }
        public int Locked { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string CompanyName { get; set; }
        public Int64 TotalRecords { get; set; }
    }

   

    public class PasswordDetails
    {
        public string UserName { get; set; }
        public string UserID { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public string cNewPassword { get; set; }
       
    }

    public class Role
    {
        [Key]
        public Int32 RoleID { get; set; }
        public string RoleName { get; set; }
    }


    public class HitCountT
    {
        [Key]
        public string PageName { get; set; }
        public Int64 HitCount { get; set; }
    }
    public class Users
    {
        public ICollection<string> UserName { get; set; }
        public Users()
        {
            UserName = new List<string>();
        }
    }
}
