﻿using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Linq.Expressions;

namespace OHES.eFit.Data.Repository
{
    public class RepositoryBase<C> : IDisposable
       where C : DbContext, IDisposedTracker, new()
    {
        private C _DataContext;
        public virtual C DataContext
        {
            get
            {
                if (_DataContext == null || _DataContext.IsDisposed)
                {
                    _DataContext = new C();
                    AllowSerialization = true;
                    //Disable ProxyCreationDisabled to prevent the "In order to serialize the parameter, add the type to the known types collection for the operation using ServiceKnownTypeAttribute" error
                }
                return _DataContext;
            }
        }

        public virtual bool AllowSerialization
        {
            get
            {            
                return _DataContext.Configuration.ProxyCreationEnabled;
            }
            set
            {
                _DataContext.Configuration.ProxyCreationEnabled = !value;
            }
        }
        public virtual T Get<T>(Expression<Func<T, bool>> predicate) where T : class
        {
            if (predicate != null)
            {
                using (DataContext)
                {
                    return DataContext.Set<T>().Where(predicate).SingleOrDefault();
                }
            }
            else
            {
                throw new ApplicationException("Predicate value must be passed to Get<T>.");
            }
        }
        public virtual IQueryable<T> GetList<T>(Expression<Func<T, bool>> predicate) where T : class
        {
            try
            {
                return DataContext.Set<T>().Where(predicate);
            }
            catch (Exception ex)
            {
             Utility.Utility.LogException(ex);
            }
            return null;
        }

        public virtual IQueryable<T> GetList<T, TKey>(Expression<Func<T, bool>> predicate,
            Expression<Func<T, TKey>> orderBy) where T : class
        {
            try
            {
                return GetList(predicate).OrderBy(orderBy);
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return null;
        }
        public virtual IQueryable<T> GetList<T, TKey>(Expression<Func<T, TKey>> orderBy) where T : class
        {
            try
            {
                return GetList<T>().OrderBy(orderBy);
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return null;
        }
        public virtual IQueryable<T> GetList<T>() where T : class
        {
            try
            {
                return DataContext.Set<T>();
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return null;
        }



        public void Dispose()
        {
            if (DataContext != null) DataContext.Dispose();
        }

        public string MonthConvert(string mon)
        {
            string month = string.Empty;

            try
            {
                if (mon == "Jan")
                {
                    month = "01";
                }
                else if (mon == "Feb")
                {
                    month = "02";
                }
                else if (mon == "Mar")
                {
                    month = "03";
                }
                else if (mon == "Apr")
                {
                    month = "04";
                }
                else if (mon == "May")
                {
                    month = "05";
                }
                else if (mon == "Jun")
                {
                    month = "06";
                }
                else if (mon == "Jul")
                {
                    month = "07";
                }
                else if (mon == "Aug")
                {
                    month = "08";
                }
                else if (mon == "Sep")
                {
                    month = "09";
                }
                else if (mon == "Oct")
                {
                    month = "10";
                }
                else if (mon == "Nov")
                {
                    month = "11";
                }
                else if (mon == "Dec")
                {
                    month = "12";
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }

            return month;
        }

        public string ConvertMonth(string mon)
        {
            string month = string.Empty;

            try
            {
                if (mon == "1")
                {
                    month = "Jan";
                }
                else if (mon == "2")
                {
                    month = "Feb";
                }
                else if (mon == "3")
                {
                    month = "Mar";
                }
                else if (mon == "4")
                {
                    month = "Apr";
                }
                else if (mon == "5")
                {
                    month = "May";
                }
                else if (mon == "6")
                {
                    month = "Jun";
                }
                else if (mon == "7")
                {
                    month = "Jul";
                }
                else if (mon == "8")
                {
                    month = "Aug";
                }
                else if (mon == "9")
                {
                    month = "Sep";
                }
                else if (mon == "10")
                {
                    month = "Oct";
                }
                else if (mon == "11")
                {
                    month = "Nov";
                }
                else if (mon == "12")
                {
                    month = "Dec";
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return month;
        }

    }
}
