﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace OHES.eFit.Data.Repository
{
    public interface IDocMangerRepository
    {

        #region Document Manager Pages

        companyL getCompaniesList(int companyTypeId);


        List<TrainingRecordVM> getTrainingTrainers(InputDetails ID,string userName);
        List<ActiveTrainees> getActiveTrainees(InputDetails ID);
        companyL getCompaniesListFitTrain(int tID, int disID);
        companyL getDistributorCompaniesList(string companyName, int tID, int disID);

        ActionStatus CheckTraineeName(string CompanyName);
        ActionStatus CheckTrainerName(string CompanyName);


        DataSet ExportActiveTrainees(string CompanyName, string searchText, Int64 TotalRecords);
        DataSet ExportTrainingTrainer(int tTID, string CompanyName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExportTrainerFittestRecord(string CompanyName, string TrainingDate, int tTID, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder,string userName);
        #endregion

    }


    public class DocMangerRepository : RepositoryBase<eFitContext>, IDocMangerRepository
    {
        #region Constructor

        private Database mDB;

        public DocMangerRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }

        #endregion

        //Created By : Kalpana
        //Created On : 19-February-2015
        //Purpose    : Get Companies List
        public companyL getCompaniesList(int companyTypeId)
        {
            companyL comList = new companyL();
            try{
            using (var context = DataContext)
            {
                var cList = context.CompaniesList
                  .GroupBy(x => x.CompanyName)
                  .Select(g => new { CompanyName = g.Key, CompanyID = g.FirstOrDefault().CompanyID })
                  .ToList();

                foreach (var item in cList)
                {
                    comList.companyName.Add(item.CompanyName);
                }

            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }

            return comList;
        }

        //Created By : Kalpana
        //Created On : 19-February-2015
        //Purpose    : Get Companies List Fittest Train The Trainer
        public companyL getCompaniesListFitTrain(int tID, int disID)
        {
            companyL comList = new companyL();
            DataSet mDS;
            try
            {
                using (var context = DataContext)
                {
                    if (disID == 1)
                    {
                        mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord", tID, "", "", 1, 1000, "", "", "");
                    }
                    else
                    {
                        mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin", tID, "", "", 1, 1000, "", "", "");
                    }
                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[2];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            CompaniesList company = new CompaniesList();
                            company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();

                            if (!string.IsNullOrEmpty(company.CompanyName))
                            {
                                comList.companyName.Add(company.CompanyName);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 19-February-2015
        //Purpose    : Get Distributors Companies List
        public companyL getDistributorCompaniesList(string companyName, int tID, int disID)
        {
            companyL comList = new companyL();
            DataSet mDS;
            try
            {
                using (var context = DataContext)
                {
                    if (disID == 1)
                    {
                        mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Distributed",tID, companyName, "", 1, 50, "", "", "");
                    }
                    else
                    {
                        mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Distributed", tID, companyName, "", 1, 50, "", "", "");
                    }
                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[2];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            CompaniesList company = new CompaniesList();
                            company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();

                            if (!string.IsNullOrEmpty(company.CompanyName))
                            {
                                comList.companyName.Add(company.CompanyName);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 19-February-2015
        //Purpose    : Getting Active Trainees Details For Certificate
        public List<ActiveTrainees> getActiveTrainees(InputDetails ID)
        {
            List<ActiveTrainees> objMembers = new List<ActiveTrainees>();
            try{
            string dayT, monT, yearT, Tdate;

            if (ID.searchText == null)
            { ID.searchText = ""; }


            if (ID.sortOrder == "True")
            { ID.sortOrder = "Asc"; }
            else { ID.sortOrder = "Desc"; }
            if (ID.trainingDate != null && ID.trainingDate != "")
            {
                string[] words = ID.trainingDate.Split('-');
                monT = words[0];
                dayT = words[1];
                yearT = words[2];
                Tdate = yearT + monT + dayT;
            }
            else
            { Tdate = ""; }



            DataSet mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "1");

            if (mDS.Tables.Count > 0)
            {
                DataTable dT1 = mDS.Tables[0];
                foreach (DataRow dr in dT1.Rows)
                {
                    ActiveTrainees activeTrainees = new ActiveTrainees();

                    activeTrainees.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                    activeTrainees.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                    activeTrainees.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                    activeTrainees.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                    activeTrainees.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                    activeTrainees.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                    activeTrainees.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                    activeTrainees.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                    activeTrainees.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                    activeTrainees.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                    activeTrainees.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();



                    DataTable dT2 = mDS.Tables[1];
                    foreach (DataRow dr2 in dT2.Rows)
                    {
                        activeTrainees.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                    }
                    objMembers.Add(activeTrainees);
                }

            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }


            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 19-February-2015
        //Purpose    : Getting Trainers Details 
        public List<TrainingRecordVM> getTrainingTrainers(InputDetails ID,string userName)
        {
            List<TrainingRecordVM> objMembers = new List<TrainingRecordVM>();
            try{
            string dayT, monT, yearT, Tdate;
            DataSet mDS;
            if (ID.searchText == null)
            { ID.searchText = ""; }
            if (ID.sortOrder == "True")
            { ID.sortOrder = "Asc"; }
            else { ID.sortOrder = "Desc"; }
            if (ID.trainingDate != null && ID.trainingDate != "")
            {
                string[] words = ID.trainingDate.Split('-');
                dayT = words[0];
                monT = MonthConvert(words[1]);
                yearT = words[2];
                Tdate = yearT + monT + dayT;
            }
            else
            { Tdate = ""; }

            if (ID.adminId != 1)
            {
                if (ID.companyTypeID == 3)
                {
                    if (ID.traineeType == 1)
                    {
                        mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Distributed_FitTest", ID.traineeType, ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder,userName);
                    }
                    else
                    {
                        mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Distributed", ID.traineeType, ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder);
                    }
                }
                else
                {

                    mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin", ID.traineeType, ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder);
                }
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        TrainingRecordVM trainingRecord = new TrainingRecordVM();
                        trainingRecord.RefNo = Convert.ToInt32(dr["RefNo"]); //dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        trainingRecord.CompanyId = Convert.ToInt32(dr["CompanyID"]);
                        trainingRecord.TRFDateS = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString(); //Convert.ToDateTime(dr["TrainingDate"]);
                        trainingRecord.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        trainingRecord.TrainerCompanyName = dr["TrainerCompanyName"] == DBNull.Value ? "" : dr["TrainerCompanyName"].ToString();
                        trainingRecord.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        trainingRecord.Email = dr["Email"] == DBNull.Value ? "" : dr["Email"].ToString();
                        if (dr["TrainerPicFileId"].ToString() != "")
                        {
                            trainingRecord.TrainerPicFileId = new Guid(dr["TrainerPicFileId"].ToString());
                        }

                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            trainingRecord.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(trainingRecord);
                    }

                }

            }
            else
            {
                mDS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin", ID.traineeType, ID.companyName, Tdate, ID.pageIndex, 100, ID.searchText, ID.sortColumn, ID.sortOrder);
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        TrainingRecordVM trainingRecord = new TrainingRecordVM();
                        trainingRecord.RefNo = Convert.ToInt32(dr["RefNo"]); //dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        trainingRecord.CompanyId = Convert.ToInt32(dr["CompanyID"]);
                        trainingRecord.TRFDateS = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString(); //Convert.ToDateTime(dr["TrainingDate"]);
                        trainingRecord.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString().Trim();
                        trainingRecord.TrainerCompanyName = dr["TrainerCompanyName"] == DBNull.Value ? "" : dr["TrainerCompanyName"].ToString();
                        trainingRecord.TrainerCompanyID = Convert.ToInt32(dr["TrainerCompanyID"]);
                        trainingRecord.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        trainingRecord.Email = dr["Email"] == DBNull.Value ? "" : dr["Email"].ToString();
                        if (dr["TrainerPicFileId"].ToString() != "")
                        {
                            trainingRecord.TrainerPicFileId = new Guid(dr["TrainerPicFileId"].ToString());
                        }

                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            trainingRecord.TotalRecordsExp = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        int addCount = 0;
                        foreach (var itemE in objMembers)
                        {
                            if (itemE.TrainerName.Trim().ToLower() == trainingRecord.TrainerName.ToLower() && itemE.TrainerCompanyName == trainingRecord.TrainerCompanyName)
                            {
                                addCount++;
                            }
                        }
                        if (addCount == 0)
                        {
                            objMembers.Add(trainingRecord);
                        }
                    }
                    foreach (var itemE in objMembers)
                    {
                        itemE.TotalRecords = objMembers.Count();
                    }

                }
            }
            
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }

            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export Active Trainees Details
        public DataSet ExportActiveTrainees(string CompanyName, string searchText, Int64 TotalRecords)
        {
            DataSet mDSTTS = new DataSet();
            try{

            using (var context = DataContext)
            {
                mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", CompanyName, "", 0, TotalRecords, searchText, "TrainingDate", "Desc", "1");
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }

            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export TrainingTrainer Details
        public DataSet ExportTrainingTrainer(int tTID, string CompanyName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
            string dayT, monT, yearT, Tdate;

            if (searchText == null)
            { searchText = ""; }

            if (TrainingDate != null && TrainingDate != "")
            {
                string[] words = TrainingDate.Split('-');
                dayT = words[0];
                monT = MonthConvert(words[1]);
                yearT = words[2];
                Tdate = yearT + monT + dayT;
            }
            else
            { Tdate = ""; }
            if (sortOrder == "true")
            { sortOrder = "Asc"; }
            else { sortOrder = "Desc"; }
            using (var context = DataContext)
            {
                    if (companyTypeID > 1)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Distributed", tTID, CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder);
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin", tTID, CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder);
                    }
              
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Ramya
        //Created On : 23-February-2015
        //Purpose    : Export Trainer Fit Test Record Details
        public DataSet ExportTrainerFittestRecord(string CompanyName, string TrainingDate, int tTID, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder, string userName)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
            string dayT, monT, yearT, Tdate;

            if (searchText == null)
            { searchText = ""; }

            if (TrainingDate != null && TrainingDate != "")
            {
                string[] words = TrainingDate.Split('-');
                dayT = words[0];
                monT = MonthConvert(words[1]);
                yearT = words[2];
                Tdate = yearT + monT + dayT;
            }
            else
            { Tdate = ""; }
            if (sortOrder == "true")
            { sortOrder = "Asc"; }
            else { sortOrder = "Desc"; }
            using (var context = DataContext)
            {
                if (companyTypeID == 3)
                {
                    if (tTID == 1)
                    { mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Distributed_FitTest", tTID, CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, userName); }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Distributed", tTID, CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder);
                    }
                }
                else
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin", tTID, CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder);
                }
            }

            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Check Trainee Name
        public ActionStatus CheckTraineeName(string Name)
        {
            ActionStatus status = new ActionStatus();
          
            using (var context = DataContext)
            {
                try
                {

                    var cList = context.TrainingAttendance.Where(w => w.Name == Name).ToList();

                    if (cList.Count > 0)
                    { status.success = true; }
                    else
                    {
                        status.success = false;
                        status.message = "Please select trainee name from the list";
                    }

                }

                catch (Exception ex)
                {
                    Utility.Utility.LogException(ex);
                }
                return status;
            }
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Check Trainer Name
        public ActionStatus CheckTrainerName(string Name)
        {
            ActionStatus status = new ActionStatus();
            using (var context = DataContext)
            {
                try
                {

                    var cList = context.TrainingRecord.Where(w => w.TrainerName == Name).ToList();

                    if (cList.Count > 0)
                    { status.success = true; }
                    else
                    {
                        status.success = false;
                        status.message = "Please select trainer name from the list";
                    }

                }

                catch (Exception ex)
                {
                    Utility.Utility.LogException(ex);
                }
                return status;
            }
        }
    
    
    }
}
