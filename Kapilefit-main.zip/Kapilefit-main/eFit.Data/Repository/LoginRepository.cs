﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.SqlClient;

namespace OHES.eFit.Data.Repository
{
    public interface ILoginRepository
    {
        #region Login Details
        User submitLoginDetails(User objLoginDetails, string domain);
        Int64 getHitCountTotal();
        string getHitCount();
        #endregion
    }

    public class LoginRepository : RepositoryBase<eFitContext>, ILoginRepository
    {
        private Microsoft.Practices.EnterpriseLibrary.Data.Database mDB;
        public LoginRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }
        [System.Runtime.InteropServices.DllImport("advapi32.dll", EntryPoint = "LogonUser", ExactSpelling = false, CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
        public static extern int LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Login 
        public User submitLoginDetails(User objLoginDetails, string domain)
        {
            try
            {
          
                using (var context = DataContext)
                {
                    var auth = context.Users.Where(w => w.UserID == objLoginDetails.UserID).FirstOrDefault();
                    if (auth != null)
                    {
                        if (!string.IsNullOrEmpty(auth.Password) || string.IsNullOrEmpty(auth.Password))
                        {
                            objLoginDetails.UserID = auth.UserID;
                            objLoginDetails.UserName = auth.UserName;
                            objLoginDetails.CompanyName = auth.CompanyName;
                            objLoginDetails.RoleID = auth.RoleID;
                            objLoginDetails.CompanyID = auth.CompanyID;
                            var comType = context.CompaniesList.Where(x => x.CompanyID == auth.CompanyID).FirstOrDefault();
                            if (comType != null)
                            {
                                objLoginDetails.companyTypeId = comType.CompanyTypeID;
                            }
                        }
                        else
                        {
                            bool returnValue = false;
                            IntPtr tokenHandle = new IntPtr(0);
                            int LOGON32_PROVIDER_DEFAULT = 0;
                            int LOGON32_LOGON_NETWORK_CLEARTEXT = 3;
                            tokenHandle = IntPtr.Zero;
                            string[] domains = domain.Split(',');
                            int result = 0;
                            foreach (string mDomain in domains)
                            {
                                result = LogonUser(objLoginDetails.UserID, mDomain, objLoginDetails.Password, LOGON32_LOGON_NETWORK_CLEARTEXT, LOGON32_PROVIDER_DEFAULT, ref tokenHandle);
                                if (Convert.ToBoolean(result))
                                {
                                    break;
                                }
                            }
                            returnValue = Convert.ToBoolean(result);
                            if (returnValue == false)
                            {
                                objLoginDetails = null;
                            }
                            else
                            {
                                objLoginDetails.UserID = auth.UserID;
                                objLoginDetails.UserName = auth.UserName;
                                objLoginDetails.CompanyName = auth.CompanyName;
                                objLoginDetails.RoleID = auth.RoleID;
                                var comType = context.CompaniesList.Where(x => x.CompanyID == auth.CompanyID).FirstOrDefault();

                                objLoginDetails.companyTypeId = comType.CompanyTypeID;
                            }
                        }
                    }
                    else
                    {
                        objLoginDetails = null;
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objLoginDetails;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get Hit Count
        public string getHitCount()
        {
            string Count = "";
            DataSet mDS = new DataSet();
            try
            {
                mDS = mDB.ExecuteDataSet("SP_GetHitCount");

                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {

                        Count = (dr["HitCount"] == DBNull.Value ? 0 : Convert.ToInt32(dr["HitCount"])).ToString();

                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return Count;

        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get Hit Count
        public Int64 getHitCountTotal()
        {
            Int64 Count = 0;
            try
            {
                using (var context = DataContext)
                {
                    var hitCount = context.HitCount.Select(s => new
                    {
                        s.PageName,
                        s.HitCount
                    }).ToList();
                    foreach (var single in hitCount)
                    {
                        Count = single.HitCount;
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return Count;

        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Decrypt Password
        private string Decryptdata(string encryptpwd)
        {
            string decryptpwd = string.Empty;
            try
            {
                UTF32Encoding encodepwd = new UTF32Encoding();
                Decoder Decode = encodepwd.GetDecoder();
                byte[] todecode_byte = Convert.FromBase64String(encryptpwd);
                int charCount = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                char[] decoded_char = new char[charCount];
                Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
                decryptpwd = new String(decoded_char);
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return decryptpwd;
        }



        public User getAuthorization(string userId)
        {
            User objLoginDetails = new User();
            try
            {
                
                using (var context = DataContext)
                {
                    var auth = context.Users.Where(w => w.UserID == userId || w.EmailID==userId).FirstOrDefault();
                    if (auth != null)
                    {
                        
                            objLoginDetails.UserID = auth.UserID;
                            objLoginDetails.UserName = auth.UserName;
                            objLoginDetails.CompanyName = auth.CompanyName;
                            objLoginDetails.RoleID = auth.RoleID;
                            objLoginDetails.CompanyID = auth.CompanyID;
                            var comType = context.CompaniesList.Where(x => x.CompanyID == auth.CompanyID).FirstOrDefault();
                            if (comType != null)
                            {
                                objLoginDetails.companyTypeId = comType.CompanyTypeID;
                            }

                           
                       
                        }
                    }
                   
                }
            
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objLoginDetails;
        }



    }
}

