﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.SqlClient;

namespace OHES.eFit.Data.Repository
{

    public interface IeFitToolAdminRepository
    {
        //Admin
        #region CustomerListingPages

        List<TrainingType> getTrainingType();
        ICollection<QuickLinksDetails> getQuickLinksDetails(int flag);
        List<CompanyType> getCompaniesType(int companyTrainingTypeId);
        companyL getCompaniesList(int companyTypeId);
        trainingCompanyL getTrainingCompaniesList(int companyTypeId);
        TrainerList getTrainerName(string companyTypeId);
        List<Distributors> getCompaniesDetails(string companyName);
        ActionStatus saveUploadForm(UploadFormVM uploadForm,string userID);
        byte[] GetImageFromDataBase(Guid fileId);
        ActionStatus saveAttach(TempAttachments attach);
        ActionStatus uploadTrainerPhoto(Int32 RefNo, string TrainerName, Int32 TrainerCompanyID);
        UploadFormVM getActiveTrainersListdData(Int32 RefNo);
        ActionStatus DeleteImage(Guid fileId, Int32 RefNo, string TrainerName, Int32 TrainerCompanyID);
        ActionStatus CheckTrainingCompany(string TrainingCompanyName);
        ActionStatus CheckTrainerName(string trainingCompanyName, string trainerName);
        List<QuickLinks> getQuickLinks(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder);
        DataSet ExportLinksSummary(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder);
        QuickLinksDetails getLinkData(int SNo);
        ActionStatus saveLinkDetails(QuickLinksDetails Linkdts);

        #endregion

    }


    public class eFitToolAdminRepository : RepositoryBase<eFitContext>, IeFitToolAdminRepository
    {
        private Database mDB;

        #region Constructor

        public eFitToolAdminRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }

        #endregion

        //created By:M.marimuthu
        //Created On : 06-February-2015
        //Purpose    : Getting Quick Links Details
        public ICollection<QuickLinksDetails> getQuickLinksDetails(int flag)
        {
            ICollection<QuickLinksDetails> QuickLinks = new List<QuickLinksDetails>();
            try
            {
                using (var context = DataContext)
                {

                    DataSet mDS = mDB.ExecuteDataSet("SP_GetQuickLinkDetails", flag);
                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[0];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            QuickLinksDetails singleQuickLinks = new QuickLinksDetails();
                            singleQuickLinks.SNo = Convert.ToInt32(dr["SNo"]);
                            singleQuickLinks.Name = Convert.ToString(dr["Name"]);
                            singleQuickLinks.URL = Convert.ToString(dr["URL"]);
                            singleQuickLinks.Target = Convert.ToString(dr["Target"]);
                            QuickLinks.Add(singleQuickLinks);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return QuickLinks;
        }

        //Created By : Kalpana
        //Created On : 06-February-2015
        //Purpose    : Getting Training Type
        public List<TrainingType> getTrainingType()
        {
            List<TrainingType> trainingList = new List<TrainingType>();
            try
            {
                using (var context = DataContext)
                {
                    var tList = context.TrainingType.Select(s => new
                    {
                        s.ID,
                        s.Type
                    }).OrderBy(o => o.ID).ToList();
                    foreach (var single in tList)
                    {
                        TrainingType trainingTypeList = new TrainingType();
                        trainingTypeList.Type = single.Type.Contains("\r\n") ? single.Type.Replace("\r\n", "") : single.Type;
                        trainingTypeList.ID = single.ID;
                        trainingList.Add(trainingTypeList);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return trainingList;
        }

        //Created By : Kalpana
        //Created On : 06-February-2015
        //Purpose    : Getting Company Type
        public List<CompanyType> getCompaniesType(int companyTrainingTypeId)
        {
            List<CompanyType> companyType = new List<CompanyType>();

            try
            {
                using (var context = DataContext)
                {
                    var cType = context.CompanyType.Select(s => new
                    {
                        s.ID,
                        s.Type
                    }).OrderBy(o => o.ID).ToList();
                    foreach (var single in cType)
                    {
                        CompanyType companyTypeList = new CompanyType();
                        companyTypeList.Type = single.Type.Contains("\r\n") ? single.Type.Replace("\r\n", "") : single.Type;
                        companyTypeList.ID = single.ID;
                        companyType.Add(companyTypeList);

                    }
                    if (companyTrainingTypeId == 1)
                    {
                        companyType.RemoveAll(x => x.Type == "Host");
                        companyType.RemoveAll(x => x.Type == "Distributor");
                    }
                    //else
                    //{
                    //    companyType.RemoveAll(x => x.Type == "Private");
                    //    companyType.RemoveAll(x => x.Type == "Govt");
                    //}
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return companyType;
        }

        //Created By : Kalpana
        //Created On : 06-February-2015
        //Purpose    : Getting Companies List
        public companyL getCompaniesList(int companyTypeId)
        {
            companyL comList = new companyL();
            try
            {
                using (var context = DataContext)
                {
                    var cList = context.CompaniesList.Where(x => x.CompanyTypeID == companyTypeId)
                      .GroupBy(x => x.CompanyName)
                      .Select(g => new { CompanyName = g.Key, CompanyID = g.FirstOrDefault().CompanyID })
                      .ToList();
                    foreach (var item in cList)
                    {
                        if (item.CompanyName != "" && item.CompanyName != null)
                        {
                            comList.companyName.Add(item.CompanyName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 06-February-2015
        //Purpose    : Getting Training Companies List
        public trainingCompanyL getTrainingCompaniesList(int companyTypeId)
        {
            trainingCompanyL comList = new trainingCompanyL();
            try
            {
                using (var context = DataContext)
                {
                    DataSet mDS = mDB.ExecuteDataSet("SP_Dis_CompanyName");
                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[0];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            CompaniesList company = new CompaniesList();

                            company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                            if (!string.IsNullOrEmpty(company.CompanyName))
                            {
                                comList.companyName.Add(company.CompanyName);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 06-February-2015
        //Purpose    : Getting Trainer Name List
        public TrainerList getTrainerName(string companyName)
        {
            TrainerList trainerList = new TrainerList();
            try
            {

                using (var context = DataContext)
                {
                    var companyData = context.CompaniesList.Where(w => w.CompanyName == companyName).FirstOrDefault();
                    if (companyData != null)
                    {

                        //Adding From Trainer Table
                        var tlist = context.TrainingRecord.Where(x => x.TrainerCompanyID == companyData.CompanyID)
                          .GroupBy(x => x.TrainerName)
                          .Select(g => new { RefNo = g.Key, TrainerName = g.FirstOrDefault().TrainerName })
                          .ToList();
                        foreach (var single in tlist)
                        {
                            if (single.TrainerName != null && single.TrainerName != "")
                            {
                                trainerList.TrainerName.Add(single.TrainerName);
                            }
                        }

                        //Adding From Trainee Table
                        DataSet mDS = mDB.ExecuteDataSet("SP_Get_TrainerTheTrainer_Trainee_List", companyData.CompanyID);
                        if (mDS.Tables.Count > 0)
                        {
                            DataTable dT1 = mDS.Tables[0];
                            foreach (DataRow dr in dT1.Rows)
                            {
                                string traineeName = dr["Name"] == DBNull.Value ? "" : dr["Name"].ToString();

                                trainerList.TrainerName.Add(traineeName);
                            }
                        }
                    }
                    else
                    {
                        trainerList.company = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return trainerList;
        }

        //Created By : Kalpana
        //Created On : 06-February-2015
        //Purpose    : Getting Companies Details
        public List<Distributors> getCompaniesDetails(string companyName)
        {
            List<Distributors> cLi = new List<Distributors>();
            try
            {
                using (var context = DataContext)
                {
                    var companyData = context.CompaniesList.Where(w => w.CompanyName == companyName).FirstOrDefault();
                    if (companyData != null)
                    {
                        var cList = context.CompaniesList.Where(s => s.CompanyID == companyData.CompanyID).ToList();
                        foreach (var single in cList)
                        {
                            Distributors dDeatails = new Distributors();
                            dDeatails.Address = single.Address;
                            dDeatails.PostalCode = single.PostalCode;
                            dDeatails.ContactPerson = single.ContactPerson;
                            dDeatails.ContactDesignation = single.ContactDesignation;
                            dDeatails.ContactNumber = single.ContactNumber;
                            dDeatails.CompanyName = single.CompanyName;
                            dDeatails.Email = single.Email;
                            cLi.Add(dDeatails);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return cLi;
        }

        //Created By : Kalpana
        //Created On : 06-February-2015
        //Purpose    : Save Trainer Data
        public ActionStatus saveUploadForm(UploadFormVM uploadForm, string userID)
        {
            ActionStatus objActionStatus = new ActionStatus();
            Int32 lastinsertedRefNo = 0;
            try
            {
                string month = string.Empty;
                using (var context = DataContext)
                {
                    TrainingRecord uploadData = new TrainingRecord();
                    Distributors companies = new Distributors();

                    TrainingRecordVM uploadDataS = uploadForm.trainingRecord;
                    refNoList refe = new refNoList();
                    string referenceNo = string.Empty;
                    string resultRefS = string.Empty;

                    int trainingRecordExistsCount = 0;

                    var companyData = context.CompaniesList.Where(w => w.CompanyName == uploadForm.trainingRecord.CompanyName).FirstOrDefault();

                    //Check Existing Data
                    if (companyData != null)
                    {
                        var trainingRecordExists = context.TrainingRecord.Where(w => w.TRFDate == uploadForm.trainingRecord.TRFDate && w.TrainingTypeID == uploadForm.trainingRecord.TrainingTypeID
                            && w.CompanyID == companyData.CompanyID).ToList();

                        if (uploadForm.trainingRecord.RefNo == 0)
                        {
                            trainingRecordExistsCount = trainingRecordExists.Count();
                        }
                        else
                        {
                            foreach (var item in trainingRecordExists)
                            {
                                if (item.RefNo != uploadForm.trainingRecord.RefNo)
                                {
                                    trainingRecordExistsCount++;
                                }
                            }
                        }
                    }
                    

                    if (trainingRecordExistsCount == 0)
                    {
                        if (companyData == null)
                        {


                            
                                companies.CompanyName = uploadForm.trainingRecord.CompanyName;
                                companies.CompanyTypeID = uploadForm.trainingRecord.CompanyTypeID;
                                companies.Email = uploadForm.trainingRecord.Email;
                                if (uploadForm.companiesDetails != null)
                                {
                                companies.Address = uploadForm.companiesDetails.Address;
                                companies.PostalCode = uploadForm.companiesDetails.PostalCode;
                                companies.ContactPerson = uploadForm.companiesDetails.ContactPerson;
                                companies.ContactDesignation = uploadForm.companiesDetails.ContactDesignation;
                                companies.ContactNumber = uploadForm.companiesDetails.ContactNumber;
                                }
                                companies.FileName = uploadForm.trainingRecord.FileName;
                                context.CompaniesList.Add(companies);
                                context.SaveChanges();
                                objActionStatus.success = true;
                                objActionStatus.message = "Company Saved successfully";
                            

                        }
                        else
                        {
                            Distributors companyGrid = context.CompaniesList.Find(companyData.CompanyID);
                            if (companyGrid != null)
                            {
                                companyGrid.CompanyID = companyData.CompanyID;
                                companyGrid.CompanyName = uploadForm.trainingRecord.CompanyName;
                                companyGrid.CompanyTypeID = uploadForm.trainingRecord.CompanyTypeID;
                                companyGrid.Address = uploadForm.companiesDetails.Address;
                                companyGrid.PostalCode = uploadForm.companiesDetails.PostalCode;
                                companyGrid.ContactPerson = uploadForm.companiesDetails.ContactPerson;
                                companyGrid.ContactDesignation = uploadForm.companiesDetails.ContactDesignation;
                                companyGrid.ContactNumber = uploadForm.companiesDetails.ContactNumber;
                                companyGrid.Email = uploadForm.trainingRecord.Email;
                                context.SaveChanges();
                                objActionStatus.success = true;
                                objActionStatus.message = "Company Updated successfully";
                            }
                        }

                        var companyDataTraining = context.CompaniesList.Where(w => w.CompanyName == uploadForm.trainingRecord.TrainerCompanyName).FirstOrDefault();
                        if (companyDataTraining == null)
                        {
                            companies.CompanyName = uploadForm.trainingRecord.TrainerCompanyName;
                            companies.CompanyTypeID = uploadForm.trainingRecord.CompanyTypeID;
                            companies.Address = uploadForm.companiesDetails.Address;
                            companies.PostalCode = uploadForm.companiesDetails.PostalCode;
                            companies.ContactPerson = uploadForm.companiesDetails.ContactPerson;
                            companies.ContactDesignation = uploadForm.companiesDetails.ContactDesignation;
                            companies.ContactNumber = uploadForm.companiesDetails.ContactNumber;
                            context.CompaniesList.Add(companies);
                            context.SaveChanges();
                            objActionStatus.success = true;
                            objActionStatus.message = "Saved successfully";
                        }

                        companyData = context.CompaniesList.Where(w => w.CompanyName == uploadForm.trainingRecord.CompanyName).FirstOrDefault();
                        companyDataTraining = context.CompaniesList.Where(w => w.CompanyName == uploadForm.trainingRecord.TrainerCompanyName).FirstOrDefault();

                        if (companyData != null && companyDataTraining != null)
                        {
                            var trainingRecord = context.TrainingRecord.Where(w => w.RefNo == uploadForm.trainingRecord.RefNo).FirstOrDefault();
                            if (trainingRecord == null)
                            {

                                uploadData.CompanyID = companyData.CompanyID;
                                uploadData.TRFDate = uploadDataS.TRFDate;
                                uploadData.TopicsCovered = uploadDataS.TopicsCovered;
                                uploadData.TrainerName = uploadDataS.TrainerName;
                                uploadData.TrainerCompanyID = companyDataTraining.CompanyID;
                                uploadData.Email = uploadDataS.Email;
                                uploadData.TrainingTypeID = uploadDataS.TrainingTypeID;
                                uploadData.FileName = uploadDataS.FileName;
                                uploadData.modifiedBy = userID;
                                uploadData.modifiedDate = DateTime.Now;


                                //Saving Training Record
                                context.TrainingRecord.Add(uploadData);
                                context.SaveChanges();
                                lastinsertedRefNo = uploadData.RefNo;
                                objActionStatus.success = true;
                                objActionStatus.message = "Saved successfully";
                            }
                            else
                            {
                                TrainingRecord trainerRecordGrid = context.TrainingRecord.Find(uploadForm.trainingRecord.RefNo);
                                if (trainerRecordGrid != null)
                                {
                                    trainerRecordGrid.CompanyID = companyData.CompanyID;
                                    trainerRecordGrid.TRFDate = uploadDataS.TRFDate;
                                    trainerRecordGrid.TopicsCovered = uploadDataS.TopicsCovered;
                                    trainerRecordGrid.TrainerName = uploadDataS.TrainerName;
                                    trainerRecordGrid.TrainerCompanyID = companyDataTraining.CompanyID;
                                    trainerRecordGrid.Email = uploadDataS.Email;
                                    trainerRecordGrid.TrainingTypeID = uploadDataS.TrainingTypeID;
                                    trainerRecordGrid.FileName = uploadDataS.FileName;
                                    trainerRecordGrid.modifiedBy = userID;
                                    trainerRecordGrid.modifiedDate = DateTime.Now;

                                    //Updating Training Record
                                    context.SaveChanges();
                                    objActionStatus.success = true;
                                    objActionStatus.message = "Updated successfully";
                                }
                            }

                            var trainingAttendanceRecordDelCheck = context.TrainingAttendance.Where(w => w.RefNo == uploadForm.trainingRecord.RefNo).FirstOrDefault();
                            if (trainingAttendanceRecordDelCheck != null)
                            {
                                //Deleting All Trainee Records
                                var items = context.TrainingAttendance.Where(item => item.RefNo == uploadForm.trainingRecord.RefNo).ToList();
                                foreach (var item in items)
                                {
                                    context.TrainingAttendance.Remove(item);
                                    context.SaveChanges();
                                }
                            }
                            if (uploadForm.trainingAttendance.Count > 0)
                            {
                                foreach (var traineeList in uploadForm.trainingAttendance)
                                {
                                    TrainingAttendance traineeAtt = new TrainingAttendance();
                                    var trainingAttendanceRecordAdd = context.TrainingAttendance.Where(w => w.RefNo == uploadForm.trainingRecord.RefNo && w.Name == traineeList.nameOfTrainee).FirstOrDefault();
                                    if (trainingAttendanceRecordAdd == null)
                                    {
                                        if (lastinsertedRefNo > 0)
                                        {
                                            traineeAtt.RefNo = lastinsertedRefNo;
                                        }
                                        else
                                        {
                                            traineeAtt.RefNo = uploadForm.trainingRecord.RefNo;
                                        }
                                        traineeAtt.Name = traineeList.nameOfTrainee;
                                        traineeAtt.Designation = traineeList.designation;
                                        traineeAtt.Department = traineeList.dept;
                                        traineeAtt.IC = traineeList.IDNo;
                                        traineeAtt.Model = traineeList.model;
                                        traineeAtt.Outcome = traineeList.outcome;
                                        //Saving Trainee Record
                                        context.TrainingAttendance.Add(traineeAtt);
                                        context.SaveChanges();

                                        objActionStatus.success = true;
                                    }
                                }
                            }
                            objActionStatus.success = true;
                        }
                    }
                    else
                    {
                        objActionStatus.success = false;
                        objActionStatus.message = "The training record(s) that you are trying to update already exists in the system.";
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objActionStatus;

        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Getting Trainer Data
        public UploadFormVM getActiveTrainersListdData(Int32 RefNo)
        {
            UploadForm objTrainers = new UploadForm();
            UploadFormVM objTrainersOut = new UploadFormVM();
            try
            {
                using (var context = DataContext)
                {
                    objTrainers.trainingRecord = context.TrainingRecord.Where(w => w.RefNo == RefNo).Select(s => s).FirstOrDefault();
                    if (objTrainers.trainingRecord != null)
                    {
                        var comName = context.CompaniesList.Where(w => w.CompanyID == objTrainers.trainingRecord.CompanyID).Select(s => s).FirstOrDefault();
                        var TrainerComName = context.CompaniesList.Where(w => w.CompanyID == objTrainers.trainingRecord.TrainerCompanyID).Select(s => s).FirstOrDefault();

                        //Companies Details
                        objTrainersOut.companiesDetails.Address = comName.Address;
                        objTrainersOut.companiesDetails.PostalCode = comName.PostalCode;
                        objTrainersOut.companiesDetails.ContactPerson = comName.ContactPerson;
                        objTrainersOut.companiesDetails.ContactNumber = comName.ContactNumber;
                        objTrainersOut.companiesDetails.ContactDesignation = comName.ContactDesignation;

                        //Training Record Details
                        objTrainersOut.trainingRecord.CompanyName = comName.CompanyName;
                        objTrainersOut.trainingRecord.CompanyTypeID = comName.CompanyTypeID;
                        objTrainersOut.trainingRecord.TrainerCompanyName = TrainerComName.CompanyName;
                        objTrainersOut.trainingRecord.Email = objTrainers.trainingRecord.Email;
                        objTrainersOut.trainingRecord.RefNo = objTrainers.trainingRecord.RefNo;
                        objTrainersOut.trainingRecord.TopicsCovered = objTrainers.trainingRecord.TopicsCovered;
                        objTrainersOut.trainingRecord.TrainerName = objTrainers.trainingRecord.TrainerName;
                        objTrainersOut.trainingRecord.TrainingTypeID = objTrainers.trainingRecord.TrainingTypeID;
                        DateTime traDate = objTrainers.trainingRecord.TRFDate;
                        string date = string.Empty;
                        if (traDate.Day < 10)
                        {
                            date = traDate.Day.ToString().PadLeft(2, '0');
                        }
                        else
                        {
                            date = traDate.Day.ToString();
                        }
                        objTrainersOut.trainingRecord.TRFDateS = date + '-' + ConvertMonth(traDate.Month.ToString()) + '-' + traDate.Year.ToString();

                    }

                    //Training Attendance Details
                    objTrainers.trainingAttendance = (from s in context.TrainingAttendance where s.RefNo == RefNo select s).ToList<TrainingAttendance>();
                    //context.TrainingAttendance.Where(w => w.RefNo == RefNo).Select(s => s).ToList<TrainingAttendance>();

                    foreach (var item in objTrainers.trainingAttendance)
                    {
                        TrainingAttendanceVM traAtt = new TrainingAttendanceVM();
                        traAtt.nameOfTrainee = item.Name;
                        traAtt.IDNo = item.IC;
                        traAtt.dept = item.Department;
                        traAtt.designation = item.Designation;
                        traAtt.RefNo = item.RefNo;
                        traAtt.outcome = item.Outcome;
                        traAtt.model = item.Model;

                        objTrainersOut.trainingAttendance.Add(traAtt);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objTrainersOut;
        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Get Image From DataBase
        public byte[] GetImageFromDataBase(Guid fileId)
        {

            try
            {
                byte[] data;
                using (var context = DataContext)
                {

                    data = (from temp in context.T_Trainers_Temp_Pic_Attachments where temp.fileId == fileId select temp.fileContent).FirstOrDefault();
                    if (data == null)
                    {
                        data = (from temp in context.T_Trainers_Attachments where temp.fileId == fileId select temp.fileContent).FirstOrDefault();
                    }

                }
                return data;
            }
            catch (Exception ex)
            {
               
                Utility.Utility.LogException(ex);
                return null;
            }

        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Save Image To DataBase
        public ActionStatus saveAttach(TempAttachments attach)
        {
            ActionStatus status = new ActionStatus();
            using (var context = DataContext)
            {
                try
                {
                    context.T_Trainers_Temp_Pic_Attachments.Add(attach);
                    context.SaveChanges();
                    status.success = true;
                }
                catch (Exception ex)
                {
                    status.success = false;
                    Utility.Utility.LogException(ex);
                }
            }
            return status;
        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Upload Image To DataBase
        public ActionStatus uploadTrainerPhoto(Int32 RefNo, string TrainerName, Int32 TrainerCompanyID)
        {
            ActionStatus status = new ActionStatus();
            DataSet mDSTTS = new DataSet();
            using (var context = DataContext)
            {
                try
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin_PhotoUpload", TrainerCompanyID, TrainerName);

                    
                    var getFileInfo = context.T_Trainers_Temp_Pic_Attachments.FirstOrDefault();
                    var tempDatas = context.T_Trainers_Temp_Pic_Attachments;

                    if (mDSTTS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDSTTS.Tables[0];
                        if (dT1.Rows.Count > 0)
                        {
                                if (getFileInfo != null)
                                {
                                    Attachments attch = new Attachments();
                                    attch.fileId = getFileInfo.fileId;
                                    attch.fileName = getFileInfo.fileName;
                                    attch.fileSize = getFileInfo.fileSize;
                                    attch.fileType = getFileInfo.fileType;
                                    attch.RefNo = RefNo;
                                    attch.TrainerName = TrainerName;
                                    attch.TrainerCompanyID = TrainerCompanyID;
                                    attch.fileExtension = getFileInfo.fileExtension;
                                    attch.fileContent = getFileInfo.fileContent;
                                    attch.createdBy = getFileInfo.createdBy;
                                    attch.createdDate = DateTime.Now;
                                    context.T_Trainers_Attachments.Add(attch);
                                    context.SaveChanges();


                                    //Clear temp table - Newly Added - kalpna
                                    var items = context.T_Trainers_Temp_Pic_Attachments.ToList();
                                    foreach (var item in items)
                                    {
                                        context.T_Trainers_Temp_Pic_Attachments.Remove(item);
                                        context.SaveChanges();
                                    }
                                }

                                //Updating Pic ID
                                foreach (DataRow dr in dT1.Rows)
                                {
                                    Int32 RefNoID = Convert.ToInt32(dr["RefNo"]);

                                    var TrainersData = context.TrainingRecord.Where(w => w.RefNo == RefNoID).FirstOrDefault();
                                    if (TrainersData != null)
                                    {
                                        //TrainersData.RefNo = RefNo;
                                        TrainersData.TrainerPicFileId = getFileInfo.fileId;
                                        context.SaveChanges();
                                    }
                                }
                                

                                status.success = true;
                                status.message = "Updated successfully";
                            }
                        }
                    }
                
                catch (Exception ex)
                {
                    status.success = false;
                    Utility.Utility.LogException(ex);
                }
            }
            return status;
        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Delete Image To DataBase
        public ActionStatus DeleteImage(Guid fileId, Int32 RefNo, string TrainerName, Int32 TrainerCompanyID)
        {
            ActionStatus status = new ActionStatus();
            DataSet mDSTTS = new DataSet();
            using (var context = DataContext)
            {
                try
                {
                    var tempattach = context.T_Trainers_Temp_Pic_Attachments.Where(s => s.fileId == fileId).FirstOrDefault();
                    var attach = context.T_Trainers_Attachments.Where(s => s.fileId == fileId).FirstOrDefault();

                    mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin_PhotoUpload", TrainerCompanyID, TrainerName);


                    

                    if (tempattach != null)
                    {
                        context.T_Trainers_Temp_Pic_Attachments.Remove(tempattach);
                    }
                    else if (attach != null)
                    {
                        context.T_Trainers_Attachments.Remove(attach);
                        context.SaveChanges();
                    }

                    if (mDSTTS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDSTTS.Tables[0];
                        if (dT1.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dT1.Rows)
                            {
                                Int32 RefNoID = Convert.ToInt32(dr["RefNo"]);
                                var traineePhoto = context.TrainingRecord.Where(s => s.RefNo == RefNoID).FirstOrDefault();
                                if (traineePhoto != null)
                                {
                                    //traineePhoto.RefNo = RefNo;
                                    traineePhoto.TrainerPicFileId = null;
                                    context.SaveChanges();
                                }

                            }
                            
                        }
                    }

                    status.success = true;
                    status.message = "Deleted successfully";
                }

                catch (Exception ex)
                {
                    Utility.Utility.LogException(ex);
                }
                return status;
            }
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Check Training Name
        public ActionStatus CheckTrainingCompany(string TrainingCompanyName)
        {
            ActionStatus status = new ActionStatus();
            trainingCompanyL comList = new trainingCompanyL();
            try
            {
                using (var context = DataContext)
                {
                    DataSet mDS = mDB.ExecuteDataSet("SP_GetTrainingCompanyName");
                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[0];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            CompaniesList company = new CompaniesList();

                            company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                            if (!string.IsNullOrEmpty(company.CompanyName))
                            {
                                comList.companyName.Add(company.CompanyName);
                            }
                            if (comList.companyName.Contains(TrainingCompanyName))
                            {
                                status.success = true;
                            }
                            else
                            {
                                status.success = false;
                                status.message = "Training Company selected does not exist in the system";
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return status;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Check Trainer Name
        public ActionStatus CheckTrainerName(string trainingCompanyName, string trainerName)
        {
            ActionStatus status = new ActionStatus();
            using (var context = DataContext)
            {
                try
                {
                    var companyData = context.CompaniesList.Where(w => w.CompanyName == trainingCompanyName).FirstOrDefault();
                    if (companyData != null)
                    {
                        var tlist = context.TrainingRecord.Where(x => x.TrainerCompanyID == companyData.CompanyID && x.TrainerName == trainerName)
                          .GroupBy(x => x.TrainerName)
                          .Select(g => new { RefNo = g.Key, TrainerName = g.FirstOrDefault().TrainerName })
                          .ToList();

                        if (tlist.Count > 0)
                        { status.success = true; }
                        else
                        {
                            status.success = false;
                            status.message = "Please select trainer name from the list";
                        }
                    }

                }

                catch (Exception ex)
                {
                    Utility.Utility.LogException(ex);
                }
                return status;
            }
        }

        //created By:Ramya
        //Created On : 06-February-2015
        //Purpose    : Getting Quick Links List
        public List<QuickLinks> getQuickLinks(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder)
        {
            List<QuickLinks> objMembers = new List<QuickLinks>();
            try
            {
                searchText = string.IsNullOrEmpty(searchText) ? "" : searchText;
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "True")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                DataSet mDS = mDB.ExecuteDataSet("SP_GetLinkDetails", searchText, pageIndex, pageSize, sortColumn, sortOrder);
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        QuickLinks links = new QuickLinks();
                        links.SNo = Convert.ToInt16(dr["SNo"]);
                        links.Name = dr["Name"] == DBNull.Value ? "" : dr["Name"].ToString();
                        links.URL = dr["URL"] == DBNull.Value ? "" : dr["URL"].ToString();
                        links.Target = dr["Target"] == DBNull.Value ? "" : dr["Target"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            links.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(links);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //created By:Ramya
        //Created On : 06-February-2015
        //Purpose    : Export Links Summary
        public DataSet ExportLinksSummary(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_GetLinkDetails", searchText, 0, TotalRecords, sortColumn, sortOrder);
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //created By:Ramya
        //Created On : 06-February-2015
        //Purpose    : Get Links Data
        public QuickLinksDetails getLinkData(int SNo)
        {
            QuickLinksDetails objMembers = new QuickLinksDetails();
            try
            {
                List<QuickLinksDetails> objMembers1 = new List<QuickLinksDetails>();
                using (var context = DataContext)
                {
                    objMembers1 = context.T_QuickLinks.Where(w => w.SNo == SNo).ToList();
                    if (objMembers != null)
                    {
                        foreach (var item in objMembers1)
                        {
                            objMembers.SNo = item.SNo;
                            objMembers.Name = item.Name;
                            objMembers.URL = item.URL;
                            objMembers.Target = item.Target;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //created By:Ramya
        //Created On : 06-February-2015
        //Purpose    : Save Links
        public ActionStatus saveLinkDetails(QuickLinksDetails Linkdts)
        {
            ActionStatus objActionStatus = new ActionStatus();
            try
            {
                using (var context = DataContext)
                {
                    QuickLinksDetails quickLinks = new QuickLinksDetails();
                    var LinkData = context.T_QuickLinks.Where(w => w.SNo == Linkdts.SNo).FirstOrDefault();
                    if (LinkData == null)
                    {

                        quickLinks.SNo = Linkdts.SNo;
                        quickLinks.Name = Linkdts.Name;
                        quickLinks.URL = Linkdts.URL;
                        quickLinks.Target = Linkdts.Target;

                        context.T_QuickLinks.Add(quickLinks);
                        context.SaveChanges();
                        objActionStatus.success = true;
                        objActionStatus.message = "Saved successfully";
                    }

                    else
                    {
                        QuickLinksDetails QuickLinksGrid = context.T_QuickLinks.Find(Linkdts.SNo);
                        if (QuickLinksGrid != null)
                        {
                            QuickLinksGrid.SNo = Linkdts.SNo;
                            QuickLinksGrid.Name = Linkdts.Name;
                            QuickLinksGrid.URL = Linkdts.URL;
                            QuickLinksGrid.Target = Linkdts.Target;
                            context.SaveChanges();
                            objActionStatus.success = true;
                            objActionStatus.message = "Updated successfully";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objActionStatus;
        }

    }
}
