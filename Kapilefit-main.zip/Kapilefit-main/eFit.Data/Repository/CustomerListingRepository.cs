﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace OHES.eFit.Data.Repository
{

    public interface ICustomerListingRepository
    {
        //CustomerListing
        #region CustomerListingPages

        List<Distributors> getDistributors(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder);
        List<govtCompanies> getgovtCompanies(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder, string disName);
        List<PrivateCompanies> getPrivateCompanies(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder, string disName);
        List<PrivateCompanies> getDisPrivateCompanies(Int64 companyId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder);
        List<TrainersListDetails> getTrainersList(Int64 roleId, Int64 companyId, Int64 companyPriId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder);
        List<TraineesListDetails> getTraineesList(Int64 roleId, Int64 companyId, Int64 companyPriId, string trainerId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder);

        DataSet ExportDistributors(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExportCompanies(string searchText, Int64 TotalRecords, Int64 companyId, string sortColumn, string sortOrder);
        DataSet ExportTrainers(Int64 roleId, Int64 companyId, string searchText, Int64 TotalRecords, Int64 priCompanyId, string sortColumn, string sortOrder);
        DataSet ExportTrainees(Int64 roleId, Int64 companyId, string searchText, Int64 TotalRecords, Int64 priCompanyId, string trainerId, string sortColumn, string sortOrder);


        DataSet ExportPrivateCompanies(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder, string disName);
        DataSet ExportGovtCommpanies(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder, string disName);

        string GetDisName(Int32 Id);

        #endregion
    }

    public class CustomerListingRepository : RepositoryBase<eFitContext>, ICustomerListingRepository
    {
        private Database mDB;

        #region Constructor

        public CustomerListingRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }

        #endregion

        //Created By : Kalpana
        //Created On : 28-January-2015
        //Purpose    : Getting Distributors Details
        public List<Distributors> getDistributors(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder)
        {
            List<Distributors> objMembers = new List<Distributors>();
            try
            {
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "True")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }

                DataSet mDS = mDB.ExecuteDataSet("SP_GetCompanyDetails", companyTypeId, pageIndex, pageSize, searchText, sortColumn, sortOrder);
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        Distributors distributors = new Distributors();
                        distributors.CompanyID = Convert.ToInt32(dr["CompanyID"]);
                        distributors.CompanyName = dr["DistributorName"] == DBNull.Value ? "" : dr["DistributorName"].ToString();
                        distributors.ContactDesignation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        distributors.ContactNumber = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        distributors.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        distributors.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                        distributors.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            distributors.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(distributors);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created on : 05-02-2015
        //purpose    : Getting Distributors PrivateCompanies Details
        public List<PrivateCompanies> getDisPrivateCompanies(Int64 companyId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder)
        {
            List<PrivateCompanies> objMembers = new List<PrivateCompanies>();
            try
            {
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "True")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                DataSet mDS = mDB.ExecuteDataSet("SP_GetCompanyInfo", companyId, pageIndex, pageSize, searchText, sortColumn, sortOrder);
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        PrivateCompanies privateCompanies = new PrivateCompanies();
                        privateCompanies.CompanyID = Convert.ToInt64(dr["CompanyID"]);
                        privateCompanies.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        privateCompanies.ContactDesignation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        privateCompanies.ContactNumber = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        privateCompanies.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        privateCompanies.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                        privateCompanies.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                        privateCompanies.DistributorName = dr["DistributorName"] == DBNull.Value ? "" : dr["DistributorName"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            privateCompanies.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(privateCompanies);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created on : 05-02-2015
        //purpose    : Getting Trainers Details
        public List<TrainersListDetails> getTrainersList(Int64 roleId, Int64 companyId, Int64 companyPriId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder)
        {
            List<TrainersListDetails> objMembers = new List<TrainersListDetails>();
            TrainersListDetails trainersListOut = new TrainersListDetails();
            int a_count = 0;
            try
            {
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "True")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                DataSet mDS = mDB.ExecuteDataSet("SP_GetTrainers",roleId, companyId,companyPriId, pageIndex, pageSize, searchText, sortColumn, sortOrder);
                if (mDS.Tables.Count > 0)
                {

                        DataTable accessCountTbl = mDS.Tables[2];
                        foreach (DataRow drC in accessCountTbl.Rows)
                        {
                            a_count = Convert.ToInt32(drC["C_Exist_Count"]);
                        }
                        if(a_count != 0)
                        {
                        DataTable dT1 = mDS.Tables[0];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            TrainersListDetails trainersList = new TrainersListDetails();
                            trainersList.CompanyID = Convert.ToInt64(dr["CompanyID"]);
                            trainersList.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                            trainersList.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                            trainersList.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                            trainersList.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                            trainersList.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                            trainersList.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                            trainersList.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                            trainersList.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                            trainersList.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                            trainersList.TrainerCompany = dr["TrainerCompany"] == DBNull.Value ? "" : dr["TrainerCompany"].ToString();
                            trainersList.TrainingType = dr["TrainingType"] == DBNull.Value ? "" : dr["TrainingType"].ToString();
                            trainersList.TopicsCovered = dr["TopicsCovered"] == DBNull.Value ? "" : dr["TopicsCovered"].ToString();
                            trainersList.TrainingCompany = dr["TrainingCompany"] == DBNull.Value ? "" : dr["TrainingCompany"].ToString();
                            trainersList.counting = dr["counting"] == DBNull.Value ? "" : dr["counting"].ToString();
                            trainersList.access = true;
                            DataTable dT2 = mDS.Tables[1];
                            foreach (DataRow dr2 in dT2.Rows)
                            {
                                trainersList.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                            }
                            objMembers.Add(trainersList);
                        }
                    }
                    else
                    {
                        trainersListOut.access = false;
                        objMembers.Add(trainersListOut);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created on : 05-02-2015
        //purpose    : Getting Trainees Details
        public List<TraineesListDetails> getTraineesList(Int64 roleId, Int64 companyId, Int64 companyPriId, string trainerId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder)
        {
            List<TraineesListDetails> objMembers = new List<TraineesListDetails>();
            TraineesListDetails trainersListOut = new TraineesListDetails();
            int a_count = 0;
            try
            {
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "True")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                DataSet mDS = mDB.ExecuteDataSet("SP_GetTraineeList",roleId,companyId, companyPriId, trainerId, pageIndex, pageSize, searchText, sortColumn, sortOrder);

               

                if (mDS.Tables.Count > 0)
                {

                    DataTable accessCountTbl = mDS.Tables[2];
                    foreach (DataRow drC in accessCountTbl.Rows)
                    {
                        a_count = Convert.ToInt32(drC["C_Exist_Count"]);
                    }

                    //if (a_count != 0)
                    //{
                        DataTable dT1 = mDS.Tables[0];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            TraineesListDetails traineesList = new TraineesListDetails();
                            traineesList.CompanyID = Convert.ToInt64(dr["CompanyID"]);
                            traineesList.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                            traineesList.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                            traineesList.CompanyType = dr["CompanyType"] == DBNull.Value ? "" : dr["CompanyType"].ToString();
                            traineesList.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                            traineesList.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                            traineesList.Cmp_ContactPerson = dr["Cmp_ContactPerson"] == DBNull.Value ? "" : dr["Cmp_ContactPerson"].ToString();
                            traineesList.Cmp_Designation = dr["Cmp_Designation"] == DBNull.Value ? "" : dr["Cmp_Designation"].ToString();
                            traineesList.Cmp_ContactNo = dr["Cmp_ContactNo"] == DBNull.Value ? "" : dr["Cmp_ContactNo"].ToString();
                            traineesList.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                            traineesList.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                            traineesList.TrainerCompany = dr["TrainerCompany"] == DBNull.Value ? "" : dr["TrainerCompany"].ToString();
                            traineesList.TrainingType = dr["TrainingType"] == DBNull.Value ? "" : dr["TrainingType"].ToString();
                            traineesList.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                            traineesList.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                            traineesList.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                            traineesList.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                            traineesList.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                            traineesList.Outcome = dr["Outcome"] == DBNull.Value ? "" : dr["Outcome"].ToString();
                            traineesList.TopicsCovered = dr["TopicsCovered"] == DBNull.Value ? "" : dr["TopicsCovered"].ToString();
                            traineesList.Email = dr["Email"] == DBNull.Value ? "" : dr["Email"].ToString();
                            traineesList.access = true;
                            DataTable dT2 = mDS.Tables[1];
                            foreach (DataRow dr2 in dT2.Rows)
                            {
                                traineesList.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                            }
                            objMembers.Add(traineesList);
                        }
                    //}
                    //else
                    //{
                    //    trainersListOut.access = false;
                    //    objMembers.Add(trainersListOut);
                    //}

                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Ramya
        //Created on : 05-02-2015
        //purpose    : Getting GovtCompanies Details
        public List<govtCompanies> getgovtCompanies(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder, string disName)
        {
            List<govtCompanies> objMembers = new List<govtCompanies>();
            DataSet mDS;
            try
            {
                using (var context = DataContext)
                {
                    if (searchText == "null")
                    { searchText = ""; }
                    if (sortOrder == "True")
                    { sortOrder = "Asc"; }
                    else { sortOrder = "Desc"; }
                    var companyId = context.CompaniesList.Where(w => w.CompanyName == disName).Select(s => s).FirstOrDefault();

                    if (disName !="3M Technologies (S) Pte Ltd")
                    {

                        mDS = mDB.ExecuteDataSet("SP_GetCompanyInfoGovt", companyId.CompanyID, pageIndex, pageSize, searchText, sortColumn, sortOrder);
                        if (mDS.Tables.Count > 0)
                        {
                            DataTable dT1 = mDS.Tables[0];
                            foreach (DataRow dr in dT1.Rows)
                            {
                                govtCompanies govtcompanies = new govtCompanies();
                                govtcompanies.CompanyID = Convert.ToInt64(dr["CompanyID"]);
                                govtcompanies.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                                govtcompanies.ContactDesignation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                                govtcompanies.ContactNumber = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                                govtcompanies.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                                govtcompanies.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                                govtcompanies.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                                govtcompanies.DistributorName = dr["DistributorName"] == DBNull.Value ? "" : dr["DistributorName"].ToString();
                                DataTable dT2 = mDS.Tables[1];
                                foreach (DataRow dr2 in dT2.Rows)
                                {
                                    govtcompanies.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                                }
                                objMembers.Add(govtcompanies);
                            }
                        }
                    }
                    else
                    {
                        mDS = mDB.ExecuteDataSet("SP_GetCompanyDetails", companyTypeId, pageIndex, pageSize, searchText, sortColumn, sortOrder);
                        if (mDS.Tables.Count > 0)
                        {
                            DataTable dT1 = mDS.Tables[0];
                            foreach (DataRow dr in dT1.Rows)
                            {
                                govtCompanies govtcompanies = new govtCompanies();
                                govtcompanies.CompanyID = Convert.ToInt64(dr["CompanyID"]);
                                govtcompanies.CompanyName = dr["DistributorName"] == DBNull.Value ? "" : dr["DistributorName"].ToString();
                                govtcompanies.ContactDesignation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                                govtcompanies.ContactNumber = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                                govtcompanies.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                                govtcompanies.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                                govtcompanies.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                                govtcompanies.DistributorName = dr["DistributorNames"] == DBNull.Value ? "" : dr["DistributorNames"].ToString();
                                DataTable dT2 = mDS.Tables[1];
                                foreach (DataRow dr2 in dT2.Rows)
                                {
                                    govtcompanies.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                                }
                                objMembers.Add(govtcompanies);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Ramya
        //Created on : 05-02-2015
        //purpose    : Getting PrivateCompanies Details
        public List<PrivateCompanies> getPrivateCompanies(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder, string disName)
        {
            List<PrivateCompanies> objMembers = new List<PrivateCompanies>();
            DataSet mDS;
            try
            {
                using (var context = DataContext)
                {
                    if (searchText == "null")
                    { searchText = ""; }
                    if (sortOrder == "True")
                    { sortOrder = "Asc"; }
                    else { sortOrder = "Desc"; }

                    var companyId = context.CompaniesList.Where(w => w.CompanyName == disName).Select(s => s).FirstOrDefault();
                    if (disName != "3M Technologies (S) Pte Ltd")
                    {

                        mDS = mDB.ExecuteDataSet("SP_GetCompanyInfoPrivate", companyId.CompanyID, pageIndex, pageSize, searchText, sortColumn, sortOrder);
                        if (mDS.Tables.Count > 0)
                        {
                            DataTable dT1 = mDS.Tables[0];
                            foreach (DataRow dr in dT1.Rows)
                            {
                                PrivateCompanies privateCompanies = new PrivateCompanies();
                                privateCompanies.CompanyID = Convert.ToInt64(dr["CompanyID"]);
                                privateCompanies.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                                privateCompanies.ContactDesignation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                                privateCompanies.ContactNumber = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                                privateCompanies.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                                privateCompanies.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                                privateCompanies.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                                privateCompanies.DistributorName = dr["DistributorName"] == DBNull.Value ? "" : dr["DistributorName"].ToString();
                                DataTable dT2 = mDS.Tables[1];
                                foreach (DataRow dr2 in dT2.Rows)
                                {
                                    privateCompanies.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                                }
                                objMembers.Add(privateCompanies);
                            }
                        }
                    }
                    else
                    { 
                        mDS = mDB.ExecuteDataSet("SP_GetCompanyDetails", companyTypeId, pageIndex, pageSize, searchText, sortColumn, sortOrder);
                        if (mDS.Tables.Count > 0)
                        {
                            DataTable dT1 = mDS.Tables[0];
                            foreach (DataRow dr in dT1.Rows)
                            {
                                PrivateCompanies privateCompanies = new PrivateCompanies();
                                privateCompanies.CompanyID = Convert.ToInt64(dr["CompanyID"]);
                                privateCompanies.CompanyName = dr["DistributorName"] == DBNull.Value ? "" : dr["DistributorName"].ToString();
                                privateCompanies.ContactDesignation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                                privateCompanies.ContactNumber = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                                privateCompanies.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                                privateCompanies.Address = dr["Address"] == DBNull.Value ? "" : dr["Address"].ToString();
                                privateCompanies.PostalCode = dr["PostalCode"] == DBNull.Value ? "" : dr["PostalCode"].ToString();
                                privateCompanies.DistributorName = dr["DistributorNames"] == DBNull.Value ? "" : dr["DistributorNames"].ToString();
                                DataTable dT2 = mDS.Tables[1];
                                foreach (DataRow dr2 in dT2.Rows)
                                {
                                    privateCompanies.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                                }
                                objMembers.Add(privateCompanies);
                            }
                        }
                    }

                    
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export Distributors Details
        public DataSet ExportDistributors(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_GetCompanyDetails", 3, 0, TotalRecords, searchText, sortColumn, sortOrder);
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Export Companies Details
        public DataSet ExportCompanies(string searchText, Int64 TotalRecords, Int64 companyId, string sortColumn, string sortOrder)
        {

            DataSet mDSTTS = new DataSet();
            try
            {
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_GetCompanyInfo", companyId, 0, TotalRecords, searchText, sortColumn, sortOrder);
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Export Trainers Details
        public DataSet ExportTrainers(Int64 roleId, Int64 companyId, string searchText, Int64 TotalRecords, Int64 priCompanyId, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    
                    mDSTTS = mDB.ExecuteDataSet("SP_GetTrainers", roleId, companyId,priCompanyId, 0, TotalRecords, searchText, sortColumn, sortOrder);
                   
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 24-February-2015
        //Purpose    : Export Trainees Details
        public DataSet ExportTrainees(Int64 roleId, Int64 companyId, string searchText, Int64 TotalRecords, Int64 priCompanyId, string trainerId, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_GetTraineeList", roleId, companyId, priCompanyId, trainerId, 0, TotalRecords, searchText, sortColumn, sortOrder);
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export Private Details
        public DataSet ExportPrivateCompanies(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder, string disName)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    var companyId = context.CompaniesList.Where(w => w.CompanyName == disName).Select(s => s).FirstOrDefault();
                    if (disName != "3M Technologies (S) Pte Ltd")
                    {

                        mDSTTS = mDB.ExecuteDataSet("SP_GetCompanyInfoPrivate", companyId.CompanyID, 0, TotalRecords, searchText, sortColumn, sortOrder);
                    }
                    else
                    {

                        mDSTTS = mDB.ExecuteDataSet("SP_GetCompanyDetails", 2, 0, TotalRecords, searchText, sortColumn, sortOrder);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export Govt Details
        public DataSet ExportGovtCommpanies(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder, string disName)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                     var companyId = context.CompaniesList.Where(w => w.CompanyName == disName).Select(s => s).FirstOrDefault();

                     if (disName != "3M Technologies (S) Pte Ltd")
                     {

                         mDSTTS = mDB.ExecuteDataSet("SP_GetCompanyInfoGovt", companyId.CompanyID, 0, TotalRecords, searchText, sortColumn, sortOrder);
                     }
                     else
                     {

                         mDSTTS = mDB.ExecuteDataSet("SP_GetCompanyDetails", 4, 0, TotalRecords, searchText, sortColumn, sortOrder);
                     }

                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Get Distributor Name
        public string GetDisName(Int32 Id)
        {
            string disName = string.Empty;
            try
            {
                using (var context = DataContext)
                {
                    var com = context.CompaniesList.Where(x => x.CompanyID == Id).FirstOrDefault();

                    if (com != null)
                    {
                        disName = com.CompanyName;
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return disName;
        }
    }
}






