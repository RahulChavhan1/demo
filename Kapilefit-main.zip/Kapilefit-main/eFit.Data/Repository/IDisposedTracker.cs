﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OHES.eFit.Data.Repository
{
    public interface IDisposedTracker
    {
        bool IsDisposed { get; set; }
    }
}
