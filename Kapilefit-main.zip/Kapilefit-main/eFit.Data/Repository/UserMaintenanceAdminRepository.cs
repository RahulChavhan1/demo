﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace OHES.eFit.Data.Repository
{


    public interface IUserMaintenanceAdminRepository
    {
        //CustomerListing
        #region CustomerListingPages

        List<UserVM> getUsers(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder);
        ActionStatus saveUser(UserVM userDetails);
        ActionStatus PasswordUpdate(PasswordDetails userDetails);
        User getUsersData(string UserID);
        List<Role> getRoleList(string roleID);
        DataSet ExportUserSummary(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder);
        Users getUserName();
        ActionStatus CheckCompanyName(string CompanyName);
        ActionStatus ResetPwd(string UserID);
        ActionStatus deleteUser(string UserID);
        companyL getCompaniesList(int companyTypeId);
        companyL getCompaniesListUser(int companyTypeId);
        #endregion

    }


    public class UserMaintenanceAdminRepository : RepositoryBase<eFitContext>, IUserMaintenanceAdminRepository
    {
        private Database mDB;

        #region Constructor

        public UserMaintenanceAdminRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }
        #endregion

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get User Name
        public Users getUserName()
        {
            Users users = new Users();
            try
            {
                using (var context = DataContext)
                {
                    var userlist = context.Users.ToList();
                    foreach (var single in userlist)
                    {
                        users.UserName.Add(single.UserName);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }

            return users;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get Role List
        public List<Role> getRoleList(string roleID)
        {
            List<Role> roleList = new List<Role>();
            try
            {
                using (var context = DataContext)
                {
                    var rList = context.Roles.Select(s => new
                    {
                        s.RoleID,
                        s.RoleName
                    }).OrderBy(o => o.RoleID).ToList();
                    foreach (var item in rList)
                    {
                        Role roleItem = new Role();

                        roleItem.RoleName = item.RoleName.Contains("\r\n") ? item.RoleName.Replace("\r\n", "") : item.RoleName;
                        roleItem.RoleID = item.RoleID;
                        roleList.Add(roleItem);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return roleList;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get Companies List
        public companyL getCompaniesListUser(int companyTypeId)
        {
            companyL comList = new companyL();
            try
            {
                using (var context = DataContext)
                {

                    if (companyTypeId == 4)
                    {
                        var cList = context.CompaniesList.Where(x => x.CompanyTypeID == 2 || x.CompanyTypeID == 4)
                          .GroupBy(x => x.CompanyName)
                          .Select(g => new { CompanyName = g.Key, CompanyID = g.FirstOrDefault().CompanyID })
                          .ToList();
                        foreach (var item in cList)
                        {
                            if (item.CompanyName != "" && item.CompanyName != null)
                            {
                                comList.companyName.Add(item.CompanyName);
                            }
                        }
                    }

                    else
                    {
                        var cList = context.CompaniesList.Where(x => x.CompanyTypeID == companyTypeId)
                           .GroupBy(x => x.CompanyName)
                           .Select(g => new { CompanyName = g.Key, CompanyID = g.FirstOrDefault().CompanyID })
                           .ToList();
                        foreach (var item in cList)
                        {
                            if (item.CompanyName != "" && item.CompanyName != null)
                            {
                                comList.companyName.Add(item.CompanyName);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get Companies List
        public companyL getCompaniesList(int companyTypeId)
        {
            companyL comList = new companyL();
            try
            {
                using (var context = DataContext)
                {

                        var cList = context.CompaniesList.Where(x => x.CompanyTypeID == companyTypeId)
                          .GroupBy(x => x.CompanyName)
                          .Select(g => new { CompanyName = g.Key, CompanyID = g.FirstOrDefault().CompanyID })
                          .ToList();
                        foreach (var item in cList)
                        {
                            if (item.CompanyName != "" && item.CompanyName != null)
                            {
                                comList.companyName.Add(item.CompanyName);
                            }
                        }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get User List
        public List<UserVM> getUsers(Int64 companyTypeId, string searchText, Int64 pageSize, Int64 pageIndex, String sortColumn, string sortOrder)
        {
            List<UserVM> objMembers = new List<UserVM>();
            try
            {
                searchText = string.IsNullOrEmpty(searchText) ? "" : searchText;
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "True")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                DataSet mDS = mDB.ExecuteDataSet("SP_GetUserDetails", searchText, pageIndex, pageSize, sortColumn, sortOrder);
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        UserVM users = new UserVM();
                        users.UserID = dr["UserID"] == DBNull.Value ? "" : dr["UserID"].ToString();
                        users.UserName = dr["UserName"] == DBNull.Value ? "" : dr["UserName"].ToString();
                        users.Password = dr["Password"] == DBNull.Value ? "" : dr["Password"].ToString();
                        users.EmailID = dr["EmailID"] == DBNull.Value ? "" : dr["EmailID"].ToString();
                        users.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            users.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(users);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Get Particular User Data
        public User getUsersData(string userID)
        {
            User objMembers = new User();
            try
            {
                List<User> objMembers1 = new List<User>();
                using (var context = DataContext)
                {
                    objMembers1 = context.Users.Where(w => w.UserID == userID).ToList();
                    if (objMembers != null)
                    {
                        foreach (var item in objMembers1)
                        {
                            objMembers.CompanyID = item.CompanyID;
                            objMembers.UserID = item.UserID;
                            objMembers.UserName = item.UserName;
                            objMembers.EmailID = item.EmailID;
                            objMembers.RoleID = item.RoleID;
                            objMembers.CompanyName = item.CompanyName;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Save User
        public ActionStatus saveUser(UserVM userD)
        {
            ActionStatus objActionStatus = new ActionStatus();
            try
            {
                using (var context = DataContext)
                {
                    User user = new User();
                    var userData = context.Users.Where(w => w.UserID == userD.UserID).FirstOrDefault();
                    var userDataExists = context.Users.Where(w => w.UserID == userD.UserName).FirstOrDefault();
                    string encPwd = string.Empty;
                    if (userData == null)
                    {
                        if (userDataExists == null)
                        {
                            user.UserID = userD.UserID;
                            user.UserName = userD.UserName;

                            var companyDetails = context.CompaniesList.Where(x => x.CompanyName == userD.CompanyName).FirstOrDefault();
                            user.CompanyID = companyDetails.CompanyID;
                            user.EmailID = userD.EmailID;
                            
                            user.RoleID = userD.RoleID;
                            user.Locked = userD.Locked;
                            user.UpdatedBy = "Admin";
                            user.UpdatedDate = DateTime.Now;
                            user.CompanyName = userD.CompanyName;
                            context.Users.Add(user);
                            context.SaveChanges();
                            objActionStatus.success = true;
                            objActionStatus.message = "Saved successfully";
                        }
                        else
                        {
                            objActionStatus.message = "UserName already exists";
                        }
                    }
                    else
                    {
                        User usergrid = context.Users.Find(userD.UserID);
                        if (usergrid != null)
                        {
                            usergrid.UserName = userD.UserName;

                            var companyDetails = context.CompaniesList.Where(x => x.CompanyName == userD.CompanyName).FirstOrDefault();

                            usergrid.CompanyID = companyDetails.CompanyID;
                          
                            usergrid.EmailID = userD.EmailID;
                            usergrid.RoleID = userD.RoleID;
                            usergrid.Locked = userD.Locked;
                            usergrid.UpdatedDate = DateTime.Now;
                            usergrid.CompanyName = userD.CompanyName;
                            context.SaveChanges();
                            objActionStatus.success = true;
                            objActionStatus.message = "Updated successfully";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objActionStatus;
        }

        //Created By : Kalpana
        //Created On : 18-June-2015
        //Purpose    : Delete User
        public ActionStatus deleteUser(string userID)
        {
            ActionStatus objActionStatus = new ActionStatus();
            try
            {


                using (var context = DataContext)
                {
                    var userData = context.Users.Where(w => w.UserID == userID).FirstOrDefault();
                    if (userData != null)
                    {
                        //Back up The User Data
                        User_Deleted userDelete = new User_Deleted();
                        userDelete.UserID = userData.UserName;
                        userDelete.UserName = userData.UserName;

                        var companyDetails = context.CompaniesList.Where(x => x.CompanyName == userData.CompanyName).FirstOrDefault();
                        userDelete.CompanyID = companyDetails.CompanyID;
                        userDelete.EmailID = userData.EmailID;
                        //encPwd = Encryptdata(userD.Password);
                        userDelete.RoleID = userData.RoleID;

                        userDelete.DeletedBy = "Admin";
                        userDelete.DeletedOn = DateTime.Now;

                        context.UsersDeleted.Add(userDelete);
                        context.SaveChanges();

                        context.Users.Remove(userData);
                        context.SaveChanges();
                        objActionStatus.success = true;
                        objActionStatus.message = "Deleted successfully";
                    }

                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }


            return objActionStatus;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Upadate Password
        public ActionStatus PasswordUpdate(PasswordDetails userD)
        {
            ActionStatus objActionStatus = new ActionStatus();
            try
            {
                using (var context = DataContext)
                {
                    User user = new User();
                    var userData = context.Users.Where(w => w.UserID == userD.UserID).FirstOrDefault();
                    if (userData == null)
                    {

                    }
                    else
                    {
                        User usergrid = context.Users.Find(userD.UserID);
                        if (usergrid != null)
                        {
                            if (Decryptdata(usergrid.Password) == userD.OldPassword)
                            {
                                usergrid.Password = Encryptdata(userD.NewPassword);
                                context.SaveChanges();
                                objActionStatus.success = true;
                                objActionStatus.message = "Password updated successfully";
                            }
                            else
                            {
                                objActionStatus.success = false;
                                objActionStatus.message = "Old password is incorrect";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objActionStatus;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Export User List
        public DataSet ExportUserSummary(string searchText, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_GetUserDetails", searchText, 0, TotalRecords, sortColumn, sortOrder);
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Check Company Name
        public ActionStatus CheckCompanyName(string CompanyName)
        {
            ActionStatus status = new ActionStatus();

            using (var context = DataContext)
            {
                try
                {

                    var cList = context.CompaniesList.Where(w => w.CompanyName == CompanyName).ToList();

                    if (cList.Count > 0)
                    { status.success = true; }
                    else
                    {
                        status.success = false;
                        status.message = "Training Company selected does not exist in the system";
                    }

                }

                catch (Exception ex)
                {
                    Utility.Utility.LogException(ex);
                }

                return status;
            }
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Reset Password
        public ActionStatus ResetPwd(string UserID)
        {
            ActionStatus status = new ActionStatus();
            using (var context = DataContext)
            {
                try
                {
                    string allowedChars = "";
                    allowedChars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,";
                    allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";
                    allowedChars += "1,2,3,4,5,6,7,8,9,0,!,@,#,$,%,&,?";
                    char[] sep = { ',' };
                    string[] arr = allowedChars.Split(sep);
                    string passwordString = "";
                    string temp = "";
                    Random rand = new Random();
                    for (int i = 0; i < Convert.ToInt32(8); i++)
                    {
                        temp = arr[rand.Next(0, arr.Length)];
                        passwordString += temp;
                    }
                    status.key = passwordString;
                }

                catch (Exception ex)
                {
                    Utility.Utility.LogException(ex);
                }
                return status;
            }
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Encrypting Pwd
        private string Encryptdata(string password)
        {
            string strmsg = string.Empty;
            try
            {
                byte[] encode = new byte[password.Length];
                encode = Encoding.UTF32.GetBytes(password);
                strmsg = Convert.ToBase64String(encode);
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return strmsg;
        }

        //Created By : Kalpana
        //Created On : 24-March-2015
        //Purpose    : Decrypt Pwd
        private string Decryptdata(string encryptpwd)
        {
            string decryptpwd = string.Empty;
            try
            {
                UTF32Encoding encodepwd = new UTF32Encoding();
                Decoder Decode = encodepwd.GetDecoder();
                byte[] todecode_byte = Convert.FromBase64String(encryptpwd);
                int charCount = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                char[] decoded_char = new char[charCount];
                Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
                decryptpwd = new String(decoded_char);
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return decryptpwd;
        }

    }
}
