﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace OHES.eFit.Data.Repository
{
    public interface IStatusInquiryRepository
    {
        //CustomerListing
        #region StatusInquiryRepository

        List<traineeList> getTraineeList(string CompanyName, int companyTypeID, string TraineeName, string NRIC, string searchText, Int64 pageIndex, Int64 pageSize, String sortColumn, string sortOrder);
        List<trainerListPC> getTrainerListPC(string CompanyName, int companyTypeID, string TrainerName, string NRIC, string searchText, Int64 pageIndex, Int64 pageSize, String sortColumn, string sortOrder);
        DataSet ExporttraineeList(string CompanyName, int companyTypeID, string searchText, string Name, string NRIC, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExporttrainerList(string searchText, Int64 TotalRecords, string CompanyName);
        DataSet ExporttrainerListPC(string CompanyName, int companyTypeID, string searchText, string Name, string NRIC, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExportAdmintrainerList(string searchText, Int64 TotalRecords, string CompanyName, string TrainingDate, string sortColumn, string sortOrder);
        DataSet ExportAdmintrainerSummary(string CompanyName, string TrainingDate, int tTID, string searchText, Int64 TotalRecords, string sortColumn, string sortOrder);
        TraineeList getTraineeName(int companyTypeId);
        TrainerList getTrainerName(int companyTypeId);
        List<trainerList> getActiveTrainers(InputDetails tDatas);
        #endregion

    }
    public class StatusInquiryRepository : RepositoryBase<eFitContext>, IStatusInquiryRepository
    {
        private Database mDB;

        #region Constructor

        public StatusInquiryRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }

        #endregion

        //Created By : Ramya
        //Created on : 07-02-2015
        //purpose    : Get Trainee Name List
        public TraineeList getTraineeName(int companyTypeId)
        {
            TraineeList traineeList = new TraineeList();
            try{
            string name = string.Empty;
            using (var context = DataContext)
            {
                DataSet mDS = mDB.ExecuteDataSet("SP_GetTraineeName");
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        name = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                        if (name != null && name != "")
                        {
                            traineeList.TraineeName.Add(name);
                        }
                    }
                }
                
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return traineeList;
        }

        //Created By : Ramya
        //Created on : 07-02-2015
        //purpose    : Get Trainer Name List
        public TrainerList getTrainerName(int companyTypeId)
        {
            TrainerList trainerList = new TrainerList();
            try{
            string name = string.Empty;
            using (var context = DataContext)
            {
                DataSet mDS = mDB.ExecuteDataSet("SP_GetTrainerName");
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        name = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        if (name != null && name != "")
                        {
                            trainerList.TrainerName.Add(name);
                            
                        }
                    }
                }
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return trainerList;
        }

        //Created By : Ramya
        //Created on : 07-02-2015
        //purpose    : Getting traineeList Details
        public List<traineeList> getTraineeList(string CompanyName, int companyTypeID, string Name, string NRIC, string searchText, Int64 pageIndex, Int64 pageSize, String sortColumn, string sortOrder)
        {
            List<traineeList> objMembers = new List<traineeList>();
            try{
            DataSet mDS;
            if (searchText == "null")
            { searchText = ""; }
            if (Name == "null")
            { Name = ""; }
            if (sortOrder == "True")
            { sortOrder = "Asc"; }
            else { sortOrder = "Desc"; }
            if (NRIC == "null")
            { NRIC = ""; }

            if (companyTypeID == 3 )
            {
                mDS = mDB.ExecuteDataSet("SP_GetTraineesListPC", CompanyName, Name, NRIC, pageIndex, pageSize, searchText, sortColumn, sortOrder, "1");
            }
            else
            {
                mDS = mDB.ExecuteDataSet("SP_GetTraineesList", CompanyName, NRIC, pageIndex, pageSize, searchText, sortColumn, sortOrder);
            }
          
            
            if (mDS.Tables.Count > 0)
            {
                DataTable dT1 = mDS.Tables[0];
                foreach (DataRow dr in dT1.Rows)
                {
                    traineeList TraineeList = new traineeList();
                    TraineeList.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                    TraineeList.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                    TraineeList.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                    TraineeList.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                    TraineeList.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                    TraineeList.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                    TraineeList.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                    TraineeList.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                    TraineeList.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                    TraineeList.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                    TraineeList.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                    DataTable dT2 = mDS.Tables[1];
                    foreach (DataRow dr2 in dT2.Rows)
                    {
                        TraineeList.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                    }
                    objMembers.Add(TraineeList);
                }
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Ramya
        //Created on : 07-02-2015
        //purpose    : Getting Trainer List Details
        public List<trainerListPC> getTrainerListPC(string CompanyName, int companyTypeID, string Name, string NRIC, string searchText, Int64 pageIndex, Int64 pageSize, String sortColumn, string sortOrder)
        {
            List<trainerListPC> objMembers = new List<trainerListPC>();
            try{
            DataSet mDS;
            if (searchText == "null")
            { searchText = ""; }
            if (Name == "null")
            { Name = ""; }
            if (sortOrder == "True")
            { sortOrder = "Asc"; }
            else { sortOrder = "Desc"; }
            if (NRIC == "null")
            { NRIC = ""; }

            if (companyTypeID > 1 )
            {
                mDS = mDB.ExecuteDataSet("SP_GetTrainersListPC", CompanyName, Name, NRIC, pageIndex, pageSize, searchText, sortColumn, sortOrder, "1");
            }
            else
            {
                mDS = mDB.ExecuteDataSet("SP_GetTrainersList", Name, NRIC, pageIndex, pageSize, searchText, sortColumn, sortOrder, "1");
            }

            
            if (mDS.Tables.Count > 0)
            {
                DataTable dT1 = mDS.Tables[0];
                foreach (DataRow dr in dT1.Rows)
                {
                    trainerListPC TrainerList = new trainerListPC();
                    TrainerList.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                    TrainerList.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                    TrainerList.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                    TrainerList.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                    TrainerList.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                    TrainerList.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                    TrainerList.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                    TrainerList.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                    TrainerList.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                    TrainerList.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                    TrainerList.TrainerPicField = dr["TrainerPicFileId"] == DBNull.Value ? "" : dr["TrainerPicFileId"].ToString();
                    TrainerList.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                    DataTable dT2 = mDS.Tables[1];
                    foreach (DataRow dr2 in dT2.Rows)
                    {
                        TrainerList.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                    }
                    objMembers.Add(TrainerList);
                }
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;

        }
      
        //Created By : Kalpana  
        //Created on : 25-02-2015
        //purpose    : Getting Active Trainers Details
        public List<trainerList> getActiveTrainers(InputDetails tDatas)
        {
            List<trainerList> objMembers = new List<trainerList>();
            try{
            string dayT, monT, yearT, Tdate;
            if (tDatas.searchText == null)
            { tDatas.searchText = ""; }
            if (tDatas.sortOrder == "True")
            { tDatas.sortOrder = "Asc"; }
            else { tDatas.sortOrder = "Desc"; }
            if (tDatas.trainingDate != null && tDatas.trainingDate != "")
            {
                string[] words = tDatas.trainingDate.Split('-');
                dayT = words[0];
                monT = MonthConvert(words[1]);
                yearT = words[2];
                Tdate = yearT + monT + dayT;
            }
            else
            { Tdate = ""; }
            using (var context = DataContext)
            {
                DataSet mDS = mDB.ExecuteDataSet("SP_GetTrainerListing", tDatas.searchText, tDatas.pageIndex, tDatas.pageSize, tDatas.sortColumn, tDatas.sortOrder, tDatas.companyName, Tdate);
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        trainerList TrainerList = new trainerList();
                        TrainerList.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        TrainerList.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString(); ;
                        TrainerList.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        TrainerList.TopicsCovered = dr["TopicsCovered"] == DBNull.Value ? "" : dr["TopicsCovered"].ToString();
                        TrainerList.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        
                        TrainerList.TrainerCompanyName = dr["TrainerCompanyName"] == DBNull.Value ? "" : dr["TrainerCompanyName"].ToString();
                        TrainerList.Email = dr["Email"] == DBNull.Value ? "" : dr["Email"].ToString();
                        TrainerList.TrainingTypeID = dr["TrainingTypeID"] == DBNull.Value ? "" : dr["TrainingTypeID"].ToString();
                        TrainerList.TrainingTypeName = dr["TrainingType"] == DBNull.Value ? "" : dr["TrainingType"].ToString();
                        
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            TrainerList.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(TrainerList);
                    }
                }
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana  
        //Created on : 25-02-2015
        //purpose    : Export Trainee List
        public DataSet ExporttraineeList(string CompanyName, int companyTypeID, string searchText, string Name, string NRIC, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                if (searchText == "null")
                { searchText = ""; }
                if (Name == "null")
                { Name = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                if (NRIC == "null")
                { NRIC = ""; }
                using (var context = DataContext)
                {
                    if (companyTypeID == 3)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetTraineesListPC", CompanyName, Name, NRIC, 0, TotalRecords, searchText, sortColumn, sortOrder, "1");
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetTraineesList", CompanyName, NRIC, 0, TotalRecords, searchText, sortColumn, sortOrder);
                    }

                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana  
        //Created on : 25-02-2015
        //purpose    : Export Trainer List
        public DataSet ExporttrainerList(string searchText, Int64 TotalRecords, string CompanyName)
        {
            DataSet mDSTTS = new DataSet();
            try{
            using (var context = DataContext)
            {
                mDSTTS = mDB.ExecuteDataSet("SP_GetTrainerListing", searchText, 0, TotalRecords, "RefNo", "Desc", CompanyName, "");
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana  
        //Created on : 25-02-2015
        //purpose    : Export Print Certificate - Trainer
        public DataSet ExporttrainerListPC(string CompanyName, int companyTypeID, string searchText, string Name, string NRIC, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
            if (searchText == "null")
            { searchText = ""; }
            if (Name == "null")
            { Name = ""; }
            if (sortOrder == "true")
            { sortOrder = "Asc"; }
            else { sortOrder = "Desc"; }
            if (NRIC == "null")
            { NRIC = ""; }
            using (var context = DataContext)
            {
                if (companyTypeID > 1)
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_GetTrainersListPC", CompanyName, Name, NRIC, 0, TotalRecords, searchText, sortColumn, sortOrder, "1");
                }
                else
                {
                    mDSTTS = mDB.ExecuteDataSet("SP_GetTrainersList", Name, NRIC, 0, TotalRecords, searchText, sortColumn, sortOrder, "1");
                }
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana  
        //Created on : 25-02-2015
        //purpose    : Export Admin Trainer List
        public DataSet ExportAdmintrainerList(string searchText, Int64 TotalRecords, string CompanyName, string TrainingDate, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
            string dayT, monT, yearT, Tdate;
            if (TrainingDate != null && TrainingDate != "")
            {
                string[] words = TrainingDate.Split('-');
                dayT = words[0];
                monT = MonthConvert(words[1]);
                yearT = words[2];
                Tdate = yearT + monT + dayT;
            }
            else
            { Tdate = ""; }
            if (sortOrder == "true")
            { sortOrder = "Asc"; }
            else { sortOrder = "Desc"; }
            using (var context = DataContext)
            {
                mDSTTS = mDB.ExecuteDataSet("SP_GetTrainerListing", searchText, 0, TotalRecords, sortColumn, sortOrder, CompanyName, Tdate);
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana  
        //Created on : 25-02-2015
        //purpose    : Export Admin Trainer Summary
        public DataSet ExportAdmintrainerSummary(string CompanyName, string TrainingDate, int tTID, string searchText, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            DataSet mDSTTSOutput = new DataSet();
            DataTable mDSTTS1 = new DataTable();
            List<TrainingRecordVM> objMembers = new List<TrainingRecordVM>();          

            try
            {
            if (sortOrder == "true")
            { sortOrder = "Asc"; }
            else { sortOrder = "Desc"; }
            using (var context = DataContext)
            {
                mDSTTS = mDB.ExecuteDataSet("SP_TrainerTrainingRecord_Admin", tTID, CompanyName, TrainingDate, 0, TotalRecords, searchText, sortColumn, sortOrder);
                if (mDSTTS.Tables.Count > 0)
                {
                    DataTable dT1 = mDSTTS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        TrainingRecordVM trainingRecord = new TrainingRecordVM();
                        trainingRecord.RefNo = Convert.ToInt32(dr["RefNo"]); //dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        trainingRecord.CompanyId = Convert.ToInt32(dr["CompanyID"]);
                        trainingRecord.TRFDateS = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString(); //Convert.ToDateTime(dr["TrainingDate"]);
                        trainingRecord.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString().Trim();
                        trainingRecord.TrainerCompanyName = dr["TrainerCompanyName"] == DBNull.Value ? "" : dr["TrainerCompanyName"].ToString();
                        trainingRecord.TrainerCompanyID = Convert.ToInt32(dr["TrainerCompanyID"]);
                        trainingRecord.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        trainingRecord.Email = dr["Email"] == DBNull.Value ? "" : dr["Email"].ToString();
                        if (dr["TrainerPicFileId"].ToString() != "")
                        {
                            trainingRecord.TrainerPicFileId = new Guid(dr["TrainerPicFileId"].ToString());
                        }
                        
                        int addCount = 0;
                        foreach (var itemE in objMembers)
                        {
                            if (itemE.TrainerName.Trim().ToLower() == trainingRecord.TrainerName.ToLower() && itemE.TrainerCompanyName == trainingRecord.TrainerCompanyName)
                            {
                                addCount++;
                            }
                        }
                        if (addCount == 0)
                        {
                            objMembers.Add(trainingRecord);
                        }
                    }
                    foreach (var itemE in objMembers)
                    {
                        itemE.TotalRecords = objMembers.Count();
                    }
                    mDSTTS1 = ToDataTable(objMembers);
                    mDSTTSOutput.Tables.Add(mDSTTS1);
                }
            }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTSOutput;
        }


        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

    }
}