﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace OHES.eFit.Data.Repository
{

    public interface ICertifiedTrainersRepository
    {
        //Certified Trainers
        #region CustomerListingPages

        companyLi getCompaniesList(int companyTypeId);
        companyLi getTrainerCompanyName(int companyTypeId, int traType);
        List<ActiveTrainers> getActiveTrainers(InputDetails ID);
        List<ActiveTrainers> getDueOfRenewal(InputDetails ID);
        List<ActiveTrainers> getExpiredTrainers(InputDetails ID);
        DataSet ExportActiveTrainers(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeId, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExportDueOfRenewalTrainers(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeId, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExportExpiredTrainers(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeId, Int64 TotalRecords, string sortColumn, string sortOrder);


        #endregion
    }
    public class CertifiedTrainersRepository : RepositoryBase<eFitContext>, ICertifiedTrainersRepository
    {
        private Database mDB;

        #region Constructor

        public CertifiedTrainersRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }

        #endregion

        //Created By : Kalpna
        //Created On : 18-February-2015
        //Purpose    : Getting Companies List
        public companyLi getCompaniesList(int companyTypeId)
        {
            companyLi comList = new companyLi();
            try
            {
                using (var context = DataContext)
                {
                    var cList = context.CompaniesList
                      .GroupBy(x => x.CompanyName)
                      .Select(g => new { CompanyName = g.Key, CompanyID = g.FirstOrDefault().CompanyID })
                      .ToList();
                    foreach (var item in cList)
                    {
                        if (item.CompanyName != null && item.CompanyName != "")
                        {
                            comList.companyName.Add(item.CompanyName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpna
        //Created On : 18-February-2015
        //Purpose    : Get Trainer Company Name
        public companyLi getTrainerCompanyName(int companyTypeId, int traType)
        {
            companyLi comList = new companyLi();
            DataSet mDS;
            try
            {
                using (var context = DataContext)
                {
                   
                    if (companyTypeId == 3)
                    {
                        mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", "", "", 1, 50, "", "", "", traType);
                    }
                    else
                    {
                        mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", "", "", 1, 50, "", "", "", traType);
                    }

                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[2];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            CompaniesList company = new CompaniesList();

                            company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                            if (!string.IsNullOrEmpty(company.CompanyName))
                            {
                                comList.companyName.Add(company.CompanyName);
                            }

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Ramya
        //Created On : 18-February-2015
        //Purpose    : Getting Active Trainers Details
        public List<ActiveTrainers> getActiveTrainers(InputDetails ID)
        {
            List<ActiveTrainers> objMembers = new List<ActiveTrainers>();
            try
            {
                string dayT, monT, yearT, Tdate;
                DataSet mDS;
                if (ID.searchText == null)
                { ID.searchText = ""; }
                if (ID.sortOrder == "True")
                { ID.sortOrder = "Asc"; }
                else { ID.sortOrder = "Desc"; }
                if (!string.IsNullOrEmpty(ID.trainingDate))
                {
                    string[] words = ID.trainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (ID.companyTypeID == 3)
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers_Distributed", ID.companyName, ID.disCompanyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "1");
                }
                else
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "1");
                }
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        ActiveTrainers activeTrainers = new ActiveTrainers();
                        activeTrainers.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        activeTrainers.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        activeTrainers.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                        activeTrainers.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        activeTrainers.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                        activeTrainers.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                        activeTrainers.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                        activeTrainers.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        activeTrainers.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        activeTrainers.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        activeTrainers.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();

                        activeTrainers.TrainerPicField = dr["TrainerPicFileId"] == DBNull.Value ? "" : dr["TrainerPicFileId"].ToString();

                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            activeTrainers.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(activeTrainers);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Ramya
        //Created On : 18-February-2015
        //Purpose    : Getting DueOfRenewal Trainers Details
        public List<ActiveTrainers> getDueOfRenewal(InputDetails ID)
        {
            List<ActiveTrainers> objMembers = new List<ActiveTrainers>();
            try
            {
                string dayT, monT, yearT, Tdate;
                DataSet mDS;
                if (ID.searchText == null)
                { ID.searchText = ""; }
                if (ID.sortOrder == "True")
                { ID.sortOrder = "Asc"; }
                else { ID.sortOrder = "Desc"; }
                if (!string.IsNullOrEmpty(ID.trainingDate))
                {
                    string[] words = ID.trainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (ID.companyTypeID == 3)
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers_Distributed", ID.companyName, ID.disCompanyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "2");
                }
                else
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "2");
                }
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        ActiveTrainers dueOfRenewal = new ActiveTrainers();
                        dueOfRenewal.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        dueOfRenewal.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        dueOfRenewal.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                        dueOfRenewal.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        dueOfRenewal.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                        dueOfRenewal.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                        dueOfRenewal.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                        dueOfRenewal.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        dueOfRenewal.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        dueOfRenewal.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        dueOfRenewal.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            dueOfRenewal.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(dueOfRenewal);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Ramya
        //Created On : 18-February-2015
        //Purpose    : Getting Expried Trainers Details
        public List<ActiveTrainers> getExpiredTrainers(InputDetails ID)
        {
            List<ActiveTrainers> objMembers = new List<ActiveTrainers>();
            try
            {
                string dayT, monT, yearT, Tdate;
                DataSet mDS;
                if (ID.searchText == null)
                { ID.searchText = ""; }
                if (ID.sortOrder == "True")
                { ID.sortOrder = "Asc"; }
                else { ID.sortOrder = "Desc"; }
                if (!string.IsNullOrEmpty(ID.trainingDate))
                {
                    string[] words = ID.trainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (ID.companyTypeID == 3)
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers_Distributed", ID.companyName, ID.disCompanyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "3");
                }
                else
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "3");
                }
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        ActiveTrainers expiredTrainers = new ActiveTrainers();
                        expiredTrainers.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        expiredTrainers.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        expiredTrainers.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                        expiredTrainers.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        expiredTrainers.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                        expiredTrainers.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                        expiredTrainers.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                        expiredTrainers.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        expiredTrainers.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        expiredTrainers.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        expiredTrainers.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            expiredTrainers.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(expiredTrainers);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Ramya
        //Created On : 18-February-2015
        //Purpose    : Export Active Trainers Details
        public DataSet ExportActiveTrainers(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeId, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                string dayT, monT, yearT, Tdate;
                if (!string.IsNullOrEmpty(TrainingDate))
                {
                    string[] words = TrainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    if (companyTypeId == 3)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers_Distributed", CompanyName, disName,Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, "1");
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, "1");
                    }

                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Ramya
        //Created On : 18-February-2015
        //Purpose    : Export Due Of Renewal Trainers Details
        public DataSet ExportDueOfRenewalTrainers(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeId, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                string dayT, monT, yearT, Tdate;
                if (!string.IsNullOrEmpty(TrainingDate))
                {
                    string[] words = TrainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    if (companyTypeId == 3)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers_Distributed", CompanyName, disName,Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, "2");
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, "2");
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Ramya
        //Created On : 18-February-2015
        //Purpose    : Export Expired Trainers Details
        public DataSet ExportExpiredTrainers(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeId, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                string dayT, monT, yearT, Tdate;
                if (!string.IsNullOrEmpty(TrainingDate))
                {
                    string[] words = TrainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    if (companyTypeId == 3)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers_Distributed", CompanyName,disName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, "3");
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers", CompanyName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, "3");
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }
    }
}
