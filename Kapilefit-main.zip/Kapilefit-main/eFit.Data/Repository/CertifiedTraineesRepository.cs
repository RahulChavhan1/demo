﻿using OHES.eFit.Data.DataContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OHES.eFit.Data.DataModel;
using System.Globalization;
using System.Web.ModelBinding;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using OHES.eFit.Data.Utility;

namespace OHES.eFit.Data.Repository
{
    public interface ICertifiedTraineesRepository
    {

        #region Certified Trainees Pages

        companyL getCompaniesList(int companyTypeId);
        
        companyL getCertifiedCompanyName(int companyTypeId, int traType);
        companyL getDistributorCompaniesList(string companyName ,int tID, int disID);
        List<ActiveTrainees> getActiveTrainees(InputDetails ID);
        List<ActiveTrainees> getdueOfRenewal(InputDetails ID);
        List<ActiveTrainees> getExpiredTrainees(InputDetails ID);
        DataSet ExportActiveTrainees(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExportDueOfRenewalTrainees(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder);
        DataSet ExportExpiredTrainees(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder);
        ActionStatus savePrintData(printInput checkData);
        List<TempPrint> getPrintDetails(Nullable<Guid> checkData);

        #endregion
    }
    public class CertifiedTraineesRepository : RepositoryBase<eFitContext>, ICertifiedTraineesRepository
    {
        private Database mDB;

        #region Constructor

        public CertifiedTraineesRepository()
        {
            mDB = DatabaseFactory.CreateDatabase("eFitContext");
        }

        #endregion

        //Created By : Kalpana
        //Created On : 05-February-2015
        //Purpose    : Get Companies List
        public companyL getCompaniesList(int companyTypeId)
        {
            companyL comList = new companyL();
            try
            {
                using (var context = DataContext)
                {
                    DataSet mDS = mDB.ExecuteDataSet("SP_GetCompanyName");
                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[0];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            CompaniesList company = new CompaniesList();
                            company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();

                            if (!string.IsNullOrEmpty(company.CompanyName))
                            {
                                comList.companyName.Add(company.CompanyName);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 05-February-2015
        //Purpose    : Get Certified Company Name
        public companyL getCertifiedCompanyName(int companyTypeId,int traType)
        {
            companyL comList = new companyL();
             DataSet mDS ;
            try
            {
                using (var context = DataContext)
                {
                    if (companyTypeId == 3)
                    {
                        mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", "", "", 1, 50, "", "", "", traType);
                    }
                    else
                    {
                        mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", "", "", 1, 50, "", "", "", traType);
                    }
                    if (mDS.Tables.Count > 0)
                    {
                        DataTable dT1 = mDS.Tables[2];
                        foreach (DataRow dr in dT1.Rows)
                        {
                            CompaniesList company = new CompaniesList();
                            company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                            if (!string.IsNullOrEmpty(company.CompanyName))
                            {
                                comList.companyName.Add(company.CompanyName);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        
        }

        //Created By : Kalpana
        //Created On : 05-February-2015
        //Purpose    : Get Distributor Companies List
        public companyL getDistributorCompaniesList(string companyName, int tID, int disID)
        {
            companyL comList = new companyL();
            DataSet mDS;
            try
            {
                using (var context = DataContext)
                {
                    if (disID == 1)
                    {
                        mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainers_Distributed", "", companyName,"", 1, 50, "", "", "", tID);
                    }
                    else
                    {
                       mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees_Distributed", "", companyName,"", 1, 50, "", "", "", tID);
                    }
                        if (mDS.Tables.Count > 0)
                        {
                            DataTable dT1 = mDS.Tables[2];
                            foreach (DataRow dr in dT1.Rows)
                            {
                                CompaniesList company = new CompaniesList();
                                company.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();

                                if (!string.IsNullOrEmpty(company.CompanyName))
                                {
                                    comList.companyName.Add(company.CompanyName);
                                }

                            }
                        }
                    }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return comList;
        }

        //Created By : Kalpana
        //Created On : 05-February-2015
        //Purpose    : Getting Active Trainees Details
        public List<ActiveTrainees> getActiveTrainees(InputDetails ID)
        {
            List<ActiveTrainees> objMembers = new List<ActiveTrainees>();
            try
            {
                string dayT, monT, yearT, Tdate;
                DataSet mDS;            
                if (ID.searchText == null)
                { ID.searchText = ""; }
                if (ID.sortOrder == "True")
                { ID.sortOrder = "Asc"; }
                else { ID.sortOrder = "Desc"; }
                if (!string.IsNullOrEmpty(ID.trainingDate ))
                {
                    string[] words = ID.trainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (ID.companyTypeID == 3)
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees_Distributed", ID.companyName, ID.disCompanyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "1");
                }
                else
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "1");
                }
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        ActiveTrainees activeTrainees = new ActiveTrainees();
                        activeTrainees.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        activeTrainees.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        activeTrainees.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                        activeTrainees.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        activeTrainees.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                        activeTrainees.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                        activeTrainees.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                        activeTrainees.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        activeTrainees.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        activeTrainees.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        activeTrainees.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            activeTrainees.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(activeTrainees);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 16-February-2015
        //Purpose    : Getting Du Of Renewal Trainees Details
        public List<ActiveTrainees> getdueOfRenewal(InputDetails ID)
        {
            List<ActiveTrainees> objMembers = new List<ActiveTrainees>();
            try
            {
                string dayT, monT, yearT, Tdate;
                DataSet mDS;
                if (ID.searchText == null)
                { ID.searchText = ""; }
                if (ID.sortOrder == "True")
                { ID.sortOrder = "Asc"; }
                else { ID.sortOrder = "Desc"; }
                if (!string.IsNullOrEmpty(ID.trainingDate))
                {
                    string[] words = ID.trainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (ID.companyTypeID == 3)
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees_Distributed", ID.companyName, ID.disCompanyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "2");
                }
                else
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "2");
                }
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        ActiveTrainees dueOfRenewalTrainees = new ActiveTrainees();
                        dueOfRenewalTrainees.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        dueOfRenewalTrainees.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        dueOfRenewalTrainees.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                        dueOfRenewalTrainees.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        dueOfRenewalTrainees.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                        dueOfRenewalTrainees.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                        dueOfRenewalTrainees.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                        dueOfRenewalTrainees.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        dueOfRenewalTrainees.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        dueOfRenewalTrainees.TrainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        dueOfRenewalTrainees.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            dueOfRenewalTrainees.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(dueOfRenewalTrainees);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 16-February-2015
        //Purpose    : Getting Expired Trainees Details
        public List<ActiveTrainees> getExpiredTrainees(InputDetails ID)
        {
            List<ActiveTrainees> objMembers = new List<ActiveTrainees>();
            try
            {
                string dayT, monT, yearT, Tdate;
                DataSet mDS;
                if (ID.searchText == null)
                { ID.searchText = ""; }
                if (ID.sortOrder == "True")
                { ID.sortOrder = "Asc"; }
                else { ID.sortOrder = "Desc"; }
                if (ID.trainingDate != null && ID.trainingDate != "")
                {
                    string[] words = ID.trainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (ID.companyTypeID == 3)
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees_Distributed", ID.companyName, ID.disCompanyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "3");
                }
                else
                {
                    mDS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", ID.companyName, Tdate, ID.pageIndex, ID.pageSize, ID.searchText, ID.sortColumn, ID.sortOrder, "3");
                }
                if (mDS.Tables.Count > 0)
                {
                    DataTable dT1 = mDS.Tables[0];
                    foreach (DataRow dr in dT1.Rows)
                    {
                        ActiveTrainees expiredTrainees = new ActiveTrainees();
                        expiredTrainees.TrainingDate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        expiredTrainees.CompanyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        expiredTrainees.TraineeName = dr["TraineeName"] == DBNull.Value ? "" : dr["TraineeName"].ToString();
                        expiredTrainees.Designation = dr["Designation"] == DBNull.Value ? "" : dr["Designation"].ToString();
                        expiredTrainees.Dept = dr["Dept"] == DBNull.Value ? "" : dr["Dept"].ToString();
                        expiredTrainees.IC = dr["IC"] == DBNull.Value ? "" : dr["IC"].ToString();
                        expiredTrainees.Model = dr["Model"] == DBNull.Value ? "" : dr["Model"].ToString();
                        expiredTrainees.ContactPerson = dr["ContactPerson"] == DBNull.Value ? "" : dr["ContactPerson"].ToString();
                        expiredTrainees.ContactNo = dr["ContactNo"] == DBNull.Value ? "" : dr["ContactNo"].ToString();
                        expiredTrainees.TrainerName = dr["TrainerName"] ==   DBNull.Value ? "" : dr["TrainerName"].ToString();
                        expiredTrainees.RefNo = dr["RefNo"] == DBNull.Value ? "" : dr["RefNo"].ToString();
                        DataTable dT2 = mDS.Tables[1];
                        foreach (DataRow dr2 in dT2.Rows)
                        {
                            expiredTrainees.TotalRecords = Convert.ToInt64(dr2["No_of_Records"]);
                        }
                        objMembers.Add(expiredTrainees);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return objMembers;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export Active Trainees Details
        public DataSet ExportActiveTrainees(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            string dayT, monT, yearT, Tdate;
            try
            {
                if (!string.IsNullOrEmpty(TrainingDate ))
                {
                    string[] words = TrainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    if (companyTypeID == 3)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees_Distributed", CompanyName, disName, Tdate, 0, TotalRecords, searchText, sortColumn, sortOrder, "1");
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", CompanyName, Tdate, 1, TotalRecords, searchText, sortColumn, sortOrder, "1");
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export Due Of Renewal Trainees Details
        public DataSet ExportDueOfRenewalTrainees(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                string dayT, monT, yearT, Tdate;
                if (!string.IsNullOrEmpty(TrainingDate))
                {
                    string[] words = TrainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    if (companyTypeID == 3)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees_Distributed", CompanyName, disName, Tdate, 1, TotalRecords, searchText, sortColumn, sortOrder, "2");
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", CompanyName, Tdate, 1, TotalRecords, searchText, sortColumn, sortOrder, "2");
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Export Expired Trainees Details
        public DataSet ExportExpiredTrainees(string CompanyName, string disName, string TrainingDate, string searchText, int companyTypeID, Int64 TotalRecords, string sortColumn, string sortOrder)
        {
            DataSet mDSTTS = new DataSet();
            try
            {
                string dayT, monT, yearT, Tdate;
                if (!string.IsNullOrEmpty(TrainingDate))
                {
                    string[] words = TrainingDate.Split('-');
                    dayT = words[0];
                    monT = MonthConvert(words[1]);
                    yearT = words[2];
                    Tdate = yearT + monT + dayT;
                }
                else
                { Tdate = ""; }
                if (searchText == "null")
                { searchText = ""; }
                if (sortOrder == "true")
                { sortOrder = "Asc"; }
                else { sortOrder = "Desc"; }
                using (var context = DataContext)
                {
                    if (companyTypeID == 3)
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees_Distributed", CompanyName, disName, Tdate, 1, TotalRecords, searchText, sortColumn, sortOrder, "3");
                    }
                    else
                    {
                        mDSTTS = mDB.ExecuteDataSet("SP_GetCertifiedTrainees", CompanyName, Tdate, 1, TotalRecords, searchText, sortColumn, sortOrder, "3");
                    }
                }
            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }
            return mDSTTS;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Save Print Data
        public ActionStatus savePrintData(printInput checkData)
        {
            ActionStatus status = new ActionStatus();
            string data = string.Empty;
            TempPrint saveDataPrint = new TempPrint();
            using (var context = DataContext)
            {
                try
                {
                    if (checkData.refNo != null)
                    {
                        var fileId = Guid.NewGuid(); 

                        foreach (var item in checkData.refNo)
                        {
                            saveDataPrint.Id = fileId;
                            saveDataPrint.PrintData = item.RefNo;
                            context.T_Temp_PrintData.Add(saveDataPrint);
                            context.SaveChanges();
                        }
                        

                        status.success = true;
                        status.id = fileId;
                    }
                }
                catch (Exception ex)
                {
                    status.success = false;
                    Utility.Utility.LogException(ex);
                }
            }


            return status;
        }

        //Created By : Kalpana
        //Created On : 11-February-2015
        //Purpose    : Get Print Details
        public List<TempPrint> getPrintDetails(Nullable<Guid> id)
        {
            List<TempPrint> priCerList = new List<TempPrint>();
            try
            {
                TempPrint priCer = new TempPrint();
                TempPrint pri = new TempPrint();

                 DataSet mDS = mDB.ExecuteDataSet("SP_GetPrintData",id.ToString());
                 if (mDS.Tables.Count > 0)
                 {
                     priCerList = mDS.Tables[0].AsEnumerable().Select(dataRow => new TempPrint { Id = (Guid)dataRow["Id"], PrintData = dataRow.Field<string>("PrintData") }).ToList();
                 }
                 if (id != null)
                 {
                     mDB.ExecuteDataSet("SP_DeletePrintData", id.ToString());
                 }

            }
            catch (Exception ex)
            {
                Utility.Utility.LogException(ex);
            }

            return priCerList;
        }



    }
}
