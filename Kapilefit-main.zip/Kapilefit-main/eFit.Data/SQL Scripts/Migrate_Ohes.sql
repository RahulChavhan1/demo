/*alter table [dbo].[T_TrainingRecordForm] add [modifiedBy] nvarchar(50) null
alter table [dbo].[T_TrainingRecordForm] add [modifiedDate] datetime null */

alter  VIEW [dbo].[V_Training_Record]
AS
SELECT        dbo.tbl_Training_Record_Form.RefNo, dbo.tbl_Training_Record_Form.Company_Name AS [Company Name], dbo.v_Company.Address, dbo.v_Company.Postal_Code AS [postal code], 
                         dbo.v_Company.Contact_Person AS [Contact Person], dbo.v_Company.Contact_Tele AS [Contact Tele], CONVERT(varchar(11), dbo.tbl_Training_Record_Form.TRF_Date) AS [Training Date], 
                         dbo.tbl_Training_Record_Form.Trainer_Name AS [Trainer Name], dbo.tbl_Training_Record_Form.Trainer_Company_Name AS [Trainer Company], dbo.tbl_Training_Type.Training_Type AS [Training Type], 
                         dbo.tbl_Training_Record_Form.Topics_Covered AS [Topics Covered], dbo.tbl_Training_Record_Form.Training_Type_id, dbo.v_Company.Company_ID AS id, 
                         dbo.tbl_Training_Record_Form.Trainer_Company_Name AS [Training Company], dbo.tbl_Training_Record_Form.Emails
FROM            dbo.tbl_Training_Record_Form INNER JOIN
                         dbo.tbl_Training_Type ON dbo.tbl_Training_Record_Form.Training_Type_id = dbo.tbl_Training_Type.Training_Type_ID INNER JOIN
                         dbo.v_Company ON dbo.tbl_Training_Record_Form.Company_Name = dbo.v_Company.company_name
GO

truncate table [T_Company]
truncate table [T_TrainingRecordForm]
truncate table [T_TrainingAttendanceRoster]
truncate table [T_Users]
SET IDENTITY_INSERT [OHES_NEW].[dbo].[T_Company] ON


INSERT INTO [dbo].[T_Company]
           ([CompanyID]
           ,[FileName]
           ,[CompanyName]
           ,[CompanyTypeID]
           ,[Address]
           ,[PostalCode]
           ,[ContactPerson]
           ,[ContactDesignation]
           ,[ContactNumber])
    SELECT 
       [Company_ID]
      ,[RefNo]
	  ,[company_name]
      ,[Company_Type_ID]
      ,[Address]
      ,[Postal_Code]
      ,[Contact_Person]
      ,[Contact_Designation]
      ,[Contact_Tele]
  FROM [sgohesc_OHES].[dbo].[v_Company] where Company_ID is not null

SET IDENTITY_INSERT [OHES_NEW].[dbo].[T_Company] OFF 

-----------------------------------------------------------
INSERT INTO [OHES_NEW].[dbo].[T_TrainingRecordForm]
           ([FileName]
           ,[CompanyID]
           ,[TRFDate]
           ,[TopicsCovered]
           ,[TrainerName]
           ,[TrainerCompanyID]
           --,[TrainerPicFileId]
           ,[Email]
           ,[TrainingTypeID])
    SELECT [RefNo]
	  ,(select top 1 CompanyID from [OHES_NEW].[dbo].[T_Company] where CompanyName = rtrim(ltrim(a.[Company Name]))) as CompanyID
      ,[Training Date]
	  ,[Topics Covered]
      ,[Trainer Name]
      ,(select top 1 CompanyID from [OHES_NEW].[dbo].[T_Company] where CompanyName = rtrim(ltrim(a.[Trainer Company]))) as TrainerCompanyID
      ,[Emails]
      
      ,[Training_Type_id]
     
  FROM [sgohesc_OHES].[dbo].[V_Training_Record] a

-------------------------------------------------------------
INSERT INTO [dbo].[T_TrainingAttendanceRoster]
           ([RefNo]
           ,[Name]
           ,[Designation]
           ,[Department]
           ,[IC]
           ,[Model]
           ,[Outcome])
   SELECT (select top 1 RefNo from [OHES_NEW].[dbo].[T_TrainingRecordForm] where [FileName]  = a.RefNo) as ref
      ,[Trainee Name]
      ,[Designation]
      ,[Dept]
      ,[IC]
      ,[Model]
      ,[Outcome]
      
      
  FROM [sgohesc_OHES].[dbo].[v_Training_Attendance_Roster] a

---------------------------------------------------------------

INSERT INTO [OHES_NEW].[dbo].[T_Users]
           ([UserID]
           ,[UserName]
           ,[CompanyID]
           ,[EmailID]
           ,[Password]
           ,[RoleID]
           ,[Locked]
           ,[UpdatedBy]
           ,[UpdatedDate]
           ,[CompanyName])
    SELECT [userID]
      ,[userName]
      ,[company_id]
      ,[emailID]
      ,[password]
      ,[RoleId]
      ,[Locked]
      ,[lastupdated_by]
      ,[lastupdated_date]
      ,[company_name]
  FROM [sgohesc_OHES].[dbo].[tbl_users]

select count(1) from [dbo].[T_Company]
select count(1) from [dbo].[T_TrainingAttendanceRoster]
select count(1) from [dbo].[T_TrainingRecordForm]
select count(1) from [dbo].[T_Users]