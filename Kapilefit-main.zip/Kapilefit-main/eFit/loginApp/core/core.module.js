﻿(function () {
    'use strict';

    var core = angular
        .module('loginApp.core', ['ngAnimate', 'ui.router', 'ngSanitize','angular-loading-bar',
        /*
         * Our reusable cross app code modules
         * 'blocks.exception',
         */
        'blocks.logger', 'blocks.common.directive',
        /*
         * 3rd Party modules
         */
        'ui.bootstrap', 'ngplus'])
       .constant('toastr', toastr)
        .constant('moment', moment);

    core.config(toastrConfig);

    toastrConfig.$inject = ['toastr']
    function toastrConfig(toastr) {
        toastr.options.timeOut = 4000;
        toastr.options.positionClass = 'toast-top-right';
    }

    core.config(loadingBarConfig);

    loadingBarConfig.$inject = ['cfpLoadingBarProvider']
    function loadingBarConfig(cfpLoadingBarProvider) {
        cfpLoadingBarProvider.includeSpinner = true;
        cfpLoadingBarProvider.includeBar = true;
    }

    var config = {
        appErrorPrefix: '[NG-Modular Error] ', //Configure the exceptionHandler decorator
        appTitle: 'OHES',
        version: '1.0.0',
        baseURL: '/'
    };

    core.value('config', config);

    core.run(rootscope);

    rootscope.$inject = ['$rootScope', '$state', '$stateParams'];

    function rootscope($rootScope, $state, $stateParams) {
        $state.previous = null;
        $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
            $state.previous = fromState;
        });
        // It's very handy to add references to $state and $stateParams to the $rootScope
        // so that you can access them from any scope within your applications.For example,
        // to active whenever 'contacts.list' or one of its decendents is active.
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
    }

    core.config(routconfig);


    routconfig.$inject = ['$stateProvider', '$urlRouterProvider'];

    function routconfig($stateProvider, $urlRouterProvider) {
        $urlRouterProvider
       // If the url is ever invalid, e.g. '/asdf', then redirect to '/' aka the home state
       .otherwise('/');

        // Use $stateProvider to configure your states.
        $stateProvider


         .state("login", {
             url: "/",
             templateUrl: config.baseURL + "Login/Index",
             controller: "loginAppcntrl as vm"
         })

        //.state("forgotPassword", {
        //    url: "/forgotPassword",
        //    templateUrl: config.baseURL + "Account/ForgotPassword",
        //    controller: "loginAppcntrl as vm"
        //})


    }








})();
