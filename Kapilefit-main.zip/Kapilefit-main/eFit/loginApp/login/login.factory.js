﻿(function () {
    'use strict';

    angular
        .module('loginApp.login')
        .factory('loginService', logindetails);

    logindetails.$inject = ['$http', '$q', 'config'];

    function logindetails($http, $q, config) {
        var service = {
            doAuthorize: doAuthorize,
            submitLoginDetails: submitLoginDetails,
            getHitCount: getHitCount
        };

        return service;


        function doAuthorize() {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'Login/doAuthorize'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;

        }


        function submitLoginDetails(LoginDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/LoginApi/',
                data: JSON.stringify(LoginDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;

        }
        function getHitCount()
        {
            var deferred = $q.defer();

            $http({
                method: 'Get', url: config.baseURL + 'api/LoginApi/getHitCount'

            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;

                 }


    }
})();