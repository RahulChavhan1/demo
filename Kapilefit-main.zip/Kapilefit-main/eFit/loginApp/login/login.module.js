﻿(function () {
    'use strict';

    angular.module('loginApp.login', []);


})();