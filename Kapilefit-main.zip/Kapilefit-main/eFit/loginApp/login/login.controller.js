﻿(function () {
    'use strict';

    angular
        .module('loginApp.login')
        .controller('loginAppcntrl', loginAppcntrl);

    loginAppcntrl.$inject = ['$state', '$q', 'loginService', 'logger', '$stateParams', '$rootScope', '$timeout', 'config', '$scope'];

    function loginAppcntrl($state, $q, loginService, logger, $stateParams, $rootScope, $timeout, config, $scope) {
        /* jshint validthis:true */

        var vm = this;
        vm.title = 'login';
        vm.loginDetails = {};
        vm.Login = submit;
        vm.validation = false;
        vm.errorMessage = {};
        vm.hitcount = 0;
        activate();

        function activate() {
            
            var promises = [doAuthorize(), getHitCount()];
            return $q.all(promises).then(function () { });
            
        }

        function doAuthorize()
        {
            loginService.doAuthorize().then(function (data) {
                //window.location = config.baseURL + '#/homemenu/HomeOption/General';
                window.location = config.baseURL + data.returnUrl;
            });
        }

        function getHitCount()
        {
           
            loginService.getHitCount().then(function (data) {
                vm.hitcount = data;
            });
        }


        function submit(isvalid) {
           
                loginService.submitLoginDetails(vm.loginDetails).then(function (data) {
                    if (data.success == true) {
                        vm.validation = false;                      
                        $rootScope.showMenu = true;                    
                        window.location = config.baseURL + '#/homemenu/HomeOption/General';
                    }
                    else {
                        logger.warning(data.message, "", "");
                    }
                });
        }
    }
})();
