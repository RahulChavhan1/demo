﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OHES.eFit.WebAPI
{
    [Authorize]
    public class CertifiedTrainersApiController : ApiController
    {
        ICertifiedTrainersRepository _CertifiedTrainersRepository;
        public CertifiedTrainersApiController()
        {
            _CertifiedTrainersRepository = new CertifiedTrainersRepository();
        }
       // Get Companies List
        public companyLi GetCompaniesList(int Param1)
        {
            return _CertifiedTrainersRepository.getCompaniesList(Param1);
        }

        public companyLi GetTrainerCompanyName(int Param1,int Param2)
        {
            return _CertifiedTrainersRepository.getTrainerCompanyName(Param1, Param2);
        }

        //Get Active Trainers
        public List<ActiveTrainers> Post([FromBody]InputDetails traineeInputs)
        {
            List<ActiveTrainers> trainerList = new List<ActiveTrainers>();

            if (traineeInputs.traineeType == 1)
            {
                trainerList = _CertifiedTrainersRepository.getActiveTrainers(traineeInputs);
            }

            else if (traineeInputs.traineeType == 2)
            {
                trainerList = _CertifiedTrainersRepository.getDueOfRenewal(traineeInputs);
            }

            else if (traineeInputs.traineeType == 3)
            {
                trainerList = _CertifiedTrainersRepository.getExpiredTrainers(traineeInputs);
            }

            return trainerList;
        }
         //GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }
         //GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }
         //PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }
        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}