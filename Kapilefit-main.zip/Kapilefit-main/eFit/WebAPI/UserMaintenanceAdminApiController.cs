﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OHES.eFit.WebAPI
{
    [Authorize]
    public class UserMaintenanceAdminApiController : ApiController
    {

        IUserMaintenanceAdminRepository _UserMaintenanceAdminRepository;
        
        public UserMaintenanceAdminApiController()
        {
            _UserMaintenanceAdminRepository = new UserMaintenanceAdminRepository();
        }

        public User GetUsersData(string Param1)
        {
            return _UserMaintenanceAdminRepository.getUsersData(Param1);
        }

        public List<Role> GetRoleList(string Param1)
        {
            return _UserMaintenanceAdminRepository.getRoleList(Param1);
        }

        //Delete User
        [HttpGet]
        public ActionStatus DeleteUser(string Param1)
        {
            return _UserMaintenanceAdminRepository.deleteUser(Param1);
        }

        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        public ActionStatus Post([FromBody]UserVM userDetail)
        {
            return _UserMaintenanceAdminRepository.saveUser(userDetail);
        }

        public companyL GetCompaniesListUser(int param1)
        {
            return _UserMaintenanceAdminRepository.getCompaniesListUser(param1);
        }
        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }

        [HttpGet]
        public ActionStatus CheckCompanyName(string Param1)
        {
            return _UserMaintenanceAdminRepository.CheckCompanyName(Param1);
        }

        [HttpGet]
        public ActionStatus ResetPwd(string Param1)
        {
            return _UserMaintenanceAdminRepository.ResetPwd(Param1);
        }

        [HttpPost, Route("api/UserMaintenanceAdminApi/CheckCompanyName")]
        public ActionStatus CheckCompanyName([FromBody]CompanyDts companyDet)
        {
            return _UserMaintenanceAdminRepository.CheckCompanyName(companyDet.CompanyName);
        }

        [Route("api/UserMaintenanceAdminApi/GetUserName")]
        [HttpGet]
        public Users GetUserName()
        {
            return _UserMaintenanceAdminRepository.getUserName();
        }

        [HttpPost, Route("api/CustomerListingApi/GetUsers")]
        public List<UserVM> GetUsers([FromBody]InputDetails user)
        {
            return _UserMaintenanceAdminRepository.getUsers(user.companyTypeID, user.searchText, user.pageSize, user.pageIndex, user.sortColumn, user.sortOrder);
        }

    }
}