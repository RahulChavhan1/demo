﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OHES.eFit.WebAPI
{
    [Authorize]
    public class DocMangerApiController : ApiController
    {
        IDocMangerRepository _DocMangerRepository;

         public DocMangerApiController()
        {
            _DocMangerRepository = new DocMangerRepository();
        }

        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        //Get Companies List
        public companyL GetCompaniesList(int Param1)
        {
            return _DocMangerRepository.getCompaniesList(Param1);
        }

         //Get Active Trainees
         public List<ActiveTrainees> Post([FromBody]InputDetails traineeInputs)
          
         {
             List<ActiveTrainees> traineeList=new List<ActiveTrainees>();
             
             if(traineeInputs.traineeType == 1)
             {
                 traineeList = _DocMangerRepository.getActiveTrainees(traineeInputs);
             }

             return traineeList;
         }

         [HttpPost, Route("api/DocMangerApi/CheckTraineeName")]
         public ActionStatus CheckTraineeName([FromBody]CompanyDts companyDet)
         {
             return _DocMangerRepository.CheckTraineeName(companyDet.CompanyName);
         }

         [HttpPost, Route("api/DocMangerApi/CheckTrainerName")]
         public ActionStatus CheckTrainerName([FromBody]CompanyDts companyDet)
         {
             return _DocMangerRepository.CheckTrainerName(companyDet.CompanyName);
         }

         [HttpPost, Route("api/DocMangerApi/GetDistributorCompaniesList")]
         public companyL GetDistributorCompaniesList([FromBody]CompanyDts companyDet)
         {
             return _DocMangerRepository.getDistributorCompaniesList(companyDet.companyName, companyDet.tID, companyDet.disID);
         }

         [HttpPost, Route("api/DocMangerApi/GetCompaniesListFitTrain")]
         public companyL GetCompaniesListFitTrain([FromBody]CompanyDts companyDet)
         {
             return _DocMangerRepository.getCompaniesListFitTrain(companyDet.tID, companyDet.disID);
         }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}