﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OHES.eFit.WebAPI
{
    [Authorize]
    public class StatusInquiryApiController : ApiController
    {
        IStatusInquiryRepository _StatusInquiryRepository;

        public StatusInquiryApiController()
        {
            _StatusInquiryRepository = new StatusInquiryRepository();
        }
        
       //Get TraineeName List
        public TraineeList GettraineeName(int Param1)
        {
            return _StatusInquiryRepository.getTraineeName(Param1);
        }

        public TrainerList GettrainerName(int Param1)
        {
            return _StatusInquiryRepository.getTrainerName(Param1);
        }

        public void GetTraineeList(string Param1, string param2, string param3, long param4, long param5, string param6, string param7)
        {
            //return _StatusInquiryRepository.getTraineeList(Param1, param2, param3, param4, param5, param6,param7);
        }

        public void GetTrainerListPC(string Param1, string param2, string param3, long param4, long param5, string param6, string param7)
        {
            
        }

        [HttpPost, Route("api/StatusInquiryApi/GetTraineeList")]
        public List<traineeList> GetTraineeList([FromBody]InputDetails printDetails)
        {
            return _StatusInquiryRepository.getTraineeList(printDetails.companyName, printDetails.companyTypeID, printDetails.Name, printDetails.NRIC, printDetails.searchText, printDetails.pageIndex, printDetails.pageSize, printDetails.sortColumn, printDetails.sortOrder);
        }


        [HttpPost, Route("api/StatusInquiryApi/GetTrainerListPC")]
        public List<trainerListPC> GetTrainerListPC([FromBody]InputDetails printDetails)
        {
            return _StatusInquiryRepository.getTrainerListPC(printDetails.companyName, printDetails.companyTypeID, printDetails.Name, printDetails.NRIC, printDetails.searchText, printDetails.pageIndex, printDetails.pageSize, printDetails.sortColumn, printDetails.sortOrder);
        }

        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        //Get Training Trainers
        public List<trainerList> Post([FromBody]InputDetails trainerInputs)
        {
            return _StatusInquiryRepository.getActiveTrainers(trainerInputs);

        }
        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}