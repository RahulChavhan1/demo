﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OHES.eFit.WebAPI
{
    [Authorize]
    public class CertifiedTraineesApiController : ApiController
    {

        ICertifiedTraineesRepository _CertifiedTraineesRepository;
         public CertifiedTraineesApiController()
        {
            _CertifiedTraineesRepository = new CertifiedTraineesRepository();
        }

        //Get Companies List
         public companyL GetCompaniesList(int Param1)
        {
            return _CertifiedTraineesRepository.getCompaniesList(Param1);
        }

         public companyL GetCertifiedCompanyName(int Param1,int Param2)
         {
             return _CertifiedTraineesRepository.getCertifiedCompanyName(Param1, Param2);
         }

         [HttpPost, Route("api/CertifiedTraineesApi/GetDistributorCompaniesList")]
         public companyL GetDistributorCompaniesList([FromBody]CompanyDts companyDet)
         {
             return _CertifiedTraineesRepository.getDistributorCompaniesList(companyDet.CompanyName,companyDet.tID,companyDet.disID);
         }
         //Get Active Trainees
         public List<ActiveTrainees> Post([FromBody]InputDetails traineeInputs)
          
         {
             List<ActiveTrainees> traineeList=new List<ActiveTrainees>();
             
             if(traineeInputs.traineeType == 1)
             {
                 traineeList = _CertifiedTraineesRepository.getActiveTrainees(traineeInputs);
             }

             else if (traineeInputs.traineeType == 2)
             {
                 traineeList = _CertifiedTraineesRepository.getdueOfRenewal(traineeInputs);
             }

              else if (traineeInputs.traineeType == 3)
             {
                 traineeList = _CertifiedTraineesRepository.getExpiredTrainees(traineeInputs);
             }

             return traineeList;
         }

         // POST api/<controller>

        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }


        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}