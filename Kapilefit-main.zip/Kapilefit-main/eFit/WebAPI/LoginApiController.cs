﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using System.Web.Security;
using System.Web;
using FormsAuthenticationExtensions;
using System.Collections.Specialized;
using System.Web.Configuration;
using OHES.eFit.Data.Utility;

namespace OHES.eFit.WebAPI
{
    
    public class LoginApiController : ApiController
    {
        ILoginRepository _LoginRepository;

        public LoginApiController()
        {
            _LoginRepository = new LoginRepository();
        }


        // POST api/<controller>
        [AllowAnonymous]
        [HttpPost]
        public User Post([FromBody] User LoginDetails)
        {
            try
            {
                string rememberMe = "false";
                string domain = WebConfigurationManager.AppSettings["ADDomainName"];

                User LoginVM = _LoginRepository.submitLoginDetails(LoginDetails, domain);

                if (LoginVM != null)
                {
                    var ticketData = new NameValueCollection
                   {
                        {"LoginName",LoginVM.UserName},
                        {"LoginID",LoginVM.UserID},
                        {"LoginTypeID",LoginVM.companyTypeId.ToString()},
                        {"RoleID",LoginVM.RoleID.ToString()},
                        {"UserCompanyName",LoginVM.CompanyName},
                        {"CompanyID",LoginVM.CompanyID.ToString()}
                   };
                    new FormsAuthentication().SetAuthCookie(LoginVM.UserID, Convert.ToBoolean(rememberMe), ticketData);

                    LoginDetails.success = true;
                    LoginDetails.RoleID = LoginVM.RoleID;
                }
                else
                {
                    LoginDetails.success = false;
                    LoginDetails.message = "The Username or Password is incorrect !";
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return LoginDetails;
        }

        [Route("api/Login/LogOff")]
        [HttpGet]
        public string LogOff()
        {
            FormsAuthentication.SignOut();
            
            return "LogedOut";
        }
        [Route("api/LoginApi/getHitCount")]
        [HttpGet]
        public string getHitCount()
        {
            return _LoginRepository.getHitCount();
        }
        [Route("api/LoginApi/getHitCountTotal")]
        [HttpGet]
        public Int64 getHitCountTotal()
        {
            return _LoginRepository.getHitCountTotal();
        }
        
    }
}