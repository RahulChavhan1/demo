﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using FormsAuthenticationExtensions;
using System.Web.Security;
namespace OHES.eFit.WebAPI
{
    [Authorize]
    public class CustomerListingApiController : ApiController
    {

         ICustomerListingRepository _CustomerListingRepository;

         public CustomerListingApiController()
        {
            _CustomerListingRepository = new CustomerListingRepository();
        }

         public string GetDisName(Int32 Param1)
         {
             return _CustomerListingRepository.GetDisName(Param1);
         }     

         [HttpPost, Route("api/CustomerListingApi/GetDistributors")]
         public List<Distributors> GetDistributors([FromBody]InputDetails DistDetails)
         {
             return _CustomerListingRepository.getDistributors(DistDetails.companyTypeID, DistDetails.searchText, DistDetails.pageSize, DistDetails.pageIndex, DistDetails.sortColumn, DistDetails.sortOrder);
         }
         [HttpPost, Route("api/CustomerListingApi/GetDisPrivateCompanies")]
         public List<PrivateCompanies> GetDisPrivateCompanies([FromBody]InputDetails DistDetails)
         {
             return _CustomerListingRepository.getDisPrivateCompanies(DistDetails.companyId, DistDetails.searchText, DistDetails.pageSize, DistDetails.pageIndex, DistDetails.sortColumn, DistDetails.sortOrder);
         }
         [HttpPost, Route("api/CustomerListingApi/GetTrainersList")]
         public List<TrainersListDetails> GetTrainersList([FromBody]InputDetails DistDetails)
         {
             return _CustomerListingRepository.getTrainersList(DistDetails.adminId, DistDetails.companyId, DistDetails.companyPriId, DistDetails.searchText, DistDetails.pageSize, DistDetails.pageIndex, DistDetails.sortColumn, DistDetails.sortOrder);
         }
         [HttpPost, Route("api/CustomerListingApi/GetTraineesList")]
         public List<TraineesListDetails> GetTraineesList([FromBody]InputDetails DistDetails)
         {
             return _CustomerListingRepository.getTraineesList(DistDetails.adminId, DistDetails.companyId, DistDetails.companyPriId, DistDetails.trainerId, DistDetails.searchText, DistDetails.pageSize, DistDetails.pageIndex, DistDetails.sortColumn, DistDetails.sortOrder);
         }

         [HttpPost, Route("api/CustomerListingApi/GetgovtCompanies")]
         public List<govtCompanies> GetgovtCompanies([FromBody]InputDetails DistDetails)
         {
             return _CustomerListingRepository.getgovtCompanies(DistDetails.companyTypeID, DistDetails.searchText, DistDetails.pageSize, DistDetails.pageIndex, DistDetails.sortColumn, DistDetails.sortOrder, DistDetails.disCompanyName);
         }
         [HttpPost, Route("api/CustomerListingApi/GetPrivateCompanies")]
         public List<PrivateCompanies> GetPrivateCompanies([FromBody]InputDetails DistDetails)
         {
             return _CustomerListingRepository.getPrivateCompanies(DistDetails.companyTypeID, DistDetails.searchText, DistDetails.pageSize, DistDetails.pageIndex, DistDetails.sortColumn, DistDetails.sortOrder,DistDetails.disCompanyName);
         }

        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}