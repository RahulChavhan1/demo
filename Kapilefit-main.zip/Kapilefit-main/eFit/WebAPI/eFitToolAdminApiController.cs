﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.WebHost;
using System.Web.Routing;
using System.Web.SessionState;
using OHES.eFit.Data.Utility;

namespace OHES.eFit.WebAPI
{
    [Authorize]
    public class eFitToolAdminApiController : ApiController
    {

         IeFitToolAdminRepository _eFitToolAdminRepository;
         
        public eFitToolAdminApiController()
        {
            _eFitToolAdminRepository = new eFitToolAdminRepository();
        }


        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        public QuickLinksDetails GetLinkData(int Param1)
        {
            return _eFitToolAdminRepository.getLinkData(Param1);
        }

        [HttpPost, Route("api/eFitToolAdminApi/SaveLinkDetails")]
        public ActionStatus SaveLinkDetails([FromBody]QuickLinksDetails Linkdts)
        {
            return _eFitToolAdminRepository.saveLinkDetails(Linkdts);
        }

        // POST api/<controller>
        public ActionStatus Post([FromBody]UploadFormVM uploadForm)
        {
            return _eFitToolAdminRepository.saveUploadForm(uploadForm, User.Identity.Name);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }

        [HttpPost, Route("api/eFitToolAdminApi/GetQuickLinks")]
        public List<QuickLinks> GetQuickLinks([FromBody]InputDetails link)
        {
            return _eFitToolAdminRepository.getQuickLinks(link.companyTypeID,link.searchText,link.pageSize,link.pageIndex,link.sortColumn,link.sortOrder);
        }

        [Route("api/eFitToolAdminApi/GetTrainingType")]
        [HttpGet]
        public List<TrainingType> GetTrainingType()
        {
            return _eFitToolAdminRepository.getTrainingType();
        }

       
        public List<CompanyType> GetCompaniesType(int param1)
        {
            return _eFitToolAdminRepository.getCompaniesType(param1);
        }

        public companyL GetCompaniesList(int param1)
        {
            return _eFitToolAdminRepository.getCompaniesList(param1);
        }

        public trainingCompanyL GetTrainerCompanyName(int param1)
        {
            return _eFitToolAdminRepository.getTrainingCompaniesList(param1);
        }

        [HttpPost, Route("api/eFitToolAdminApi/GetTrainerName")]
        public TrainerList GetTrainerName([FromBody]CompanyDts companydts)
        {
            return _eFitToolAdminRepository.getTrainerName(companydts.CompanyName);
        }

        [HttpPost, Route("api/eFitToolAdminApi/CheckTrainingCompany")]
        public ActionStatus CheckTrainingCompany([FromBody]CompanyDts companydts)
        {
            return _eFitToolAdminRepository.CheckTrainingCompany(companydts.CompanyName);
        }

        [HttpPost, Route("api/eFitToolAdminApi/GetCompaniesDetails")]
        public List<Distributors> GetCompaniesDetails([FromBody]CompanyDts companydts)
        {
            return _eFitToolAdminRepository.getCompaniesDetails(companydts.CompanyName);
        }

        [HttpPost, Route("api/eFitToolAdminApi/GetCompaniesDetails")]
        public List<Distributors> GetCompaniesDetails(string param1)
        {
            return _eFitToolAdminRepository.getCompaniesDetails(param1);
        }

        [HttpPost, Route("api/eFitToolAdminApi/UploadTrainerPhoto")]
        public ActionStatus UploadTrainerPhoto([FromBody]CompanyDts companydts)
        {
            return _eFitToolAdminRepository.uploadTrainerPhoto(companydts.RefNo, companydts.TrainerName, companydts.TrainerCompanyID);
        }

        [HttpPost, Route("api/eFitToolAdminApi/deletePhoto")]
        public ActionStatus deletePhoto([FromBody]CompanyDts companydts)
        {
            return _eFitToolAdminRepository.DeleteImage(companydts.fieldID, companydts.RefNo, companydts.TrainerName, companydts.TrainerCompanyID);

        }

        public UploadFormVM GetActiveTrainersListdData(Int32 param1)
        {
            return _eFitToolAdminRepository.getActiveTrainersListdData(param1);
        }

        [HttpPost, Route("api/eFitToolAdminApi/CheckTrainerName")]
        public ActionStatus CheckTrainerName([FromBody]TrainingRecordVM uploadDetails)
        {
            return _eFitToolAdminRepository.CheckTrainerName(uploadDetails.TrainerCompanyName, uploadDetails.TrainerName);
        }

        [HttpPost, Route("api/eFitToolAdminApi/UploadAttach")]
        public async Task<HttpResponseMessage> UploadAttach()
        {
            try
            {
                if (!Request.Content.IsMimeMultipartContent())
                    throw new Exception(); // divided by zero
                var provider = new MultipartMemoryStreamProvider();
                await Request.Content.ReadAsMultipartAsync(provider);
                JToken json;
                if (provider.Contents[0].Headers.ContentLength > 0)
                {
                    var filename = provider.Contents[0].Headers.ContentDisposition.FileName.Trim('\"');
                    var filesize = provider.Contents[0].Headers.ContentLength / 1024;
                    var fileExtension = Path.GetExtension(filename).ToLower().ToString();

                    if (fileExtension != ".png" && fileExtension != ".jpg")
                    {
                        json = JObject.Parse("{ 'status' :'Invalid' }");
                    }
                    else
                    {
                        string type = provider.Contents[0].Headers.ContentType.MediaType;
                        var fileId = Guid.NewGuid();//await  provider.Contents[0].ReadAsStringAsync();
                        var buffer = await provider.Contents[0].ReadAsByteArrayAsync();
                        TempAttachments attach = new TempAttachments();
                        attach.fileId = fileId;
                        attach.fileName = filename;
                        attach.fileExtension = fileExtension;
                        attach.fileType = type;
                        attach.fileSize = Convert.ToInt32(filesize);
                        attach.fileContent = buffer;
                        //attach.updatedBy = "Admin";
                        //attach.updatedDate = DateTime.Now;
                        var status = _eFitToolAdminRepository.saveAttach(attach);
                        json = JObject.Parse("{ 'status' :'" + status.success + "', 'fileId' :'" + fileId + "' }");
                    }
                }
                else
                {
                    json = JObject.Parse("{ 'status' :'NoFile' }");
                }
                return new HttpResponseMessage()
                {
                    Content = new JsonContent(json)
                };
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
                return null;
                
            }
        }
        public class JsonContent : HttpContent
        {
            private readonly JToken _value;

            public JsonContent(JToken value)
            {
                _value = value;
                Headers.ContentType = new MediaTypeHeaderValue("text/html");
            }
            protected override Task SerializeToStreamAsync(Stream stream,
                TransportContext context)
            {
                var jw = new JsonTextWriter(new StreamWriter(stream))
                {
                    Formatting = Formatting.Indented
                };
                _value.WriteTo(jw);
                jw.Flush();
                return Task.FromResult<object>(null);
            }
            protected override bool TryComputeLength(out long length)
            {
                length = -1;
                return false;
            }
        }
        
    }

}