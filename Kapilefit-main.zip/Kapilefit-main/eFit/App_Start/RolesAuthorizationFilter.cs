﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace OHES.eFit.App_Start
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]


    public class RolesAuthorizationFilter : AuthorizeAttribute
    {
        public string AllowRoles { get; set; }

        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            string Roles = string.Empty; 

            if (filterContext.HttpContext.Session["RoleID"] != null)
            {
                Roles = filterContext.HttpContext.Session["RoleID"].ToString();

                var filterAttribute = filterContext.ActionDescriptor.GetFilterAttributes(true)
                               .Where(a => a.GetType() ==
                              typeof(RolesAuthorizationFilter));

                if (filterAttribute != null)
                {
                    foreach (RolesAuthorizationFilter attr in filterAttribute)
                    {
                        AllowRoles = attr.AllowRoles;
                    }
                }

                if (!AllowRoles.Contains(Roles))
                {
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { controller = "Login", action = "unauthorize" }));
                }
            }
        }
    }
}