﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using OHES.eFit.Data.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web.Mvc;
using System.Web.Routing;
using System.Linq;

namespace OHES.eFit.ActionFilters
{
    public class ReAuthorizeFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.ActionDescriptor.ActionName.ToLower() != "accessdenied")
            {
                if (filterContext.HttpContext.Session["ticketData"] == null)
                {
                    LoginRepository _LoginRepository = new LoginRepository();
                    string userId = filterContext.RequestContext.HttpContext.User.Identity.Name;
                    if (string.IsNullOrEmpty(userId))
                    {
                        Utility.AppLog("User Identity is Empty");
                    }
                    else
                    {

                        if (filterContext.HttpContext.Session["UserId"] == null)
                        {
                            userId = userId.Split('\\').Last();
                            User LoginVM = _LoginRepository.getAuthorization(userId);
                            if (!string.IsNullOrEmpty(LoginVM.UserID))
                            {
                                filterContext.HttpContext.Session["UserId"] = userId;
                                Dictionary<string, string> ticketData = new Dictionary<string, string>
                            {
                                {"LoginName",LoginVM.UserName},
                                {"LoginID",LoginVM.UserID},
                                {"LoginTypeID",LoginVM.companyTypeId.ToString()},
                                {"RoleID",LoginVM.RoleID.ToString()},
                                {"UserCompanyName",LoginVM.CompanyName},
                                {"CompanyID",LoginVM.CompanyID.ToString()}
                            };
                                filterContext.HttpContext.Session["ticketData"] = ticketData;
                                filterContext.HttpContext.Session["RoleID"] = LoginVM.RoleID.ToString();
                            }
                            else
                            {
                                filterContext.Result = new RedirectResult("~/Login/accessdenied");
                                return;
                            }
                        }
                    }
                }
            }
            base.OnActionExecuting(filterContext);
        }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
          
        }

     }
}
