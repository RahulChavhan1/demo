﻿using System.Web;
using System.Web.Optimization;

namespace OHES.eFit
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            //3rd party lib
            bundles.Add(new ScriptBundle("~/assets/scripts/lib").Include(
                             "~/Scripts/jquery-1.9.1.js",
                              "~/Scripts/jquery-ui.js",
                              //"~/Scripts/angular.js",
                              "~/Scripts/angular.min.js",
                              "~/Scripts/jquery.cycle.all.js",                     
                              "~/Scripts/cbpHorizontalMenu.js",
                              "~/Scripts/modernizr.custom.js",
                              
                              "~/Scripts/angular-ui-router.js",
                              "~/Scripts/angular-animate.js",
                              "~/Scripts/angular-sanitize.js",                     
                              "~/Scripts/ngplus-overlay.js",
                              "~/Scripts/toastr.js",                          
                              "~/Scripts/moment.js",
                              "~/Scripts/angular-ui/ui-bootstrap.js",
                              "~/Scripts/bootstrap.js",
                              "~/Scripts/bootstrap.min.js",
                              "~/Scripts/bootstrap-datepicker.min.js",
                              "~/Scripts/ng-grid-2.0.14.debug.js",
                          
                              "~/Scripts/loading-bar.js",
                              //"~/Scripts/angular-ui/ui-bootstrap-tpls.js",
                              "~/Scripts/angular-ui/ui-bootstrap-tpls.min.js",
                             //"~/Scripts/jquery-ui-1.11.2.custom/jquery-ui.js",


                             //typeAHeadDrpdown
                             //"~/Scripts/gm.typeaheadDropdown.min.js",


                              //Export
                             "~/Scripts/Export/tableExport.js",
                             "~/Scripts/Export/jquery.base64.js",
                             "~/Scripts/Export/html2canvas.js"
                            ));
            
            //Application scripts
            bundles.Add(new ScriptBundle("~/assets/scripts/app").Include(
                            "~/app/core/core.module.js",
                            "~/app/core/constants.js",
                             "~/app/core/config.js",
                             "~/app/core/authInterceptor.factory.js",
                            "~/app/blocks/logger/logger.module.js",
                            "~/app/blocks/logger/logger.js",
                            "~/app/blocks/exception/exception.module.js",
                            "~/app/blocks/exception/exception-handler.provider.js",
                            "~/app/blocks/exception/exception.js",
                             
                            
                            //Common 
                                "~/app/app.js",      
                               "~/app/blocks/common/common.module.js",
                               
                               "~/app/blocks/common/psCompareTo.js",
                               
                               "~/app/blocks/common/psUpload.directive.js",
                               "~/app/blocks/common/autoComplete.js",
                               "~/app/blocks/common/psValidationTooltip.directive.js",
                               "~/app/blocks/common/PsDialog.js",
                               "~/app/blocks/common/psFixedHeaderTable.js",
                               //"~/app/blocks/common/datePicker.js",
                               "~/app/blocks/common/psAutoExpand.directive.js",
                               //"~/app/blocks/common/gm.typeaheadDropdown.js",

                               //login
                               "~/app/login/loginApp.js",
                               "~/app/login/login.controller.js",
                               
                               //Home

                                "~/app/home/home.module.js",
                                "~/app/home/home.factory.js",
                                "~/app/home/home.shell.controller.js",
                               
                                //Home General
                                "~/app/homeGeneral/homeGeneral.module.js",
                                "~/app/homeGeneral/homeGeneral.factory.js",
                                "~/app/homeGeneral/homeGeneral.shell.controller.js",

                                //EFit
                                "~/app/eFit/eFit.core.js",
                                "~/app/eFit/eFit.shell.controller.js",

                                //Admin
                                "~/app/admin/admin.core.js",
                                "~/app/admin/admin.shell.controller.js",


                                //Homemenu
                                "~/app/homeMenu/homeMenu.module.js",
                                "~/app/homeMenu/homeMenu.shell.controller.js",

                                //ProductsMenu
                                "~/app/productsMenu/productsMenu.module.js",
                                "~/app/productsMenu/productsMenu.shell.controller.js",

                              //Customer Listing
                               "~/app/eFit/customerListing/customerListing.core.js",
                               "~/app/eFit/customerListing/customerListing.shell.controller.js",

                               //Distributors
                               "~/app/eFit/customerListing/distributors/distributors.module.js",
                               "~/app/eFit/customerListing/distributors/distributors.factory.js",
                               "~/app/eFit/customerListing/distributors/distributorsList.controller.js",

                              //Govt Companies
                               "~/app/eFit/customerListing/govtCompanies/govtCompanies.module.js",
                               "~/app/eFit/customerListing/govtCompanies/govtCompanies.factory.js",
                               "~/app/eFit/customerListing/govtCompanies/govtCompaniesList.controller.js",

                              //Private Companies
                              "~/app/eFit/customerListing/privateCompanies/privateCompanies.module.js",
                              "~/app/eFit/customerListing/privateCompanies/privateCompanies.factory.js",
                              "~/app/eFit/customerListing/privateCompanies/privateCompaniesList.controller.js",

                              //Certified Trainees
                               "~/app/eFit/certifiedTrainees/certifiedTrainees.core.js",
                               "~/app/eFit/certifiedTrainees/certifiedTrainees.shell.controller.js",

                             //Active Trainees
                            "~/app/eFit/certifiedTrainees/active/active.module.js",
                            "~/app/eFit/certifiedTrainees/active/active.factory.js",
                            "~/app/eFit/certifiedTrainees/active/activeList.controller.js",

                            //Due Of Renewal Trainees
                            "~/app/eFit/certifiedTrainees/dueOfRenewal/dueOfRenewal.module.js",
                            "~/app/eFit/certifiedTrainees/dueOfRenewal/dueOfRenewal.factory.js",
                            "~/app/eFit/certifiedTrainees/dueOfRenewal/dueOfRenewalList.controller.js",

                            //Expired Trainees
                            "~/app/eFit/certifiedTrainees/expired/expired.module.js",
                            "~/app/eFit/certifiedTrainees/expired/expired.factory.js",
                            "~/app/eFit/certifiedTrainees/expired/expiredList.controller.js",

                            //Certified Trainers
                            "~/app/eFit/certifiedTrainers/certifiedTrainers.core.js",
                            "~/app/eFit/certifiedTrainers/certifiedTrainees.shell.controller.js",

                             //Active Trainers
                            "~/app/eFit/certifiedTrainers/active/active.module.js",
                            "~/app/eFit/certifiedTrainers/active/active.factory.js",
                            "~/app/eFit/certifiedTrainers/active/activeList.controller.js",

                            //Due Of Renewal Trainers
                            "~/app/eFit/certifiedTrainers/dueOfRenewal/dueOfRenewal.module.js",
                            "~/app/eFit/certifiedTrainers/dueOfRenewal/dueOfRenewal.factory.js",
                            "~/app/eFit/certifiedTrainers/dueOfRenewal/dueOfRenewalList.controller.js",
                            
                            //Expired Trainers
                            "~/app/eFit/certifiedTrainers/expired/expired.module.js",
                            "~/app/eFit/certifiedTrainers/expired/expired.factory.js",
                            "~/app/eFit/certifiedTrainers/expired/expiredList.controller.js",

                            //Doc Manager
                            "~/app/eFit/docManager/docManager.core.js",
                            "~/app/eFit/docManager/docManager.shell.controller.js",

                            //Fit Test Record
                            "~/app/eFit/docManager/fitTestRecord/fitTestRecord.module.js",
                            "~/app/eFit/docManager/fitTestRecord/fitTestRecord.factory.js",
                            "~/app/eFit/docManager/fitTestRecord/fitTestRecordList.controller.js",

                            //Print Certificate
                            "~/app/eFit/docManager/printCertificate/printCertificate.module.js",
                            "~/app/eFit/docManager/printCertificate/printCertificate.factory.js",
                            "~/app/eFit/docManager/printCertificate/printCertificateList.controller.js",

                            //Train Trainer
                            "~/app/eFit/docManager/trainTrainer/trainTrainer.module.js",
                            "~/app/eFit/docManager/trainTrainer/trainTrainer.factory.js",
                            "~/app/eFit/docManager/trainTrainer/trainTrainerList.controller.js",

                            //Status Inquiry
                            "~/app/eFit/statusInquiry/statusInquiry.core.js",
                            "~/app/eFit/statusInquiry/statusInquiry.shell.controller.js",

                            //Trainee List
                            "~/app/eFit/statusInquiry/traineeList/traineeList.module.js",
                            "~/app/eFit/statusInquiry/traineeList/traineeList.factory.js",
                            "~/app/eFit/statusInquiry/traineeList/traineeListList.controller.js",

                            //Trainer List
                            "~/app/eFit/statusInquiry/trainerList/trainerList.module.js",
                            "~/app/eFit/statusInquiry/trainerList/trainerList.factory.js",
                            "~/app/eFit/statusInquiry/trainerList/trainerListList.controller.js",


                            //Admin - eFitTool
                              "~/app/admin/eFitTool/eFitTool.core.js",
                              "~/app/admin/eFitTool/eFitTool.shell.controller.js",
 
                            //Upload Form
                              "~/app/admin/eFitTool/uploadForm/uploadForm.module.js",
                              "~/app/admin/eFitTool/uploadForm/uploadForm.factory.js",
                              "~/app/admin/eFitTool/uploadForm/uploadForm.controller.js",
                              "~/app/admin/eFitTool/uploadForm/uploadFormList.controller.js",
                              "~/app/admin/eFitTool/uploadForm/TrainersListSummary.controller.js",
                              
                             //Quick Links
                             "~/app/admin/eFitTool/quickLinks/quickLinks.module.js",
                              "~/app/admin/eFitTool/quickLinks/quickLinks.factory.js",
                              "~/app/admin/eFitTool/quickLinks/quickLinks.controller.js",
                              "~/app/admin/eFitTool/quickLinks/quickLinksEdit.controller.js",
                              "~/app/admin/eFitTool/quickLinks/quickLinksList.controller.js",

                            //Admin - User Maintenance
                             "~/app/admin/userMaintenance/userMaintenance.core.js",
                             "~/app/admin/userMaintenance/userMaintenance.shell.controller.js",

                             //User
                             "~/app/admin/userMaintenance/user/user.module.js",
                             "~/app/admin/userMaintenance/user/user.factory.js",
                             "~/app/admin/userMaintenance/user/user.controller.js",
                             "~/app/admin/userMaintenance/user/userEdit.controller.js",

                             //PasswordMaintenance
                             "~/app/admin/userMaintenance/passwordMaintenance/passwordMaintenance.module.js",
                             "~/app/admin/userMaintenance/passwordMaintenance/passwordMaintenance.factory.js",
                             "~/app/admin/userMaintenance/passwordMaintenance/passwordMaintenance.controller.js"

                   ));

            bundles.Add(new ScriptBundle("~/assets/scripts/loginApp").Include(
                "~/app/blocks/logger/logger.module.js",
                  "~/app/blocks/logger/logger.js",
                            "~/app/blocks/exception/exception.module.js",
                            "~/app/blocks/exception/exception-handler.provider.js",
                            "~/app/blocks/exception/exception.js",
                            "~/app/blocks/router/router.module.js",
                            "~/app/blocks/router/router.js",
                             "~/app/blocks/common/common.module.js",
                             "~/app/blocks/common/psValidationTooltip.directive.js",
                            "~/app/blocks/common/psAutoExpand.directive.js",
                "~/loginApp/loginApp.js",
                "~/loginApp/core/core.module.js",
                "~/loginApp/login/login.module.js",
                "~/loginApp/login/login.factory.js",
                "~/loginApp/login/login.controller.js"

                ));

            bundles.Add(new StyleBundle("~/assets/css").Include(
                      // "~/Content/bootstrap.css",
                       "~/Content/bootstrap.min.css",
                       "~/Content/bootstrap-theme.min.css",
                       "~/Content/datepicker.min.css",

                      "~/Content/toastr.min.css",
                      "~/Content/loading-bar.css",
                      "~/Content/style.css",
                      "~/Content/component.css",
                      "~/Content/jquery-ui.css",
                      "~/Content/ng-grid.css"
                      
                      //"~/eFit/Scripts/jquery-ui-1.11.2.custom/jquery-ui.css"
                      ));

            BundleTable.EnableOptimizations = false;
        }
    }
}
