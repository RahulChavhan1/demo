﻿using OHES.eFit.ActionFilters;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            filters.Add(new ReAuthorizeFilter());
        }
    }
}
