﻿(function () {
    'use strict';

    angular
        .module('app.productsmenu')
        .controller('ProductsmenuShellCtrl', ProductsmenuShellCtrl)


    ProductsmenuShellCtrl.$inject = ['$state', '$q', '$scope', '$rootScope'];

    function ProductsmenuShellCtrl($state, $q, $scope, $rootScope) {

        //variable Declaration
        var vm = this;
        vm.ParentModule = {};

        //Menthod Declaration
        activate()

        //Method Definition
        function activate() {
        }
    }
})();
