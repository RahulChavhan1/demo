﻿(function () {
    'use strict';

    angular.module('app.admin', [
        'eFitTool.core',
        'userMaintenance.core'
    ]);
})();
