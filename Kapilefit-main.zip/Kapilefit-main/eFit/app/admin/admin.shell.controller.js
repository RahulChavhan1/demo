﻿(function () {
    'use strict';

    angular
        .module('app.admin')
        .controller('AdminCtrl', AdminCtrl);

    AdminCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function AdminCtrl($state, $stateParams, $q, $rootScope) {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'Admin Shell Crtl';
        $rootScope.showMenu = true;
        vm.AdminDetails = {};
        activate();

        function activate() {
            //$state.transitionTo('efitmenu.EfitLanding');
            //$state.transitionTo('client.details', { clientID: '2' }, { notify: true });

        }

    }

})();
