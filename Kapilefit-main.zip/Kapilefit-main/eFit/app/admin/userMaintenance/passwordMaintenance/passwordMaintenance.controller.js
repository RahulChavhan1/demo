﻿(function () {
    'use strict';

    angular
        .module('userMaintenance.passwordMaintenance')
        .controller('PasswordMaintenanceCtrl', PasswordMaintenanceCtrl)

    PasswordMaintenanceCtrl.$inject = ['$state', '$q', 'passwordMaintenanceService', 'logger', '$timeout', '$filter', '$stateParams', '$scope'];

    function PasswordMaintenanceCtrl($state, $q, passwordMaintenanceService, logger, $timeout, $filter, $stateParams, $scope) {

        // Variable Declaration
        var vm = this;
        vm.title = 'User Edit Ctrl';
        vm.PasswordDetails = {};
        $scope.UserDropdownList = [];
     
        // Method Declaration
        vm.Save = save;
        vm.validPassword = false;
        vm.errorMessage = {};
        activate();
        vm.UserName = "";

        // Method Definition
        function activate() {
            return passwordMaintenanceService.getUserName().then(function (data) {
                $scope.UserDropdownList = data.UserName;
            });
        }
        
        //Save Data
        function save(isValid) {
            if (vm.PasswordDetails.NewPassword != vm.PasswordDetails.ConfirmPassword) {             
                logger.warning("Confirm password does not match", "", "");
                vm.validPassword = true;
            }
            else
            {
                vm.errorMessage = "";
                vm.validPassword = false;
            }
            if (vm.validPassword == false) {
                if (isValid) {
                    vm.PasswordDetails.UserName = angular.element('#UserName').val();;
                    vm.PasswordDetails.UserID = angular.element('#UserID').val();;
                    return passwordMaintenanceService.savePasswordDetails(vm.PasswordDetails).then(function (data) {                  
                        if (data.success == true) {
                            logger.success(data.message, "", "");
                        }
                        else { logger.warning(data.message, "", ""); }
                    });
                }
            }
        }
    }
})();