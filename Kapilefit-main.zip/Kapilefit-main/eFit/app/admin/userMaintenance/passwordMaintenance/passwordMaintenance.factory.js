﻿(function () {
    'use strict';
    //  angular.module('ui.filters', []);
    angular
        .module('userMaintenance.passwordMaintenance', [])
        .factory('passwordMaintenanceService', passwordMaintenanceService)

    passwordMaintenanceService.$inject = ['$http', '$q', '$timeout', 'config'];

    function passwordMaintenanceService($http, $q, $timeout, config) {
        var service = {
            savePasswordDetails: savePasswordDetails,
            getUserName: getUserName
        };
        return service;
        
        function getUserName() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/UserMaintenanceAdminApi/GetUserName'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function savePasswordDetails(PasswordDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/PasswordMaintenanceApi/',
                data: JSON.stringify(PasswordDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();