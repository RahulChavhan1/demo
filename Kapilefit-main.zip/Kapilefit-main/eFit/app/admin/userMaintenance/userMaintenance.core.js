﻿(function () {
    'use strict';

    angular.module('userMaintenance.core', [
        'userMaintenance.user',
        'userMaintenance.passwordMaintenance'
    ]);
})();
