﻿(function () {
    'use strict';

    angular
        .module('userMaintenance.core')
        .controller('userMaintenanceCtrl', userMaintenanceCtrl);

    userMaintenanceCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function userMaintenanceCtrl($state, $stateParams, $q, $rootScope) {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'Certified Trainees Shell';
        $rootScope.showMenu = true;
        vm.CertifiedTraineesDetails = {};
        activate();


        function activate() {

            //$state.transitionTo('client.details', { clientID: '2' }, { notify: true });

        }

    }

})();
