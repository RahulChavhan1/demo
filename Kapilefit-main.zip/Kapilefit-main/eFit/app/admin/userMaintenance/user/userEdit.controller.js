﻿(function () {
    'use strict';

    angular
        .module('userMaintenance.user')
        .controller('UserEditCtrl', UserEditCtrl)
    UserEditCtrl.$inject = ['$state', '$q', 'userService', 'logger', '$timeout', '$filter', '$stateParams', '$scope','config'];

    function UserEditCtrl($state, $q, userService, logger, $timeout, $filter, $stateParams, $scope, config) {


        // Variable Declaration
        var vm = this;
        vm.title = 'User Edit Ctrl';
        vm.UserDetails = {};
        vm.UserSaveDetails = {};
        vm.CompanyList = [];
        vm.RoleList = {};
        vm.CompanyDts = {};
        vm.ResetedPassword = "";
        vm.RstPwd = false;
        $scope.CompanyDropdownList = [];
        $stateParams.userID = $stateParams.userID == "" ? null : $stateParams.userID;
        $stateParams.RoleID = $stateParams.RoleID == "" ? null : $stateParams.RoleID;
        vm.newPwdValid = false;      
        vm.UserSaveDetails.ConfirmPassword = '';
        vm.isEdit = false;
        vm.UserNameDisable = false;
        vm.CompanyDisable = false;


        // Method Declaration
        vm.Save = save;
        vm.ResetPwd = ResetPwd;
        vm.checkCompanyName = checkCompanyName;
        vm.retypePwdCheck = retypePwdCheck;
        vm.validPassword = false;
        vm.errorMessage = {};
        vm.loadCompanyName = loadCompanyName;
        vm.delete = deleteUser;
        vm.canceldelteDialog = canceldelteDialog;
        vm.deleteConfirm = deleteConfirm;

        //activate();

        activate();


        // Method Definition
        function activate() {
            vm.CompanyDisable = true;
            //$stateParams.companyTypeId = 3;
            getRoleList($stateParams.companyTypeId);
            if ($stateParams.userID != null) {
                
                vm.isEdit = true;
                vm.UserNameDisable = true;
                vm.disableControls = true,
                vm.deleteShow = true;
                vm.editShow = true;
                vm.saveShow = false;
                vm.CompanyDisable = false;
            }
            else {
                vm.isEdit = false;
            }
        }

        function loadCompanyName(RoleID) {
           
            vm.UserSaveDetails.CompanyName = "";
            if (RoleID != "") {
                if (RoleID == 1 || RoleID == 2) {
                    vm.UserSaveDetails.CompanyName = "3M Technologies (S) Pte Ltd";
                    vm.CompanyDts.CompanyName = vm.UserSaveDetails.CompanyName;
                    vm.CompanyDisable = true;
                }
                else {
                    vm.CompanyDisable = false;
                    var promises = [getCompaniesList(RoleID)];
                    return $q.all(promises).then(function () {
                    });
                }
            }

        }

        function getUserListEdit(userID) {
            vm.CompanyDisable = false;
            return userService.getUserData(userID).then(function (data) {
                loadCompanyName(data.RoleID)
                vm.UserSaveDetails = new UserSaveDetails(data);
                
            });
        }


        function checkCompanyName() {
            vm.UserSaveDetails.CompanyName = angular.element('#inputCompanyName').val();

            vm.CompanyDts.CompanyName = vm.UserSaveDetails.CompanyName;
            return userService.checkCompanyName(vm.CompanyDts).then(function (data) {
                if (data.success == true) {
                }
                else {
                    logger.warning(data.message, "", "");
                }
            });
        }

        function getCompaniesList(comID) {
            return userService.getCompaniesList(comID).then(function (data) {
                
                $scope.CompanyDropdownList = data.companyName;              
                    	$scope.dts = [
		{
		    name: "Mary"
		},
		{
		    name: "Jane"
		},
		{
		    name: "John"
		},
		{
		    name: "Fred"
		}
                    	];

            });
        }
        function getRoleList(RoleID) {
            return userService.getRoleList(RoleID).then(function (data) {
                vm.RoleList = data;
                if ($stateParams.userID != null) {
                    getUserListEdit($stateParams.userID);
                }
            });
        }

        function deleteUser() {
            return userService.deleteUser($stateParams.userID).then(function (data) {
                if (data.success == true) {
                    logger.success(data.message, "", "");
                    $state.transitionTo('adminmenu.UserList');
                }
            });
        }

        function deleteConfirm() {
            vm.showdeleteModal = !vm.showdeleteModal;
        }
        
        function canceldelteDialog() {
            vm.showdeleteModal = !vm.showdeleteModal;
        }

        //Reset Password
        function ResetPwd() {
            return userService.resetPwd($stateParams.userID).then(function (data) {
                vm.ResetedPassword = data.key;
                vm.RstPwd = true;
                vm.UserSaveDetails.ResetPassword = vm.ResetedPassword;
                
            });
        }


        //Save Data
        function save(isValid) {
            vm.UserSaveDetails.CompanyName = angular.element('#inputCompanyName').val();

            vm.CompanyDts.CompanyName = vm.UserSaveDetails.CompanyName;
            return userService.checkCompanyName(vm.CompanyDts).then(function (data) {
                if (data.success == true) {

                  

                    if (vm.UserSaveDetails.Password == "" || vm.UserSaveDetails.ConfirmPassword == "") {
                        vm.errorMessage = "";
                    }
                    else if (vm.UserSaveDetails.Password != vm.UserSaveDetails.ConfirmPassword) {


                        //vm.errorMessage = "Re-type password does not match";
                        logger.warning("Confirm password does not match", "", "");
                        vm.validPassword = true;

                    }

                    else {
                        vm.errorMessage = "";
                        vm.validPassword = false;
                    }
                    if (vm.validPassword == false) {
                        if (isValid) {
                            vm.UserSaveDetails.CompanyName = angular.element('#inputCompanyName').val();
                            return userService.saveUserDetails(vm.UserSaveDetails).then(function (data) {
                                if (data.success == true) {
                                    logger.success(data.message, "", "");
                                    $state.transitionTo('adminmenu.UserList');
                                }
                                else { logger.warning(data.message, "", ""); }

                            });
                        }
                    }

                    if ($stateParams.userID != null) {

                        if (isValid) {
                            vm.UserSaveDetails.CompanyName = angular.element('#inputCompanyName').val();
                            return userService.saveUserDetails(vm.UserSaveDetails).then(function (data) {
                                if (data.success == true) {
                                    logger.success(data.message, "", "");
                                    $state.transitionTo('adminmenu.UserList');
                                }
                                else { logger.warning(data.message, "", ""); }

                            });
                        }
                    }
                }
                else {
                    logger.warning(data.message, "", "");
                }
            });
            
        }
        function UserSaveDetails(data) {
            return {
                UserID: data.UserID,
                UserName: data.UserName,
                CompanyID: data.CompanyID,
                EmailID: data.EmailID,
                RoleID: data.RoleID,
                CompanyName: data.CompanyName
            }
        }
        function retypePwdCheck() {
           
            if (vm.UserSaveDetails.Password != vm.UserSaveDetails.ConfirmPassword) {
                vm.validPassword = true;
                vm.errorMessage = "Confirm password does not match";         
                                
            }


        }
    }


   
})();