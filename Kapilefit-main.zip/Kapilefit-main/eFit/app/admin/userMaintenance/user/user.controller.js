﻿(function () {
    'use strict';

    angular
        .module('userMaintenance.user')

        .controller('UserNewCtrl', UserNewCtrl)

    UserNewCtrl.$inject = ['$state', '$q', 'userService', 'logger', '$timeout', '$filter', '$stateParams','$scope','config'];

    function UserNewCtrl($state, $q, userService, logger, $timeout, $filter, $stateParams, $scope,config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'User Details Ctrl';
        vm.UserDetails = {};
        vm.tempDetails = {};
        vm.InputDetails = {};
        vm.InputDetails.searchText = "";
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.tempIndex = 1;
        vm.showPage = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;


        // Method Declaration
        vm.SearchUsers = SearchUsers;
        vm.Usertable = Usertable;
        vm.sort = sort;
        vm.ExportToExcel = ExportToExcel;
        vm.setPage = setPage;
        vm.editUser = editUser;
        //vm.paginate = paginate;
        //activate();


        activate();

        // Method Definition
        function activate() {
            $stateParams.companyTypeId = 3;
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            var promises = [getUsersList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }

        function getUsersList(InputDetails) {
            //vm.UserDetails = {};
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return userService.getUsers(InputDetails).then(function (data) {

                vm.UserDetails = data;
                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }
            });
        }
      

        //Searching
        function SearchUsers(search) {
            vm.Usertable(search)
        }
        function Usertable(search) {
            vm.InputDetails.searchText = search;
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            setPage(0);
            //var promises = [getUsersList(vm.InputDetails), ];
            //return $q.all(promises).then(function () {
            //});
        }
        
        // Export To Excel
        function ExportToExcel() {
           
            window.location.href = config.baseURL + "UserMaintenanceAdmin/ExportUserSummary?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems;
        }

        //Sorting
        function sort(newSortField) {
            //vm.UserDetails = {};
            if (vm.sortField == newSortField)
                //vm.descending = !vm.descending;
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            var promises = [getUsersList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        //Paging       
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }

            var ps = [];
            var start;

            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }

            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {

            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }

            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage +1;

            if (cPage != 0) {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getUsersList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;
            if (cPage != vm.pageCount()) {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getUsersList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };

 

        function editUser(UserID)
        {
            $state.transitionTo('adminmenu.NewUser', { userID: UserID }, { notify: true });
        };
        function setPage(n) {
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            var promises = [getUsersList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };
        vm.columDefin = [
                {
                    cellTemplate: '<div class="link3"><a ng-click="vm.editUser(row.entity.UserID)">{{row.getProperty(\'UserID\')}}</a></div>',
                    field: 'UserID', displayName: 'User ID', width: '25%'
                },

            { field: 'UserName', displayName: 'Username', width: '25%' },
            { field: 'EmailID', displayName: 'Email ID', width: '35%' },
            { field: 'CompanyName', displayName: 'Company Name', width: '30%' }];


        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.UserGrid = {
            data: 'vm.UserDetails',
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            multiSelect: false,
            displaySelectionCheckbox: false,
            enableColumnResize: true,
            columnDefs: vm.columDefin
        };

        $scope.$watch('UserGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            if ($scope.sortInfo.fields[0] == "") {
            }
            else {
                sort($scope.sortInfo.fields[0]);
            }
        }, true);
    }
})();
