﻿(function () {
    'use strict';
    //  angular.module('ui.filters', []);
    angular
        .module('userMaintenance.user', ['gm.typeaheadDropdown'])
        .factory('userService', userService)

    userService.$inject = ['$http', '$q', '$timeout', 'config'];

    function userService($http, $q, $timeout, config) {
        var service = {
            getCompaniesList: getCompaniesList,
            getUsers: getUsers,
            getUserData: getUserData,
            getRoleList: getRoleList,
            saveUserDetails: saveUserDetails,
            checkCompanyName: checkCompanyName,
            resetPwd: resetPwd,
            Logout: Logout,
            deleteUser: deleteUser,
        };
        return service;
        function getCompaniesList(companyTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/UserMaintenanceAdminApi/GetCompaniesListUser/' + companyTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getRoleList(roleID) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/UserMaintenanceAdminApi/GetRoleList/' + roleID, data: {
                    id: roleID
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getUserData(Id) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/UserMaintenanceAdminApi/GetUsersData/' + Id
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
       
        function saveUserDetails(UserDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/UserMaintenanceAdminApi/',
                data: JSON.stringify(UserDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function resetPwd(UserID) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/UserMaintenanceAdminApi/ResetPwd/' + UserID, data: {
                    id: UserID
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        function checkCompanyName(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/UserMaintenanceAdminApi/CheckCompanyName',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getUsers(UserDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetUsers',
                data: JSON.stringify(UserDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function deleteUser(Id) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/UserMaintenanceAdminApi/DeleteUser/' + Id
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

    }
})();