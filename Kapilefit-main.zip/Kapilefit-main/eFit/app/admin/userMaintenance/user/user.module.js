﻿(function () {
    'use strict';

    angular.module('userMaintenance.user', [

    ]);
})();