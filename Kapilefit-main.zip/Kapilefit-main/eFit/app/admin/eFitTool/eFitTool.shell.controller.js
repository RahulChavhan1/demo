﻿(function () {
    'use strict';

    angular
        .module('eFitTool.core')
        .controller('eFitToolCtrl', eFitToolCtrl);

    eFitToolCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function eFitToolCtrl($state, $stateParams, $q, $rootScope) {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'Certified Trainees Shell';
        $rootScope.showMenu = true;
        vm.CertifiedTraineesDetails = {};
        activate();


        function activate() {            

        }

    }

})();
