﻿(function () {
    'use strict';

    angular.module('eFitTool.core', [
        'eFitTool.uploadForm',
        'eFitTool.quickLinks'
    ]);
})();
