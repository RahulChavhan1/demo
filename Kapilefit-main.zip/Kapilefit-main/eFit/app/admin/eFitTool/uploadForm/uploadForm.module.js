﻿(function () {
    'use strict';

    angular.module('eFitTool.uploadForm', [

    ]);
})();