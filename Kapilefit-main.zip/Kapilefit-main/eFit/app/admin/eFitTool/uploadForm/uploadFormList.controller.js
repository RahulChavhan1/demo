﻿(function () {
    'use strict';

    angular
        .module('eFitTool.uploadForm')

        .controller('TrainerRecordListCtl', TrainerRecordListCtl)

    TrainerRecordListCtl.$inject = ['$state', '$q', 'uploadFormService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function TrainerRecordListCtl($state, $q, uploadFormService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'TrainerList Details Ctrl';
        vm.trainerListDetails = {};
        vm.tempDetails = {};
        vm.searchText = "";
        vm.pageSize = 50;
        vm.pageIndex = 1;
        vm.sortColumn = "";
        vm.sortOrder = true;
        vm.tempIndex = 1;
        vm.showPage = false;
        vm.ReferenceNo = "";
        vm.PicId = "";
        vm.TrainerName = "";
        vm.TrainerCompanyID = "";
        vm.CompanyDts = {};

        vm.InputDetails = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 0;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.traineeType = 2;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        vm.showImageUpload = false;
        vm.showDeleteModal = false;
        vm.uploadComplete = uploadComplete;
        vm.validateFiles = validateFiles;
        vm.deletePhoto = deletePhoto;

        // Method Declaration
        vm.SearchtrainerList = SearchtrainerList;
        vm.trainerListtable = trainerListtable;
        vm.sort = sort;
        vm.ExportToExcel = ExportToExcel;
        vm.cancelDialog = cancelDialog;
        vm.cancelDeleteDialog = cancelDeleteDialog;
        vm.setPage = setPage;
       

        activate();

        // Method Definition
        function activate() {
            vm.InputDetails.TrainingTypeID = 2;
            vm.InputDetails.TrainingTypeID = 2;
            vm.InputDetails.adminId = 1;
            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }

        function gettrainerlist(InputDetails) {
            vm.trainerListDetails = {};

            return uploadFormService.gettrainerlist(InputDetails).then(function (data) {       
                vm.trainerListDetails = data;
                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                    $scope.totalItemsExp = data[0].TotalRecordsExp;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }
            });
        }
        function cancelDialog() {

            vm.showImageUpload = !vm.showImageUpload;

        }
        function cancelDeleteDialog() {
            vm.showDeleteModal = !vm.showDeleteModal;
        }


        //Searching
        function SearchtrainerList(search) {
            vm.InputDetails.pageIndex = 1;
            vm.trainerListtable(search)
        }
        function trainerListtable(search) {
            vm.InputDetails.searchText = search;
            setPage(0);           
        }
        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)         
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        // Export To Excel
        function ExportToExcel(tTID, searchText, sortColumn, sortOrder) {

            window.location.href = config.baseURL + "StatusInquiry/ExportAdmintrainerSummary?searchText=" + encodeURIComponent(searchText) + "&CompanyName=" + encodeURIComponent(vm.InputDetails.companyName) + "&TrainingDate=" + vm.InputDetails.trainingDate + "&TTID=" + tTID + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItemsExp;
        }
        //Paging
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }
            var ps = [];
            var start;
            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }
            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;
            if (cPage != 0) {
                var promises = [gettrainerlist(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;
            if (cPage != vm.pageCount()) {
                var promises = [gettrainerlist(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };
        function setPage(n) {
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;
            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        vm.uploadImage = function (RefNo, picId, TrainerName, TrainerCompanyID) {
            vm.PicId = picId;
            vm.ReferenceNo = RefNo;
            vm.TrainerName = TrainerName;
            vm.TrainerCompanyID = TrainerCompanyID;
            vm.showImageUpload = !vm.showImageUpload;

        }
        vm.deleteImage = function (RefNo, picId, TrainerName, TrainerCompanyID) {
            vm.PicId = picId;
            vm.ReferenceNo = RefNo;
            vm.TrainerName = TrainerName;
            vm.TrainerCompanyID = TrainerCompanyID;
            vm.showDeleteModal = !vm.showDeleteModal;
        }

        function deletePhoto(fileId) {
            vm.CompanyDts.RefNo = vm.ReferenceNo;
            vm.CompanyDts.fieldID = fileId;
            vm.CompanyDts.TrainerName = vm.TrainerName;
            vm.CompanyDts.TrainerCompanyID = vm.TrainerCompanyID;
            uploadFormService.deletePhoto(vm.CompanyDts).then(function (data) {
                if (data.success == true) {
                    vm.showDeleteModal = !vm.showDeleteModal;
                    activate();
                }
            });
        }

        function uploadComplete(content, isComplete) {

            if (isComplete == true) {
                vm.showModal = !vm.showModal;

                var response = JSON.parse(content)
                vm.trainerListDetails.TrainerPicFileId = response.fileId;
                if (response.status == "True") {
                    vm.CompanyDts.RefNo = vm.ReferenceNo;
                    vm.CompanyDts.TrainerName = vm.TrainerName;
                    vm.CompanyDts.TrainerCompanyID = vm.TrainerCompanyID;
                    uploadFormService.saveUploadTrainerPhoto(vm.CompanyDts).then(function (data) {
                        if (data.success == true) {
                            vm.showImageUpload = !vm.showImageUpload;
                            activate();
                        }
                    });
                    
                }
                
                else if (response.status == "Invalid") {
                    logger.warning("Select a image file ");
                }
                else if (response.status == "error") {
                    logger.error("Error occurred  in File Upload ");
                }
                else if (response.status == "NoFile") {
                    logger.warning("Select a file");
                }

            }
        }
        function validateFiles(e) {
            if (e.target.files.length > 0) {
                if (e.target.files[0].size / 1024 / 1024 >= 15) {
                    logger.warning("File Size should be less then 15MB");
                    angular.element("#attachfilepath").val(null);
                }
            }
        };


        //ng- Grid Options
        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.trainerPhotoGrid = {
            data: 'vm.trainerListDetails',
            rowHeight: 60,
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            multiSelect: false,
            displaySelectionCheckbox: false,
            enableColumnResize: true,
            columnDefs: [
                {
                    cellTemplate: '<div class="trainee_photo"> <div class="user_img"><img ng-src="/efitps/eFitToolAdmin/RetrieveImage/?fileId={{row.entity.TrainerPicFileId}}" ng-if="row.entity.TrainerPicFileId" /><div class="def_user_img" ng-if="!row.entity.TrainerPicFileId" /></div><div class="edit_icons"><a ng-click="vm.uploadImage(row.entity.RefNo,row.entity.TrainerPicFileId,row.entity.TrainerName,row.entity.TrainerCompanyID)"><i class="edit_ic"></i></a><a ng-click="vm.deleteImage(row.entity.RefNo,row.entity.TrainerPicFileId,row.entity.TrainerName,row.entity.TrainerCompanyID)" ng-if="row.entity.TrainerPicFileId"><i class="trush_i"></i></a></div></div>',
                    displayName: 'Trainer Photo', width: '20%'
                },
            
            { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
            { field: 'TrainerName', displayName: 'Trainer Name', width: '20%' },
            { field: 'TrainerCompanyName', displayName: 'Trainer Company Name', width: '20%' },
            { field: 'Email', displayName: 'Email ID', width: '20%' }, ]
        };

        $scope.$watch('trainerPhotoGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            if ($scope.sortInfo.fields[0] == "") {
            }
            else {
                sort($scope.sortInfo.fields[0]);
            }
        }, true);
    }
})();
