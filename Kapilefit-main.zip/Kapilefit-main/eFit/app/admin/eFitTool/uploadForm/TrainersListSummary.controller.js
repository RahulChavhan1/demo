﻿(function () {
    'use strict';

    angular
        .module('eFitTool.uploadForm')

        .controller('TrainerActiveSummaryListCtl', TrainerActiveSummaryListCtl)

    TrainerActiveSummaryListCtl.$inject = ['$state', '$q', 'uploadFormService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function TrainerActiveSummaryListCtl($state, $q, uploadFormService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'Trainers Active List Details Ctrl';
        vm.TrainerActiveListDetails = {};
        $scope.CompanyDropdownList = [];
        vm.tempDetails = {};
        vm.CompanyDts = {};
        vm.searchText = "";
        vm.pageSize = 50;
        vm.pageIndex = 0;
        vm.sortColumn = "RefNo";
        vm.sortOrder = true;
        vm.tempIndex = 1;
        vm.showPage = false;
        vm.ReferenceNo = "";
        vm.InputDetails = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 0;
        vm.InputDetails.sortColumn = "TrainingDate";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.traineeType = 1;    
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        vm.showImageUpload = false;
        vm.trainingDate = "";
        vm.searchText = "";
        $scope.totalItems = 0;

        // Method Declaration
        vm.SearchtrainerList = SearchtrainerList;
        vm.trainerListtable = trainerListtable;
        vm.sort = sort;
       // activate();
        vm.ExportToExcel = ExportToExcel;
        vm.LoadTrainerListDetails = LoadTrainerListDetails;
        vm.setPage = setPage;
        vm.editTrainerRecord = editTrainerRecord;

        activate();


        function activate() {

            $stateParams.companyTypeId = 3;
            return uploadFormService.getCompaniesListDetails($stateParams.companyTypeId).then(function (data) {
                $scope.CompanyDropdownList = data.companyName;
                LoadTrainerListDetails(vm.InputDetails.companyName);
            });

        }
        function LoadTrainerListDetails(CompanyName) {
            $stateParams.companyName = angular.element('#company_name').val();
            $stateParams.trainingDate = vm.trainingDate;
            vm.InputDetails.companyName = angular.element('#company_name').val();
            vm.InputDetails.trainingDate = vm.trainingDate;
            vm.InputDetails.searchText = vm.searchText;
            //vm.InputDetails.TrainingTypeID = 2;
            //if (vm.InputDetails.companyName != "" || vm.trainingDate != "" || vm.searchText != "") {
                setPage(0);
            //}
            //else {
            //    logger.warning("Please select any one from the text boxes", "", "");
            //    vm.TrainerActiveListDetails = {};
            //    $scope.totalItems = 0;
            //}
            
        }
        function gettrainerlist(InputDetails) {
            vm.TrainerActiveListDetails = {};
            if (vm.InputDetails.companyName != null || vm.trainingDate != "" || vm.searchText != "") {
        
                return uploadFormService.getActiveTrainersList(InputDetails).then(function (data) {
                    //alert(JSON.stringify(data));
                    vm.TrainerActiveListDetails = data;
                    vm.tempDetails = data;
                    if (data.length > 0) {
                        vm.showPage = true;
                        $scope.totalItems = data[0].TotalRecords;
                    }
                    else {
                        vm.showPage = false;
                        $scope.totalItems = 0;
                    }
                });
            }
            else {
                //logger.warning("Please select any one from the text boxes", "", "");
            }
          
        }

        //Searching
        function SearchtrainerList(search) {
            vm.InputDetails.pageIndex = 1;
            vm.trainerListtable(search)
        }
        function trainerListtable(search) {
            vm.InputDetails.searchText = search;
            vm.InputDetails.companyName = angular.element('#company_name').val();
            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }
        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
                //vm.descending = !vm.descending;
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        // Export To Excel
        function ExportToExcel(CompanyName, searchText, sortColumn, sortOrder) {
          
            window.location.href = config.baseURL + "StatusInquiry/ExportAdmintrainerList?searchText=" + encodeURIComponent(searchText) + "&CompanyName=" + encodeURIComponent(vm.InputDetails.companyName) + "&TrainingDate=" + vm.InputDetails.trainingDate + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems;
        }

        //Paging
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }

            var ps = [];
            var start;

            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }

            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {

            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }

            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage+1;

            if (cPage != 0) {
                var promises = [gettrainerlist(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;

            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }

            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;

            if (cPage != vm.pageCount()) {
                var promises = [gettrainerlist(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        function setPage(n) {
            //alert(n);
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;

            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });



        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };


        //ng-Grid Options
        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.trainerRecordGrid = {
            data: 'vm.TrainerActiveListDetails',
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            multiSelect: false,
            displaySelectionCheckbox: false,
            enableColumnResize: true,
            columnDefs: [
                {
                    cellTemplate: '<div style="padding:5px;"><a ng-click="vm.editTrainerRecord(row.entity.RefNo,row.entity.TrainingTypeID)">{{row.getProperty(\'TrainingDate\')}}</a></div>',
                    field: 'TrainingDate', displayName: 'Training Date', width: '20%'
                },
            { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
            { field: 'TrainingTypeName', displayName: 'Training Type Name', width: '20%' },
            { field: 'TopicsCovered', displayName: 'Topics Covered', width: '20%' },
            { field: 'TrainerCompanyName', displayName: 'Trainer Company Name', width: '20%' },
            { field: 'TrainerName', displayName: 'Trainer Name', width: '20%' }]
        };

        $scope.$watch('trainerRecordGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.fields[0] == "TrainingTypeName")
            {
                if ($scope.sortInfo.directions[0] == "asc")
                { vm.descending = true; }
                else
                { vm.descending = false; }
                sort("TrainingType");
            }
            else
            {
                if ($scope.sortInfo.directions[0] == "asc")
                { vm.descending = true; }
                else
                { vm.descending = false; }
                if ($scope.sortInfo.fields[0] == "") {
                }
                else {
                    sort($scope.sortInfo.fields[0]);
                }
            }
            
        }, true);

        function editTrainerRecord(RefNo, TrainingTypeID) {
            $state.transitionTo('adminmenu.UploadForm', { trainerId: RefNo, trainingTypeId: TrainingTypeID }, { notify: true });
        };

       
    }
})();
