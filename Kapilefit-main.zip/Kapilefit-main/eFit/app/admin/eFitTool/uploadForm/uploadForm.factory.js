﻿(function () {
    'use strict';
    //  angular.module('ui.filters', []);
    angular
        .module('eFitTool.uploadForm', [])
        .factory('uploadFormService', uploadFormService)

    uploadFormService.$inject = ['$http', '$q', '$timeout', 'config'];

    function uploadFormService($http, $q, $timeout, config) {
        var service = {
            getTrainingType: getTrainingType,
            getCompaniesList: getCompaniesList,
            getCompaniesType: getCompaniesType,
            getTrainerCompanyList : getTrainerCompanyList,
            getTrainerList : getTrainerList,
            getCompaniesDetails: getCompaniesDetails,
            importExcel: importExcel,
            saveUploadFormDetails : saveUploadFormDetails,
            getdueofrenewalTrainers: getdueofrenewalTrainers,
            saveUploadTrainerPhoto : saveUploadTrainerPhoto,
            gettrainerlist: gettrainerlist,
            getActiveTrainersList: getActiveTrainersList,
            getActiveTrainersListdData: getActiveTrainersListdData,
            getCompaniesListDetails: getCompaniesListDetails,
            deletePhoto: deletePhoto,
            checkTrainingCompany: checkTrainingCompany,
            checkTrainerName: checkTrainerName,
            checkCompanyName: checkCompanyName,
            Logout: Logout
        };
        return service;
        function getCompaniesListDetails(companyTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/CertifiedTraineesApi/GetCompaniesList/' + companyTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function importExcel(file, datas)
        {
            var deferred = $q.defer();
            $http({
                method: "post",
                url: config.baseURL + 'api/eFitToolAdminApi/ImportExcel',
                data: datas,
                file: file,
                async: true
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getCompaniesDetails(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/GetCompaniesDetails',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        
    
        function getCompaniesList(companyTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetCompaniesList/' + companyTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        function getCompaniesType(CompanyTrainingTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetCompaniesType/' + CompanyTrainingTypeId, data: {
                    id: CompanyTrainingTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTrainerCompanyList(companyTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetTrainerCompanyName/' + companyTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        //function getTrainerList(companyName) {
        //    var deferred = $q.defer();
        //    $http({
        //        method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetTrainerName/' + companyName, data: {
        //            id: companyName
        //        }
        //    }).success(deferred.resolve).error(deferred.reject);
        //    return deferred.promise;
        //}

        function getTrainerList(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/GetTrainerName',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        function getTrainingType() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetTrainingType'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;

        }
        function saveUploadFormDetails(UploadDetails, AttendanceDetails,CompaniesDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/',
                data: JSON.stringify({ trainingRecord: UploadDetails, trainingAttendance: AttendanceDetails, companiesDetails: CompaniesDetails }),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getdueofrenewalTrainers() { }
        function gettrainerlist(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/TrainingTrainerApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
      
      
        function saveUploadTrainerPhoto(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/UploadTrainerPhoto',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        function getActiveTrainersList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/StatusInquiryApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getActiveTrainersListdData(Id) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetActiveTrainersListdData/' + Id
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function deletePhoto(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/deletePhoto',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        //function checkTrainingCompany(TrainerCompanyName) {
        //    var deferred = $q.defer();
        //    $http({
        //        method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/CheckTrainingCompany/' + TrainerCompanyName, data: {
        //            id: TrainerCompanyName
        //        }
        //    }).success(deferred.resolve).error(deferred.reject);
        //    return deferred.promise;
        //}

        function checkTrainingCompany(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/CheckTrainingCompany',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        function checkTrainerName(UploadDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/CheckTrainerName',
                data: JSON.stringify(UploadDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function checkCompanyName(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/UserMaintenanceAdminApi/CheckCompanyName',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();