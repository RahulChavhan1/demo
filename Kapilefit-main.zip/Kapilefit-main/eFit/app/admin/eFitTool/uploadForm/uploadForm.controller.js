﻿(function () {
    'use strict';

    angular
        .module('eFitTool.uploadForm')

        .controller('UploadFormCtrl', UploadFormCtrl)

    UploadFormCtrl.$inject = ['$state', '$q', 'uploadFormService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function UploadFormCtrl($state, $q, uploadFormService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'UploadForm Ctrl';
        vm.UploadDetails = {};
        vm.CompanyDts = {};
        vm.CompaniesDetails = {};
        //vm.CompaniesDetails.CompanyName = "";
        vm.AttendanceDetails = [];
        vm.AttendanceDetailsSlice = [];
        vm.TrainingTypeDD = {};
        vm.CompaniesType = {};
        $scope.companiesList = [];
        $scope.TrainerNameList = [];
        $scope.TrainerCompanyList = [];
        vm.tempDetails = {};
        vm.searchText = "";
        vm.showUploadExcel = false;
        vm.trainerDisable = true;
        vm.companyNameDisable = false;
        vm.companyDetailsDisable = false;
        vm.trainerCompanyDisable = false;

        vm.showRecordExists = false;
        $stateParams.trainerId = $stateParams.trainerId == 0 ? null : $stateParams.trainerId;
        $stateParams.trainingTypeId = $stateParams.trainingTypeId == "" ? 0 : $stateParams.trainingTypeId;
        
        vm.index = 0;

        // Method Declaration
        vm.LoadCompanyName = LoadCompanyName;
        vm.LoadCompanyDetails = LoadCompanyDetails;
        vm.Dynamictxt = Dynamictxt;
        vm.DeleteUpAttendance = DeleteUpAttendance;
        vm.Save = save;
        vm.validateFiles = validateFiles;
        vm.uploadComplete = uploadComplete;  
        vm.onFileSelect = onFileSelect;
        vm.GetTrainerName = getTrainerList;
        vm.LoadCompanyType = LoadCompanyType;
        vm.cancelImportDialog = cancelImportDialog;
        vm.checkTrainingCompany = checkTrainingCompany;
        vm.validateMultipleEmailsCommaSeparated = validateMultipleEmailsCommaSeparated
        vm.cancelAlert = cancelAlert;


        //Role Authentication
        if (config.roleTicketId == 1) {
            activate();
        }
        else {
            uploadFormService.Logout().then(function (data) {
                if (data == "LogedOut") {
                    window.location = config.baseURL + "Login/index";
                }
            });
        }


        // Method Definition
        function activate() {
            //Dynamictxt();
            var promises = [getTrainingTypeList(), getTrainerCompanyList(1), getCompaniesType($stateParams.trainingTypeId)
            ];
            if ($stateParams.trainerId != null) {
                var promises = [getActiveTrainersListdData($stateParams.trainerId)];
            
                return $q.all(promises).then(function () {
                    //logger.info('Activated');
                });
            }
            vm.AttCount = vm.AttendanceDetails.length;
        }


        function validateEmail(field) {
            var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;
            return (regex.test(field)) ? true : false;
        }

        
        function validateMultipleEmailsCommaSeparated() {
            var value = angular.element('#inputuploademailId').val();
            if (value != '') {
                var result = value.split(",");
                for (var i = 0; i < result.length; i++) {
                    if (result[i] != '') {
                        if (!validateEmail(result[i])) {
                            //emailcntl.focus();
                            logger.warning("Enter valid email id", "", "");
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        function getTrainingTypeList() {
            return uploadFormService.getTrainingType().then(function (data) {                
                vm.TrainingTypeDD = data;
                //getCompaniesType()
            });
        }
        function getCompaniesType(CompanyTrainingTypeId) {
            return uploadFormService.getCompaniesType(CompanyTrainingTypeId).then(function (data) {
                vm.CompaniesType = data;
              
            });
        }
        function getTrainerCompanyList(companyId)    {
            return uploadFormService.getTrainerCompanyList(companyId).then(function (data) {
                $scope.TrainerCompanyList = data.companyName;
            });
        }
        function getTrainerList(companyName) {
            var companyNameIn;
            companyNameIn = angular.element('#inputNameofTraining').val();
            if (companyNameIn != "") {
                vm.CompanyDts.CompanyName = companyNameIn;
                return uploadFormService.getTrainerList(vm.CompanyDts).then(function (data) {
                    //if (data.company == true) {
                    $scope.TrainerNameList = data.TrainerName;
                    //}
                    //else {
                    //    logger.success("Invalid Company Name", "", "");
                    //}
                });
            }
            else {
                vm.CompanyDts.CompanyName = companyName;
                return uploadFormService.getTrainerList(vm.CompanyDts).then(function (data) {
                    //if (data.company == true) {
                    $scope.TrainerNameList = data.TrainerName;
                    //}
                    //else {
                    //    logger.success("Invalid Company Name", "", "");
                    //}
                });
            }
        }
        function LoadCompanyType(CompanyTrainingTypeId)
        {
            if (CompanyTrainingTypeId != "") {
                vm.CompaniesDetails = {};
                vm.UploadDetails.TrainerName = "";
                vm.UploadDetails.TopicsCovered = "";
                vm.UploadDetails.TrainerCompanyName = "";
                vm.UploadDetails.TRFDate = "";

                vm.UploadDetails.CompanyTypeID = "";
                vm.UploadDetails.CompanyName = "";
             
                vm.companyDetailsDisable = false;
                vm.trainerCompanyDisable = false;
                var promises = [getCompaniesType(CompanyTrainingTypeId), ];
                return $q.all(promises).then(function () {
                });
            }
        }
        function LoadCompanyName(CompanyType) {
            vm.UploadDetails.CompanyName = "";
            if (CompanyType != "") {
                if (CompanyType == 1) {
                    vm.UploadDetails.CompanyName = "3M Technologies (S) Pte Ltd";
                    vm.UploadDetails.TrainerCompanyName = "3M Technologies (S) Pte Ltd";
                    vm.CompanyDts.CompanyName = vm.UploadDetails.CompanyName;
                    getCompaniesDetails(vm.CompanyDts);
                    getTrainerList(vm.UploadDetails.TrainerCompanyName)
                    vm.companyDetailsDisable = true;
                    vm.trainerCompanyDisable = true;
                    vm.trainerDisable = false;
                }
                else if (CompanyType == 3) {
                    vm.UploadDetails.TrainerCompanyName = "3M Technologies (S) Pte Ltd";
                    getTrainerList(vm.UploadDetails.TrainerCompanyName)
                    vm.trainerCompanyDisable = true;
                    vm.trainerDisable = false;
                    vm.CompaniesDetails = "";
                    vm.UploadDetails.TopicsCovered = "";
                    vm.UploadDetails.TRFDate = "";
                    vm.companyNameDisable = true;
                    vm.companyDetailsDisable = false;
                    var promises = [getCompaniesList(CompanyType), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    vm.CompaniesDetails = "";
                    vm.UploadDetails.TrainerName = "";
                    vm.UploadDetails.TopicsCovered = "";
                    vm.UploadDetails.TrainerCompanyName = "";
                    vm.UploadDetails.TRFDate = "";
                    vm.companyNameDisable = true;
                    vm.companyDetailsDisable = false;
                    vm.trainerCompanyDisable = false;
                    var promises = [getCompaniesList(CompanyType), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        }
        function getCompaniesList(CompanyType) {
            
            return uploadFormService.getCompaniesList(CompanyType).then(function (data) {             
                $scope.companiesList = data.companyName;
            });
        }
        function LoadCompanyDetails(CompanyName) {
            CompanyName = angular.element('#company_name_Load').val();
            if (CompanyName != "") {
                vm.CompanyDts.CompanyName = CompanyName;
                var promises = [getCompaniesDetails(vm.CompanyDts)];
                return $q.all(promises).then(function () {
                });
            }
        }
        function getCompaniesDetails(CompanyDts) {
            vm.CompaniesDetails = {};
            //vm.UploadDetails.TrainerName = "";
            //vm.UploadDetails.TopicsCovered = "";
            //vm.UploadDetails.TrainerCompanyName = "";
            //vm.UploadDetails.TRFDate = "";
            return uploadFormService.getCompaniesDetails(CompanyDts).then(function (data) {
                if (data.length > 0) {
                    vm.CompaniesDetails.CompanyName = data[0].CompanyName;
                    vm.CompaniesDetails = new CompaniesDetails(data);
                    vm.UploadDetails.Email = data[0].Email;
                }
            });
        }
        function Dynamictxt() {
            
            vm.AttendanceDetails.push({
                    nameOfTrainee: "",
                    designation: "",
                    dept: "",
                    IDNo: "",
                    model: "",
                    outcome: ""
            });
            vm.AttCount = vm.AttendanceDetails.length;
        }
        function DeleteUpAttendance(item) {
            var index = vm.AttendanceDetails.indexOf(item)
            vm.AttendanceDetails.splice(index, 1);
            vm.AttCount = vm.AttendanceDetails.length;
           
        };
        //check Training Company
        function checkTrainingCompany() {
            vm.CompanyDts.CompanyName = vm.UploadDetails.TrainerCompanyName;
            return uploadFormService.checkTrainingCompany(vm.CompanyDts).then(function (data) {
                if (data.success == true) {
                    vm.trainerDisable = false;
                }
                else
                {
                    vm.trainerDisable = true;
                    vm.UploadDetails.TrainerName = "";
                    if (angular.element('#inputNameofTraining').val() != "") {
                        logger.warning(data.message, "", "");
                    }
                }
            });
        }
        function getActiveTrainersListdData(trainerId) {

            return uploadFormService.getActiveTrainersListdData(trainerId).then(function (data) {

                vm.UploadDetails = new UploadDetailsData(data.trainingRecord);
                vm.CompaniesDetails = new CompaniesDetailsData(data.companiesDetails);
                vm.trainerDisable = false;
             
                getCompaniesList(data.trainingRecord.CompanyTypeID);
                getTrainerCompanyList(1);
                getTrainerList(data.trainingRecord.TrainerCompanyName)

                if (data.trainingRecord.CompanyTypeID == 1)
                {
                    vm.companyDetailsDisable = true;
                    vm.trainerCompanyDisable = true;
                    vm.trainerDisable = false;
                }

                if (data.trainingRecord.CompanyTypeID == 3) {
                    vm.trainerCompanyDisable = true;
                    vm.trainerDisable = false;
                }
                
                if (data.trainingAttendance.length > 0) {
                    data.trainingAttendance.forEach(function (compData) {
                        vm.AttendanceDetails.push(new AttendanceDetails(compData));
                    });
                }

                var AttendanceDetailsArray = new Array();
                for (var iteration = 0; iteration < data.trainingAttendance.length; iteration++) {
                    AttendanceDetailsArray.push(new AttendanceDetails(data.trainingAttendance[iteration]));
                }
                vm.AttendanceDetails = AttendanceDetailsArray;

                vm.AttCount = vm.AttendanceDetails.length;
       
            });

        }
        //Save Data
        function save(isValid) {

            
            if (isValid) {
                return uploadFormService.checkTrainerName(vm.UploadDetails).then(function (data) {

                    if (vm.AttendanceDetails.length > 0) {
                        //if (data.success == true) {
                            vm.UploadDetails.TrainerCompanyName = angular.element('#inputNameofTraining').val();
                            vm.UploadDetails.CompanyName = angular.element('#company_name_Load').val();
                            vm.UploadDetails.TrainerName = angular.element('#TrainerName').val();
                            vm.UploadDetails.RefNo = $stateParams.trainerId;

                            //attendance details Validation
                            var userCount = 0;
                            userCount = vm.AttendanceDetails.length;
                            var lookup = {};
                            var items = vm.AttendanceDetails;
                            var result = [];
                            for (var item, i = 0; item = items[i++];) {
                                var name = angular.lowercase(item.IDNo);

                                if (name != "" && name != undefined) {
                                    if (!(name in lookup)) {
                                        lookup[name] = 1;
                                        result.push(name);

                                    }

                                }
                            }
                            if (userCount == result.length) {
                                //vm.CompaniesDetails.CompanyName = vm.UploadDetails.CompanyName;
                                uploadFormService.saveUploadFormDetails(vm.UploadDetails, vm.AttendanceDetails, vm.CompaniesDetails).then(function (data) {
                                    if (data.success == true) {
                                        $state.transitionTo('adminmenu.TrainingRecordSummary');
                                        logger.success(data.message, "", "");
                                    }
                                    else {
                                        vm.showRecordExists = true;
                                        //logger.error(data.message, "", "");
                                    }
                                });
                            }
                            else {
                                logger.warning("ID No. Already Exists", "", "");
                            }
                        //}
                        //else {
                        //    logger.warning(data.message, "", "");
                        //}
                    }
                    else { logger.warning("Import trainee records", "", ""); }
                });
            }
             
         
        }
        function onFileSelect($files) {
            $scope.uploadProgress = 0;
            $scope.selectedFile = $files;
            var file = $scope.selectedFile;
            var formData = new FormData();
            formData.append("file", file);
            var httpRequest = new XMLHttpRequest();
            httpRequest.open("POST", "/eFitToolAdmin/ImportExcel");
            httpRequest.send(formData);
        };
        function validateFiles(e) {
            if (e.target.files.length > 0) {
                if (e.target.files[0].size / 1024 / 1024 >= 15) {
                    logger.warning("File Size should be less then 15MB");
                    angular.element("#attachfilepath").val(null);
                }
            }
        };
        function fileType(type) {
            if (type != '' && type != undefined) {
                var img = 'Document-Blank.png'
                if (type == '.xls' || type == '.xlsx') {
                    img = 'Excel-icon1.png'
                }
                else if (type == '.pdf') {
                    img = 'pdf_icon_small.gif';
                }
                else if (type == '.doc' || type == '.docx') {
                    img = 'Microsoft-Office-Word-icon6.png';
                }
                return img;
            }
        }
        function uploadComplete(content, isComplete) {
            vm.AttendanceDetailsSlice = [];
            vm.AttendanceDetails = [];
            if (isComplete == true) {


                var response = JSON.parse(content)

              

                var traineeDetailsarray = new Array();
                for (var iteration = 0; iteration < response.status1.length; iteration++) {
                    vm.AttendanceDetails.push(new AttendanceDetails(response.status1[iteration]));
                }
          

                for (var i = 0; i < vm.AttendanceDetails.length ; i++) {
                    if (vm.AttendanceDetails[i].nameOfTrainee != "" || vm.AttendanceDetails[i].designation != "" || vm.AttendanceDetails[i].dept != "" || vm.AttendanceDetails[i].IDNo != "" || vm.AttendanceDetails[i].model != "" || vm.AttendanceDetails[i].outcome != "") {

                        vm.AttendanceDetailsSlice.push(new AttendanceDetailsSlice(vm.AttendanceDetails[i]));
                    }
                }
                if (vm.AttendanceDetailsSlice.length > 0)
                {
                    vm.AttendanceDetails = {};
                    vm.AttendanceDetails = vm.AttendanceDetailsSlice;
                }
                //if (vm.AttendanceDetails.length == 0) {
                //    Dynamictxt();
                //}
                if (response.msg == "success") {
                    vm.showUploadExcel = !vm.showUploadExcel;
                    vm.AttCount = vm.AttendanceDetails.length;
                    var importFileName = response.fileN;
                    vm.UploadDetails.FileName = importFileName;
                    //vm.Attach.push({
                    //    FileId: response.fileId,
                    //    FileName: response.fileName,
                    //    FileExtension: fileType(response.fileExtension)
                    //});
                    //angular.forEach(
                    //    angular.element("input[type='file']"),
                    //    function (inputElem) {
                    //        angular.element(inputElem).val(null);
                    //    });
                    //document.getElementById("UploadAttachForm").reset();
                }
                else if (response.msg == "error") {
                    logger.error("Error occurred  in File Upload ");
                }
                else if (response.msg == "NoFile") {
                    logger.warning("Select A File");
                }
                else if (response.msg == "Invalid") {
                    logger.warning("Select A Valid File");
                }
            }
        }
        function UploadDetails(data) {
            return {
                //RefNo: 1,
                TrainingType: data[0].TrainingType,
                Email: data[0].Email,
                TRFDate: new Date(data.TRFDate == null ? "" : data.TRFDate),
                TrainerName: data[0].TrainerName,
                TrainerCompanyName: data[0].TrainerCompanyName,
                TopicsCovered: data[0].TopicsCovered
            }
        }
        function CompaniesDetails(data) {
            return {
                Address: data[0].Address,
                PostalCode: data[0].PostalCode,
                ContactPerson: data[0].ContactPerson,
                ContactDesignation: data[0].ContactDesignation,
                ContactNumber: data[0].ContactNumber

            }

        }
        function CompaniesDetailsData(data) {
            return {
                Address: data.Address,
                PostalCode: data.PostalCode,
                ContactPerson: data.ContactPerson,
                ContactDesignation: data.ContactDesignation,
                ContactNumber: data.ContactNumber

            }

        }
        function UploadDetailsData(data) {
            return {
                //RefNo: 1,
                CompanyTypeID :data.CompanyTypeID,
                TrainingTypeID: data.TrainingTypeID,
                Email: data.Email,
                TRFDate: data.TRFDateS,
                TrainerName: data.TrainerName,
                TrainerCompanyName: data.TrainerCompanyName,
                TopicsCovered: data.TopicsCovered,
                CompanyName: data.CompanyName
            }
        }
        function cancelImportDialog()
        {
            vm.showUploadExcel = !vm.showUploadExcel;
        }

        function cancelAlert() {
            vm.showRecordExists = !vm.showRecordExists;
        }
        

        function AttendanceDetails(data) {

            return {
                //RefNo : 1,
                nameOfTrainee: data.nameOfTrainee,
                designation: data.designation,
                dept: data.dept,
                IDNo: data.IDNo,
                model: data.model,
                outcome: data.outcome
            }
        }

        function AttendanceDetailsSlice(data) {

            return {
                //RefNo : 1,
                nameOfTrainee: data.nameOfTrainee,
                designation: data.designation,
                dept: data.dept,
                IDNo: data.IDNo,
                model: data.model,
                outcome: data.outcome
            }
        }
        vm.files = [];
        $scope.fileInputChanged = function (element) {
            angular.forEach(element.files, function (item) {
                vm.files.push(item);
            });            
        }
        vm.uploadDocuments = function () {
            vm.showUploadExcel = !vm.showUploadExcel;
           
        }
    }
})();
