﻿(function () {
    'use strict';

    angular
        .module('eFitTool.quickLinks')
        .controller('AddQuickLinksCtrl', AddQuickLinksCtrl)


    AddQuickLinksCtrl.$inject = ['$state', '$q', 'quickLinksService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function AddQuickLinksCtrl($state, $q, quickLinksService, logger, $timeout, $filter, $stateParams, $scope, config) {
        var vm = this;
        vm.ParentModule = {};
        vm.title = 'Quick Link Edit Ctrl';
        vm.LinksDetails = {};
        vm.LinkSaveDetails={};
        $stateParams.SNo = $stateParams.SNo == "" ? 0 : $stateParams.SNo;
        vm.isEdit = false;
        vm.quickLink = [

      {
          'Id': 1,
          'name': 'Self Window',

      },
      {
          'Id': 2,
          'name': 'New Window',
      }
        ];


        // Method Declaration
        vm.Save = save;

        activate();

        function activate() {
            if ($stateParams.SNo > 0) {
                var promises = [getQuickLinkEdit($stateParams.SNo)];
                return $q.all(promises).then(function () {               
                });
            }
            else {
                vm.isEdit = true;
            }
        }

        function getQuickLinkEdit(SNo) {
            return quickLinksService.getLinkData(SNo).then(function (data) {
                vm.LinksDetails = new LinksDetails(data);
            });
        }

        function save(isValid) {
            if (isValid) {
                    quickLinksService.saveLinkDetails(vm.LinksDetails).then(function (data) {
                        if (data.success == true) {
                            vm.isEdit = false;
                            vm.LinkSaveDetails = vm.LinksDetails;
                            logger.success(data.message, "", "");
                            $state.transitionTo('adminmenu.QuickLinks');
                           
                        }
                        else {
                            logger.error(data.message);
                        }
                    });
                }
        }

        function LinksDetails(data) {
            return {
                SNo: data.SNo,
                Name: data.Name,
                URL: data.URL,
                Target: data.Target,

            }
        }

        }
    }
)();