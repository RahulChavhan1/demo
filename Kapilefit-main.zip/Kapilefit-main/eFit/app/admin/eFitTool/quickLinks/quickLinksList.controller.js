﻿(function () {
    'use strict';

    angular      
        .module('eFitTool.quickLinks')
        .controller('QuickLinksListCtrl', QuickLinksListCtrl)

    QuickLinksListCtrl.$inject = ['$state', '$q', 'quickLinksService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function QuickLinksListCtrl($state, $q, quickLinksService, logger, $timeout, $filter, $stateParams, $scope, config) {
      
        var vm = this;
        vm.QuickLinksList = {};
           activate();     

        function activate() {
            var promises = [getQuickLinksDetail()];
            return $q.all(promises).then(function () {

            });

            function getQuickLinksDetail() {             
                return quickLinksService.getQuickLinksDetail(1).then(function (data) {
                    vm.QuickLinksList = data;
                });

           
            }

        }

    }
})();