﻿(function () {
    'use strict';

    angular.module('eFitTool.quickLinks', [

    ]);
})();