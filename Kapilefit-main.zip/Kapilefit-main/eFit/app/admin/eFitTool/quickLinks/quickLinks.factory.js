﻿(function () {
    'use strict';
    angular
        .module('eFitTool.quickLinks', [])
        .factory('quickLinksService', quickLinksService)

    quickLinksService.$inject = ['$http', '$q', '$timeout', 'config'];

    function quickLinksService($http, $q, $timeout, config) {
        var service = {
            getQuickLink: getQuickLink,
            saveLinkDetails: saveLinkDetails,
            getQuickLinksDetail:getQuickLinksDetail,
            getLinkData: getLinkData,
            Logout: Logout,

        };
        return service;
       
        function getQuickLink(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/GetQuickLinks',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        //created by :marimuthu.M


        function getQuickLinksDetail(flag) {

        var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/HomeAPI/' + flag, data: {
                    id: flag
                }
        }).success(deferred.resolve).error(deferred.reject);
        return deferred.promise;
         }
        function saveLinkDetails(LinksDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/eFitToolAdminApi/SaveLinkDetails',
                data: JSON.stringify(LinksDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getLinkData(SNo) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetLinkData/' + SNo
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

    }


   




})();