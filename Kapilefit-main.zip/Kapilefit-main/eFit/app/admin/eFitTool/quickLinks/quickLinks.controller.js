﻿(function () {
    'use strict';

    angular
        .module('eFitTool.quickLinks')
        .controller('QuickLinksCtrl', QuickLinksCtrl)


    QuickLinksCtrl.$inject = ['$state', '$q', 'quickLinksService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function QuickLinksCtrl($state, $q, quickLinksService, logger, $timeout, $filter, $stateParams, $scope, config) {
        var vm = this;
        vm.ParentModule = {};
        vm.title = 'Quick Links Ctrl';
        vm.QuickLinkDetails = {};
        vm.tempDetails = {};
        vm.InputDetails = {};
        vm.InputDetails.searchText = "";
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "Name";
        vm.InputDetails.sortOrder = true;
        vm.tempIndex = 1;
        vm.showPage = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;


        // Method Declaration
        vm.SearchLinks = SearchLinks;
        vm.Linkstable = Linkstable;
        vm.sort = sort;
        vm.ExportToExcel = ExportToExcel;
        vm.setPage = setPage;
        vm.editLinks = editLinks;
      //  activate();

        activate();


        function activate() {
            //$state.transitionTo('homemenu.General');
            $stateParams.companyTypeId = 3;
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            var promises = [getLinkList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }

        function getLinkList(InputDetails) {
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return quickLinksService.getQuickLink(InputDetails).then(function (data) {

                vm.QuickLinkDetails = data;
                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }
            });
        }

        //Searching
        function SearchLinks(search) {
            vm.Linkstable(search)
        }
        function Linkstable(search) {
            vm.InputDetails.searchText = search;
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            setPage(0);
        }

        // Export To Excel
        function ExportToExcel() {

            window.location.href = config.baseURL + "eFitToolAdmin/ExportLinksSummary?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems;
        }


        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
               // vm.descending = !vm.descending;
                vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            var promises = [getLinkList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        //Paging       
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }

            var ps = [];
            var start;

            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }

            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {

            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }

            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;

            if (cPage != 0) {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getLinkList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;
            if (cPage != vm.pageCount()) {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getLinkList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };
        function setPage(n) {
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;
            vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
            var promises = [getLinkList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        function editLinks(SNo) {
            $state.transitionTo('adminmenu.QuickLinksAdd', { SNo: SNo }, { notify: true });
        };

        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.QuickLinksGrid = {
            data: 'vm.QuickLinkDetails',
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            multiSelect: false,
            displaySelectionCheckbox: false,
            enableColumnResize: true,
            columnDefs: [
                {
                    cellTemplate: '<div class="link3"><div class="ngCellText"><a ng-click="vm.editLinks(row.entity.SNo)">{{row.getProperty(\'Name\')}}</a></div></div>',
                    field: 'Name', displayName: 'Name', width: '25%'
                },
            { field: 'URL', displayName: 'URL', width: '35%' },
            { field: 'Target', displayName: 'Target', width: '25%' }]
        };

        $scope.$watch('QuickLinksGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            sort($scope.sortInfo.fields[0]);
        }, true);

    }
})();