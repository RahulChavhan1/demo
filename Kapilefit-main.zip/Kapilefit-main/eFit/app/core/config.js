(function () {

    'use strict';

    var core = angular.module('app.core');

    core.config(toastrConfig);

    toastrConfig.$inject = ['toastr']
    function toastrConfig(toastr) {
        toastr.options.timeOut = 4000;
        toastr.options.positionClass = 'toast-center';
    }

    core.config(loadingBarConfig);

    loadingBarConfig.$inject = ['cfpLoadingBarProvider']
    function loadingBarConfig(cfpLoadingBarProvider) {
        cfpLoadingBarProvider.includeSpinner = true;
        cfpLoadingBarProvider.includeBar = true;
    }

    var config = {
        appErrorPrefix: '[NG-Modular Error] ', //Configure the exceptionHandler decorator
        appTitle: 'eFit',
        version: '1.0.0',
        baseURL: '/',
        roleTicketId: ''
    };

    core.value('config', config);

    core.run(rootscope);

    rootscope.$inject = ['$rootScope', '$state', '$stateParams'];

    function rootscope($rootScope, $state, $stateParams) {

        // It's very handy to add references to $state and $stateParams to the $rootScope
        // so that you can access them from any scope within your applications.For example,
        // to active whenever 'contacts.list' or one of its decendents is active.
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
    }

    core.config(routconfig);


    routconfig.$inject = ['$stateProvider', '$urlRouterProvider'];

    function routconfig($stateProvider, $urlRouterProvider) {
        $urlRouterProvider
       // If the url is ever invalid, e.g. '/asdf', then redirect to '/' aka the home state
       .otherwise(config.baseURL + 'homemenu/HomeOption/General');

        // Use $stateProvider to configure your states.
        $stateProvider

          .state("/", {
              url: "/HomeOption/General",
              templateUrl: config.baseURL + 'HomeOption/General'
              //controller: 'login as vm'
          })


        //HomeMenu
        .state("homemenu", {
            url: "/homemenu",
            templateUrl: config.baseURL + 'homemenu/index',
            controller: 'homemenuShellCtrl as vm'
        })

        //eFitMenu 
        .state("efitmenu", {
            url: "/eFit",
            templateUrl: config.baseURL + 'Efit/index',
            controller: 'EfitCtrl as vm'
        })

        //productsmenu
        .state("productsmenu", {
            url: "/products",
            templateUrl: config.baseURL + 'Products/index',
            controller: 'ProductsmenuShellCtrl as vm'
        })

        //adminmenu
        .state("adminmenu", {
            url: "/adminmenu",
            templateUrl: config.baseURL + 'Admin/index',
            //controller: 'ProductsmenuShellCtrl as vm'
        })


        //EFitModule - MenuOption

        //Efit Landing
        .state("efitmenu.EfitLanding", {
            url: "/Efit/EfitLanding",
            templateUrl: config.baseURL + 'Efit/EfitLanding',
            //controller: 'homeShellCtrl as vm'
        })

        //Customer Listing
        //Distributors
         .state("efitmenu.Distributors", {
          url: "/CustomerListing/Distributors",
          templateUrl: config.baseURL + 'CustomerListing/Distributors',
          controller: 'DistributorsListCtrl as vm'
          })    
                    //DistributorsCompId
                     .state("efitmenu.DistributorsCompId", {
                         url: "/CustomerListing/Distributors/:companyId",
                         templateUrl: config.baseURL + 'CustomerListing/Distributors',
                         controller: 'DistributorsListCtrl as vm'
                     })

                    //DistributorsCompriId
                    .state("efitmenu.DistributorsCompPriId", {
                        url: "/CustomerListing/Distributors/:companyId/:companyPriId",
                                     templateUrl: config.baseURL + 'CustomerListing/Distributors',
                                     controller: 'DistributorsListCtrl as vm'
                    })

                     //DistributorsTrainerId
                    .state("efitmenu.DistributorsTrainerId", {
                        url: "/CustomerListing/Distributors/:companyId/:companyPriId/:trainerId",
                        templateUrl: config.baseURL + 'CustomerListing/Distributors',
                        controller: 'DistributorsListCtrl as vm'
                    })



            //RedDistributors
            .state("efitmenu.ReDistributors", {
                url: "/CustomerListing/Distributors",
                templateUrl: config.baseURL + 'CustomerListing/Distributors',
                controller: 'DistributorsListCtrl as vm'
            })
         
             //RedPrivate
            .state("efitmenu.RePrivateCompanies", {
                url: "/CustomerListing/Distributors/:companyId",
                templateUrl: config.baseURL + 'CustomerListing/Distributors',
                controller: 'DistributorsListCtrl as vm'
            })

          
            //RedTrainers
            .state("efitmenu.ReTrainers", {
                url: "/CustomerListing/Distributors/:companyId/:companyPriId",
                templateUrl: config.baseURL + 'CustomerListing/Distributors',
                controller: 'DistributorsListCtrl as vm'
            })    

         //PrivateCompanies
         .state("efitmenu.PrivateCompanies", {
             url: "/CustomerListing/PrivateCompanies",
             templateUrl: config.baseURL + 'CustomerListing/PrivateCompanies',
             controller: 'PrivateCompaniesListCtrl as vm'
         })
        
          //PrivateCompaniesCompanyPriId
         .state("efitmenu.PrivateCompaniesCompanyPriId", {
             url: "/CustomerListing/PrivateCompanies/:companyPriId",
             templateUrl: config.baseURL + 'CustomerListing/PrivateCompanies',
             controller: 'PrivateCompaniesListCtrl as vm'
         })

           //PrivateCompaniesTrainerId
         .state("efitmenu.PrivateCompaniesTrainerId", {
             url: "/CustomerListing/PrivateCompanies/:companyPriId/:trainerId",
             templateUrl: config.baseURL + 'CustomerListing/PrivateCompanies',
             controller: 'PrivateCompaniesListCtrl as vm'
         })


             //RePrivateCompanies
         .state("efitmenu.RedPrivateCompanies", {
             url: "/CustomerListing/PrivateCompanies",
             templateUrl: config.baseURL + 'CustomerListing/PrivateCompanies',
             controller: 'PrivateCompaniesListCtrl as vm'
         })
     
         //ReTrainers
         .state("efitmenu.RedTrainers", {
             url: "/CustomerListing/PrivateCompanies/:companyPriId",
             templateUrl: config.baseURL + 'CustomerListing/PrivateCompanies',
             controller: 'PrivateCompaniesListCtrl as vm'
         })
                
            
        //GovtCompanies
         .state("efitmenu.GovtCompanies", {
             url: "/CustomerListing/GovtCompanies",
             templateUrl: config.baseURL + 'CustomerListing/GovtCompanies',
             controller: 'GovtCompaniesListCtrl as vm'
         })

        //GovtCompaniesCompanyPriId
         .state("efitmenu.GovtCompaniesCompanyPriId", {
             url: "/CustomerListing/GovtCompanies/:companyPriId",
             templateUrl: config.baseURL + 'CustomerListing/GovtCompanies',
             controller: 'GovtCompaniesListCtrl as vm'
         })
         
        //GovtCompaniestrainerId
         .state("efitmenu.GovtCompaniesTrainerId", {
             url: "/CustomerListing/GovtCompanies/:companyPriId/:trainerId",
             templateUrl: config.baseURL + 'CustomerListing/GovtCompanies',
             controller: 'GovtCompaniesListCtrl as vm'
         })

            //RedGovtCompanies
         .state("efitmenu.RedGovtCompanies", {
             url: "/CustomerListing/GovtCompanies",
             templateUrl: config.baseURL + 'CustomerListing/GovtCompanies',
             controller: 'GovtCompaniesListCtrl as vm'
         })
               

         //ReTrainers
         .state("efitmenu.RedGovtCompaniesTrainers", {
             url: "/CustomerListing/GovtCompanies/:companyPriId",
             templateUrl: config.baseURL + 'CustomerListing/GovtCompanies',
             controller: 'GovtCompaniesListCtrl as vm'
         })
        //CertifiedTrainers
        //ActiveTrainers
        .state("efitmenu.ActiveTrainers", {
            url: "/CertifiedTrainers/ActiveTrainers",
            templateUrl: config.baseURL + 'CertifiedTrainers/Active',
            controller: 'ActiveTrainersListCtrl as vm'
        })

        //ExpiredTrainers
        .state("efitmenu.ExpiredTrainers", {
            url: "/CertifiedTrainers/ExpiredTrainers",
            templateUrl: config.baseURL + 'CertifiedTrainers/Expired',
            controller: 'ExpiredTrainersListCtrl as vm'
        })

        //DueforRenewalTrainers
        .state("efitmenu.DueforRenewalTrainers", {
            url: "/CertifiedTrainers/DueforRenewalTrainers",
            templateUrl: config.baseURL + 'CertifiedTrainers/DueforRenewal',
            controller: 'DueOfRenewalTrainersListCtrl as vm'
        })


        //CertifiedTrainees
        //ActiveTrainees
        .state("efitmenu.ActiveTrainees", {
            url: "/CertifiedTrainees/ActiveTrainees",
            templateUrl: config.baseURL + 'CertifiedTrainees/Active',
            controller: 'ActiveTraineesListCtrl as vm'
        })

        //ExpiredTrainees
        .state("efitmenu.ExpiredTrainees", {
            url: "/CertifiedTrainees/ExpiredTrainees",
            templateUrl: config.baseURL + 'CertifiedTrainees/Expired',
            controller: 'ExpiredTraineesListCtrl as vm'
        })

        //DueforRenewalTrainees
        .state("efitmenu.DueforRenewalTrainees", {
            url: "/CertifiedTrainees/DueforRenewalTrainees",
            templateUrl: config.baseURL + 'CertifiedTrainees/DueforRenewal',
            controller: 'DueOfRenewalListCtrl as vm'
        })


        //StatusInquiry
        //TraineeListing
        .state("efitmenu.TraineeDetails", {
            url: "/StatusInquiry/TraineeListing",
            templateUrl: config.baseURL + 'StatusInquiry/TraineeListing',
            controller: 'TraineeListListCtrl as vm'
        })

         //TraineeDetails
        .state("efitmenu.TrainerListing", {
            url: "/StatusInquiry/TrainerListing",
            templateUrl: config.baseURL + 'StatusInquiry/TrainerListing',
            controller: 'TrainerListListCtrl as vm'
        })


        //DocManager
        //PrintCertificate
        .state("efitmenu.PrintCertificate", {
            url: "/DocManager/PrintCertificate",
            templateUrl: config.baseURL + 'DocManager/PrintCertificate',
            controller: 'PrintCertificateListCtrl as vm'
        })

        //FitTestRecord
        .state("efitmenu.FitTestRecord", {
            url: "/DocManager/FitTestRecord/:companyId/:trainerId",
            templateUrl: config.baseURL + 'DocManager/FitTestRecord',
            controller: 'FitTestRecordListCtrl as vm'
        })

              //ReFitTestRecord
        .state("efitmenu.ReFitTestRecord", {
            url: "/DocManager/FitTestRecord/:comName/:traDate/:searchTxt",
            templateUrl: config.baseURL + 'DocManager/FitTestRecord',
            controller: 'FitTestRecordListCtrl as vm'
        })

        //TrainTrainer
        .state("efitmenu.TrainTrainer", {
            url: "/DocManager/TrainTrainer/:companyId/:trainerId",
            templateUrl: config.baseURL + 'DocManager/TrainTrainer',
            controller: 'TrainTrainerListCtrl as vm'
        })

                  //ReTrainTheTrainerRecord
        .state("efitmenu.ReTrainTheTrainerRecord", {
            url: "/DocManager/TrainTrainer/:comName/:traDate/:searchTxt",
            templateUrl: config.baseURL + 'DocManager/TrainTrainer',
            controller: 'TrainTrainerListCtrl as vm'
        })

        //DownloadeFitForm
        .state("efitmenu.DownloadeFitForm", {
            url: "/DocManager/DownloadeFitForm",
            templateUrl: config.baseURL + 'DocManager/DownloadeFitForm',
            //controller: 'TrainTrainerListCtrl as vm'
        })
        //HomeMenu - Options
        //HomeOption
        //General
        .state("homemenu.General", {
            url: "/HomeOption/General",
            templateUrl: config.baseURL + 'HomeOption/General',
            controller: 'homeGeneralShellCtrl as vm'
        })

        //RespiratoryProtection
        .state("homemenu.RespiratoryProtection", {
            url: "/HomeOption/RespiratoryProtection",
            templateUrl: config.baseURL + 'HomeOption/RespiratoryProtection',
            //controller: 'homeShellCtrl as vm'
        })

          //RespiratoryProtection
        .state("homemenu.RespiratorySelectionGuide", {
            url: "/HomeOption/RespiratorySelectionGuide",
            templateUrl: config.baseURL + 'HomeOption/TechUpdates',
            //controller: 'homeShellCtrl as vm'
        })

        //TechUpdates
        .state("homemenu.TechUpdates", {
            url: "/HomeOption/TechUpdates",
            templateUrl: config.baseURL + 'HomeOption/TechUpdates',
            //controller: 'homeShellCtrl as vm'
        })

        //NewProductsIntro
        .state("homemenu.NewProductsIntro", {
            url: "/HomeOption/NewProductsIntro",
            templateUrl: config.baseURL + 'HomeOption/NewProductsIntro',
            //controller: 'homeShellCtrl as vm'
        })

         //FitTestingDevices
        //FitTestKitsAcce
        .state("homemenu.FitTestKitsAcce", {
            url: "/FitTestingDevices/FitTestKitsAcce",
            templateUrl: config.baseURL + 'FitTestingDevices/FitTestKitsAcce',
            //controller: 'homeShellCtrl as vm'
        })



         //MSDS
        //FT11
        .state("homemenu.FT11", {
            url: "/MSDS/FT11",
            templateUrl: config.baseURL + 'MSDS/FT11',
            //controller: 'homeShellCtrl as vm'
        })

         //FT11
        .state("homemenu.FT12", {
            url: "/MSDS/FT12",
            templateUrl: config.baseURL + 'MSDS/FT12',
            //controller: 'homeShellCtrl as vm'
        })

         //FT11
        .state("homemenu.FT31", {
            url: "/MSDS/FT31",
            templateUrl: config.baseURL + 'MSDS/FT31',
            //controller: 'homeShellCtrl as vm'
        })

         //FT11
        .state("homemenu.FT32", {
            url: "/MSDS/FT32",
            templateUrl: config.baseURL + 'MSDS/FT32',
            //controller: 'homeShellCtrl as vm'
        })



        //RegulationsStandards
         .state("homemenu.RegulationsStandards", {
             url: "/RegulationsStandards",
             templateUrl: config.baseURL + 'RegulationsStandards/LocalRegulations',
             //controller: 'homeShellCtrl as vm'
         })

          //OtherStandards
         .state("homemenu.OtherStandards", {
             url: "/RegulationsStandards/OtherStandards",
             templateUrl: config.baseURL + 'RegulationsStandards/OtherStandards',
             //controller: 'homeShellCtrl as vm'
         })


        //OtherResources
        //RelatedLinks
         .state("homemenu.RelatedLinks", {
             url: "/OtherResources/RelatedLinks",
             templateUrl: config.baseURL + 'OtherResources/RelatedLinks',
             //controller: 'homeShellCtrl as vm'
         })

        //ProductsMenu - MenuOption

        //Product Landing

        .state("productsmenu.ProductsLanding", {
            url: "/Products/ProductsLanding",
            templateUrl: config.baseURL + 'Products/ProductsLanding',
            //controller: 'homeShellCtrl as vm'
        })

        //6000 Series
        //HalfFacepiece
         .state("productsmenu.HalfFacepiece6000", {
             url: "/ElastomericFacepiece/HalfFacepiece6000",
             templateUrl: config.baseURL + 'ElastomericFacepiece/HalfFacepiece6000',
             //controller: 'DistributorsListCtrl as vm'
         })

          //FullFacepiece6000
         .state("productsmenu.FullFacepiece6000", {
             url: "/ElastomericFacepiece/FullFacepiece6000",
             templateUrl: config.baseURL + 'ElastomericFacepiece/FullFacepiece6000',
             //controller: 'DistributorsListCtrl as vm'
         })


        //7000 Series
        //HalfFacepiece
         .state("productsmenu.HalfFacepiece7000", {
             url: "/ElastomericFacepiece/HalfFacepiece7000",
             templateUrl: config.baseURL + 'ElastomericFacepiece/HalfFacepiece7000',
             //controller: 'DistributorsListCtrl as vm'
         })

          //FullFacepiece7000
         .state("productsmenu.FullFacepiece7000", {
             url: "/ElastomericFacepiece/FullFacepiece7000",
             templateUrl: config.baseURL + 'ElastomericFacepiece/FullFacepiece7000',
             //controller: 'DistributorsListCtrl as vm'
         })


        //Fitting Instructions
         //EnglishWearltright
         .state("productsmenu.EnglishWearltright", {
             url: "/ElastomericFacepiece/EnglishWearltright",
             templateUrl: config.baseURL + 'ElastomericFacepiece/EnglishWearltright',
             //controller: 'DistributorsListCtrl as vm'
         })

          //MandrinWearltright
         .state("productsmenu.MandrinWearltright", {
             url: "/ElastomericFacepiece/MandrinWearltright",
             templateUrl: config.baseURL + 'ElastomericFacepiece/MandrinWearltright',
             //controller: 'DistributorsListCtrl as vm'
         })

          //ChemicalCartridges
         .state("productsmenu.ChemicalCartridges", {
             url: "/ElastomericFacepiece/ChemicalCartridges",
             templateUrl: config.baseURL + 'ElastomericFacepiece/ChemicalCartridges',
             //controller: 'DistributorsListCtrl as vm'
         })

          //ParticulateFilter
         .state("productsmenu.ParticulateFilter", {
             url: "/ElastomericFacepiece/ParticulateFilter",
             templateUrl: config.baseURL + 'ElastomericFacepiece/ParticulateFilter',
             //controller: 'DistributorsListCtrl as vm'
         })

          //FiltersAdapters
         .state("productsmenu.FiltersAdapters", {
             url: "/ElastomericFacepiece/FiltersAdapters",
             templateUrl: config.baseURL + 'ElastomericFacepiece/FiltersAdapters',
             //controller: 'DistributorsListCtrl as vm'
         })


        //Maint Free Respirator
        //Series8000
        .state("productsmenu.Series8000", {
            url: "/MaintFreeRespirator/Series8000",
            templateUrl: config.baseURL + 'MaintFreeRespirator/Series8000',
            //controller: 'DistributorsListCtrl as vm'
        })

        //FittingInstructions
        .state("productsmenu.FittingInstructions", {
            url: "/MaintFreeRespirator/FittingInstructions",
            templateUrl: config.baseURL + 'MaintFreeRespirator/FittingInstructions',
            //controller: 'DistributorsListCtrl as vm'
        })

        //poweredSupplies
        //PoweredSupplies
        .state("productsmenu.PoweredSupplies", {
            url: "/MaintFreeRespirator/PoweredSupplies",
            templateUrl: config.baseURL + 'MaintFreeRespirator/PoweredSupplies',
            //controller: 'DistributorsListCtrl as vm'
        })


        //Admin - MenuOption
          .state("adminmenu.adminLanding", {
              url: "/adminmenu",
              templateUrl: config.baseURL + 'eFitToolAdmin/adminLanding',
              //controller: 'UploadFormCtrl as vm'
          })

        //eFit Tool
        //UploadForm
        .state("adminmenu.UploadForm", {
            url: "/UploadForm/:trainerId/:trainingTypeId",
            templateUrl: config.baseURL + 'eFitToolAdmin/UploadForm',
            controller: 'UploadFormCtrl as vm'
        })

          //eFit Tool
        //Training Record Summary
        .state("adminmenu.TrainingRecordSummary", {
            url: "/TrainingRecordSummary",
            templateUrl: config.baseURL + 'eFitToolAdmin/TrainersRecordSummary',
            controller: 'TrainerActiveSummaryListCtl as vm'
        })


        //eFit Tool
        //UploadStatusCheck
        .state("adminmenu.UploadStatusCheck", {
            url: "/TrainerSummary",
            templateUrl: config.baseURL + 'eFitToolAdmin/UploadStatusCheck',
            controller: 'TrainerRecordListCtl as vm'
        })
        //eFit Tool
        // UploadTrainerPhoto
        .state("adminmenu.UploadTrainerPhoto", {
            url: "/UploadTrainerPhoto",
            templateUrl: config.baseURL + 'eFitToolAdmin/UploadTrainerPhoto',
            //controller: 'DistributorsListCtrl as vm'
        })
        //eFit Tool
        // DeleteTrainerPhoto
        .state("adminmenu.DeleteTrainerPhoto", {
            url: "/DeleteTrainerPhoto",
            templateUrl: config.baseURL + 'eFitToolAdmin/DeleteTrainerPhoto',
            //controller: 'DistributorsListCtrl as vm'
        })

         //QuickLinks
        .state("adminmenu.QuickLinks", {
            url: "/QuickLinks",
            templateUrl: config.baseURL + 'eFitToolAdmin/QuickLinks',
            controller: 'QuickLinksCtrl as vm'
        })

         //QuickLinksAdd
        .state("adminmenu.QuickLinksAdd", {
            url: "/QuickLinksAdd/:SNo",
            templateUrl: config.baseURL + 'eFitToolAdmin/AddQuickLinks',
            controller: 'AddQuickLinksCtrl as vm'
        })

         //QuickLinksList
        
        .state("homemenu.QuickLinksList", {
            url: "/QuickLinksList",
            templateUrl: config.baseURL + 'eFitToolAdmin/QuickLinksList',
            controller: 'QuickLinksListCtrl as vm'
        })


        //UserMaintenance - MenuOption

         //eFit Tool
        // NewUser
        .state("adminmenu.NewUser", {
            url: "/NewUser/:userID",
            templateUrl: config.baseURL + 'UserMaintenanceAdmin/NewUser',
            controller: 'UserEditCtrl as vm'
        })

        // UserList
        .state("adminmenu.UserList", {
            url: "/UserList",
            templateUrl: config.baseURL + 'UserMaintenanceAdmin/NewUserList',
            controller: 'UserNewCtrl as vm'
        })

         //eFit Tool
        // PasswordMaintenance
        .state("adminmenu.PasswordMaintenance", {
            url: "/PasswordMaintenance",
            templateUrl: config.baseURL + 'UserMaintenanceAdmin/PasswordMaintenance',
            controller: 'PasswordMaintenanceCtrl as vm'
        })

        //General Pages
        // ContactUs
        .state("homemenu.ContactUs", {
            url: "/ContactUs",
            templateUrl: config.baseURL + 'General/ContactUs',
            //controller: 'PasswordMaintenanceCtrl as vm'
        })

         // FAQ
        .state("homemenu.FAQ", {
            url: "/FAQ",
            templateUrl: config.baseURL + 'General/FAQ',
            //controller: 'PasswordMaintenanceCtrl as vm'
        })
    }

})();
