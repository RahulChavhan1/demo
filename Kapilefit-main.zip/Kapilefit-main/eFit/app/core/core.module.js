(function () {
    'use strict';

    angular.module('app.core', [
        /*
         * Angular modules
         */
        'ngAnimate', 'ui.router', 'ngSanitize',
        /*
         * Our reusable cross app code modules
         * 'blocks.exception',
         */
        'blocks.logger', 'blocks.common.directive', 
        /*
         * 3rd Party modules
         */
        'ui.bootstrap', 'ngplus', 'psUpload', 'angular-loading-bar', 'ngGrid'
    ]);
})();
