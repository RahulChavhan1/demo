﻿(function () {
    'use strict';

    angular
        .module('authInterceptor',[])
        .factory('authInterceptorService', authInterceptorService);

    authInterceptorService.$inject = ['$q', '$injector', '$location', 'localStorageService','config'];

    function authInterceptorService($q, $injector, $location, localStorageService, config) {
        var service = {
            request: request,
            responseError: responseError           
        };

        return service;

        function request(config) {
            config.headers = config.headers || {};
            var authData = localStorageService.get('authorizationData');
            if (authData) {
                config.headers.Authorization = 'Bearer ' + authData.token;
            }
            return config;
        }

        function responseError(rejection) {
            if (rejection.status === 401) {           
                window.location = '/Account';
            }           
        }



    }
})();