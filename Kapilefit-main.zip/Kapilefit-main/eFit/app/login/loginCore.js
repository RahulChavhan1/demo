﻿(function () {
    'use strict';

    var core = angular.module('loginApp.core');

    core.config(toastrConfig);

    toastrConfig.$inject = ['toastr']
    function toastrConfig(toastr) {
        toastr.options.timeOut = 4000;
        toastr.options.positionClass = 'toast-top-right';
    }

    core.config(loadingBarConfig);

    loadingBarConfig.$inject = ['cfpLoadingBarProvider']
    function loadingBarConfig(cfpLoadingBarProvider) {
        cfpLoadingBarProvider.includeSpinner = true;
        cfpLoadingBarProvider.includeBar = true;
    }

    var config = {
        appErrorPrefix: '[NG-Modular Error] ', //Configure the exceptionHandler decorator
        appTitle: 'SCRM',
        version: '1.0.0',
        baseURL: '/'
    };

    core.value('config', config);

})();
