﻿(function () {
    'use strict';

    angular
        .module('loginApp2')
        .controller('loginCtrl', loginCtrl);

    loginCtrl.$inject = ['$location', 'config'];

    function loginCtrl($location, config) {
        // Variable Declaration
        var vm = this;
        vm.title = 'login';

        // Method Declaration
        vm.Login = login;
        activate();

        // Method Definition
        function activate() {
        }
        function login() {
            window.location = config.baseURL + 'home/index';
        }
    }
})();
