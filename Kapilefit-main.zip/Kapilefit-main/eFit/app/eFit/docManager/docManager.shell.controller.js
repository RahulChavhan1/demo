﻿(function () {
    'use strict';

    angular
        .module('docManager.core')
        .controller('DocManagerListingCtrl', DocManagerListingCtrl);

    DocManagerListingCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function DocManagerListingCtrl($state, $stateParams, $q, $rootScope) {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'DocManager Listing Shell';
        $rootScope.showMenu = true;
        vm.DocManagerListingDetails = {};
        activate();


        function activate() {

            //$state.transitionTo('client.details', { clientID: '2' }, { notify: true });

        }

    }

})();
