﻿(function () {
    'use strict';

    angular
        .module('docManager.fitTestRecord')
        .controller('FitTestRecordListCtrl', FitTestRecordListCtrl)
    FitTestRecordListCtrl.$inject = ['$state', '$q', 'fittestrecordService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function FitTestRecordListCtrl($state, $q, fittestrecordService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'FitTestRecordListCtrl';
        vm.TrainerFittestRecordDetails = {};
        $scope.CompanyDropdownList = [];
        vm.tempDetails = {};
        vm.TraineesDetails = {};
        vm.TrainingTypeID = {};
        vm.InputDetails = {};
        vm.CompanyDts = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.traineeType = 1;
        vm.showPage = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        vm.InputDetails.companyTypeID = 0;
        vm.trainingDate = "";
        vm.searchText = "";
        vm.TTrainersList = false;
        vm.TTraineesList = false;
        vm.TTrainersListGrid = false;
        vm.title = "";
        vm.isSearch = false;
        vm.TrainingDateRef = "";
        //vm.RecordsPerPageList = [5, 10];
        //vm.pageNo = 0;




        //Method Declaration
        vm.SearchTrainerFittestRecord = SearchTrainerFittestRecord;
        vm.TrainerFittestRecordtable = TrainerFittestRecordtable;
        vm.sort = sort;
        vm.ExportToExcel = ExportToExcel;
        vm.TraineesDetails = TraineesDetails;
        vm.setPage = setPage;
        vm.LoadTrainerFittestRecord = LoadTrainerFittestRecord;

        $stateParams.companyId = $stateParams.companyId == "" ? 0 : $stateParams.companyId;
        $stateParams.trainerId = $stateParams.trainerId == "" ? null : $stateParams.trainerId;

        $stateParams.comName = $stateParams.comName == "" ? null : $stateParams.comName;
        $stateParams.traDate = $stateParams.traDate == "" ? null : $stateParams.traDate;
        $stateParams.searchTxt = $stateParams.searchTxt == "" ? null : $stateParams.searchTxt;

        activate();

        //Method Definition
        function activate() {
            $stateParams.companyTypeId = 3;
            vm.CompanyDts.disID = 1;
            vm.CompanyDts.tID = 1;
            $stateParams.companyName = angular.element('#company_name').val();
            $stateParams.companyTypeID = angular.element('#companyTypeId').val();
            $stateParams.disCompanyName = angular.element('#dis_company_name').val();

            //used For Dis User
            $stateParams.companyID = angular.element('#companyID').val();

            vm.InputDetails.companyTypeID = $stateParams.companyTypeID;

            vm.InputDetails.companyName = $stateParams.companyName;
            vm.InputDetails.trainingDate = $stateParams.traDate;
            vm.InputDetails.searchText = $stateParams.searchTxt;

            vm.title = "Fit Test Record";
            vm.isSearch = false;
            if ($stateParams.companyName != "") {

                if ($stateParams.companyId > 0 && $stateParams.trainerId != null) {

                    vm.TTrainersList = false;
                    vm.TTraineesList = true;
                    vm.InputDetails.companyPriId = $stateParams.companyId;
                    vm.InputDetails.trainerId = $stateParams.trainerId;
                    vm.InputDetails.adminId = config.roleTicketId;
                    vm.InputDetails.companyId = $stateParams.companyID;
                    var promises = [getTraineesList(vm.InputDetails)];
                    return $q.all(promises).then(function () {
                    });

                }

                else {
                    vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
                    LoadTrainerFittestRecord($stateParams.companyName)


                }
            }
            else {
                if ($stateParams.companyId > 0 && $stateParams.trainerId != null) {

                    vm.TTrainersList = false;
                    vm.TTraineesList = true;
                    vm.InputDetails.companyPriId = $stateParams.companyId;
                    vm.InputDetails.trainerId = $stateParams.trainerId;
                    vm.InputDetails.adminId = config.roleTicketId;
                    vm.InputDetails.companyId = $stateParams.companyID;
                    setPage(0);
                    //var promises = [getTraineesList(vm.InputDetails)];
                    //return $q.all(promises).then(function () {
                    //});

                }
                else {

                    if ($stateParams.comName != undefined || $stateParams.traDate != undefined || $stateParams.searchTxt != undefined) {
                        LoadTrainerFittestRecord($stateParams.companyName)

                        if (config.roleTicketId == 3 || config.roleTicketId == 4) {


                            vm.CompanyDts.companyName = $stateParams.disCompanyName;
                            vm.InputDetails.companyName = $stateParams.disCompanyName;
                            //Load Dis Company Name
                            fittestrecordService.getDisCompaniesList(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownListDis = data.companyName;
                            });

                        }
                        else {
                            fittestrecordService.getCompaniesListFitTrain(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownList = data.companyName;
                            });
                        }
                    }
                    else {
                        vm.TTrainersList = true;

                        if (config.roleTicketId == 3 || config.roleTicketId == 4) {

                            vm.CompanyDts.disID = 1;
                            vm.CompanyDts.tID = 1;
                            vm.CompanyDts.companyName = $stateParams.disCompanyName;
                            vm.InputDetails.companyName = $stateParams.disCompanyName;
                            //Load Dis Company Name
                            fittestrecordService.getDisCompaniesList(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownListDis = data.companyName;
                            });

                        }
                        else {
                            fittestrecordService.getCompaniesListFitTrain(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownList = data.companyName;
                            });
                        }
                    }
                }
            }
        }


        function LoadTrainerFittestRecord(CompanyName) {
            vm.isSearch = false;
            if ($stateParams.companyId > 0 && $stateParams.trainerId != null) {

                vm.TTrainersList = false;
                vm.TTraineesList = true;
                vm.InputDetails.companyPriId = $stateParams.companyId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                vm.InputDetails.adminId = config.roleTicketId;
                vm.InputDetails.companyId = $stateParams.companyId;
                setPage(0);
                //var promises = [getTraineesList(vm.InputDetails)];
                //return $q.all(promises).then(function () {
                //});

            }
            else {
                $stateParams.companyName = angular.element('#company_name').val();
                $stateParams.trainingDate = vm.trainingDate;
                vm.InputDetails.companyName = angular.element('#company_name').val();
                vm.InputDetails.trainingDate = vm.trainingDate;
                vm.InputDetails.searchText = vm.searchText;
                vm.InputDetails.trainingTypeID = 1;

                if (vm.InputDetails.companyTypeID == 3)
                {
                    if (vm.InputDetails.companyName == "" || vm.InputDetails.companyName == null)
                    {
                        vm.InputDetails.companyName = $stateParams.disCompanyName;
                    }
                }


                setPage(0);
            }
            //var promises = [getTrainerFittestRecord(vm.InputDetails)];
            //return $q.all(promises).then(function () {
            //});
        }

        function getTraineesList(InputDetails) {

            return fittestrecordService.getTraineesList(InputDetails).then(function (data) {
                //alert(JSON.stringify(data));
                vm.TraineesDetails = data;
                vm.TrainingDateRef = data[0].TrainingDate;
                vm.title = "Trainees Listing";
                vm.tempDetails = data;
                vm.isSearch = true;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }

            });
        }
        function getTrainerFittestRecord(InputDetails) {
           
            return fittestrecordService.getTrainerfittestRecordDetails(InputDetails).then(function (data) {
                vm.TrainerFittestRecordDetails = {};
                vm.TrainerFittestRecordDetails = data;
                vm.tempDetails = data;
                vm.isSearch = false;
                if (data.length > 0) {
                    vm.TTrainersListGrid = true;
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;

                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                    vm.TTrainersListGrid = false;
                }
            });
            //}
            //else {
            //   logger.warning("Please select any one from the text boxes", "", "");
            //}

        }

        //Searching
        function SearchTrainerFittestRecord(search) {

            vm.InputDetails.pageIndex = 1;
            vm.TrainerFittestRecordtable(search)
        }
        function TrainerFittestRecordtable(search) {
            vm.InputDetails.searchText = search;
            if ($stateParams.trainerId != null) {
                vm.trainerId = $stateParams.trainerId;
                setPage(0);

            }
            else {
                setPage(0);

            }
        }
        //Sorting
        function sort(newSortField) {

            if (vm.sortField == newSortField)
                //vm.descending = !vm.descending;
                vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            if ($stateParams.trainerId != null) {
                vm.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else {
                var promises = [getTrainerFittestRecord(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        // Export To Excel
        function ExportToExcel(tTID, searchText, sortColumn, sortOrder) {
            if ($stateParams.trainerId != null) {
                window.location.href = config.baseURL + "CustomerListing/ExportTrainees?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&TotalRecords=" + $scope.totalItems + "&companyPriId=" + $stateParams.companyId + "&trainerId=" + $stateParams.trainerId + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&disId=" + vm.InputDetails.companyId + "&adminID=" + vm.InputDetails.adminId;
            }
            else {
                window.location.href = config.baseURL + "DocManager/ExportTrainerFittestRecord?searchText=" + encodeURIComponent(searchText) + "&CompanyName=" + encodeURIComponent(vm.InputDetails.companyName) + "&CompanyTypeId=" + vm.InputDetails.companyTypeID + "&TrainingDate=" + vm.InputDetails.trainingDate + "&TTID=" + vm.CompanyDts.tID + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems + "&disId=" + vm.InputDetails.companyId + "&adminID=" + vm.InputDetails.adminId;
            }
        }


        //Paging
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {

            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }

            var ps = [];
            var start;

            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }

            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {

            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }

            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;

            if (cPage != 0) {
                if ($stateParams.trainerId != null) {
                    vm.trainerId = $stateParams.trainerId;
                    var promises = [getTraineesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    var promises = [getTrainerFittestRecord(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;

            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;

            if (cPage != vm.pageCount()) {
                if ($stateParams.trainerId != null) {
                    vm.trainerId = $stateParams.trainerId;
                    var promises = [getTraineesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    var promises = [getTrainerFittestRecord(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        };
        function setPage(n) {
            //alert(n);
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;
            if ($stateParams.trainerId != null) {
                vm.TTraineesList = true;
                vm.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else {
                vm.TTrainersList = true;
                vm.trainerId = $stateParams.trainerId;
                var promises = [getTrainerFittestRecord(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };


        function TraineesDetails(CompanyId, RefNo) {
            $state.transitionTo('efitmenu.FitTestRecord', { companyId: CompanyId, trainerId: RefNo }, { notify: true });
        };

        $scope.sortInfo = { fields: [''], directions: [''] };

        $scope.FittestGrid = {
            data: 'vm.TrainerFittestRecordDetails',
            enableColumnResize: true,
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            columnDefs: [
                {
                    cellTemplate: '<div class="link3"><a ng-click="vm.TraineesDetails(row.entity.CompanyId,row.entity.RefNo)">{{row.getProperty(\'TRFDateS\')}}</a></div>',
                    field: 'TRFDateS', displayName: 'Training Date', width: '20%'
                },
            { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
            { field: 'TrainerName', displayName: 'Trainer Name', width: '20%' },
            { field: 'TrainerCompanyName', displayName: 'Trainer Company Name', width: '20%' },
             { field: 'Email', displayName: 'Email', width: '20%' }, ]
        };
        $scope.$watch('FittestGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.fields[0] == "TRFDateS") {

                if ($scope.sortInfo.directions[0] == "asc")
                { vm.descending = true; sort("TrainingDate"); }
                else if ($scope.sortInfo.directions[0] == "desc")
                { vm.descending = false; sort("TrainingDate"); }
                else { sort("TrainingDate"); }
                
            }
            else {

                if ($scope.sortInfo.directions[0] == "asc")
                { vm.descending = true; sort($scope.sortInfo.fields[0]); }
                else if ($scope.sortInfo.directions[0] == "desc")
                { vm.descending = false; sort($scope.sortInfo.fields[0]); }
                else
                {
                    sort($scope.sortInfo.fields[0]);
                }
                
            }
        }, true);

        $(window).resize(function () {
        });


        $scope.sortInfoTr = { fields: [''], directions: [''] };
        $scope.FittestTraineeGrid = {
            data: 'vm.TraineesDetails',
            enableColumnResize: true,
            sortInfo: $scope.sortInfoTr,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            columnDefs: [
            { field: 'TraineeName', displayName: 'Trainee Name', width: '20%' },
            { field: 'Designation', displayName: 'Designation', width: '20%' },
            { field: 'Dept', displayName: 'Dept', width: '20%' },
            { field: 'IC', displayName: 'ID No.', width: '20%' },
            { field: 'Model', displayName: 'Model', width: '20%' },
            { field: 'Outcome', displayName: 'Outcome', width: '20%' }, ]
        };
        $scope.$watch('FittestTraineeGrid.ngGrid.config.sortInfo', function () {

            if ($scope.sortInfoTr.directions[0] == "asc")
            { vm.descending = true; sort($scope.sortInfoTr.fields[0]); }
            else if ($scope.sortInfoTr.directions[0] == "desc")
            { vm.descending = false; sort($scope.sortInfoTr.fields[0]); }
          

            
        }, true);


        $(window).resize(function () {
        });
    }
})();
