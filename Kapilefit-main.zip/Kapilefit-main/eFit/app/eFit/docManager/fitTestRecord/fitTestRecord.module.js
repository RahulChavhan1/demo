﻿(function () {
    'use strict';

    angular.module('docManager.fitTestRecord', [

    ]);
})();