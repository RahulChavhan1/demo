﻿(function () {
    'use strict';
    angular
        .module('docManager.fitTestRecord', [])
        .factory('fittestrecordService', fittestrecordService)
    fittestrecordService.$inject = ['$http', '$q', '$timeout', 'config'];

    function fittestrecordService($http, $q, $timeout, config) {
        var service = {
            getfittestrecord: getfittestrecord,
            getTrainerfittestRecordDetails: getTrainerfittestRecordDetails,
            getCompaniesListDetails: getCompaniesListDetails,
            checkCompanyName: checkCompanyName,
            getTraineesList: getTraineesList,
            getDisCompaniesList: getDisCompaniesList,
            getCompaniesListFitTrain: getCompaniesListFitTrain

        };
        return service;
        function getCompaniesListDetails(companyTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/CertifiedTraineesApi/GetCompaniesList/' + companyTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getfittestrecord() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetTrainingType'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTrainerfittestRecordDetails(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/TrainingTrainerApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function checkCompanyName(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/UserMaintenanceAdminApi/CheckCompanyName',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getTraineesList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetTraineesList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getDisCompaniesList(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/DocMangerApi/GetDistributorCompaniesList',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getCompaniesListFitTrain(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/DocMangerApi/GetCompaniesListFitTrain',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        
    }
})();