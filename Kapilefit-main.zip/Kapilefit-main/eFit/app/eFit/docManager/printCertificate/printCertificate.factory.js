﻿(function () {
    'use strict';
    //  angular.module('ui.filters', []);
    angular
        .module('docManager.printCertificate', [])
        .factory('printcertificateService', printcertificateService)

    printcertificateService.$inject = ['$http', '$q', '$timeout', 'config'];

    function printcertificateService($http, $q, $timeout, config) {
        var service = {           
            gettraineelist: gettraineelist,
            //getTraineeName: getTraineeName,
            getactiveTrainers: getactiveTrainers,
           // getTrainerName: getTrainerName,
            SaveprintCerData: SaveprintCerData,
            checkTrainerName: checkTrainerName,
            checkTraineeName: checkTraineeName,
        };
        return service;

      

        function getactiveTrainers(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/StatusInquiryApi/GetTrainerListPC',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function gettraineelist(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/StatusInquiryApi/GetTraineeList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
      

        function SaveprintCerData(checkedData) {

            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/PrintCertificateApi/',
                data: JSON.stringify({ refNo: checkedData }),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function checkTrainerName(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/DocMangerApi/CheckTrainerName',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function checkTraineeName(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/DocMangerApi/CheckTraineeName',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        

    }
})();