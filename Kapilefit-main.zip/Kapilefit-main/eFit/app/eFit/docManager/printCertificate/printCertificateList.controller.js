﻿(function () {
    'use strict';

    angular
        .module('docManager.printCertificate')

        .controller('PrintCertificateListCtrl', PrintCertificateListCtrl)

    PrintCertificateListCtrl.$inject = ['$state', '$q', 'printcertificateService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function PrintCertificateListCtrl($state, $q, printcertificateService, logger, $timeout, $filter, $stateParams, $scope, config) {
        //Variable Declaration
        var vm = this;
        vm.title = 'TraineeList Details Ctrl';
        vm.TraineeListDetails = {};
        vm.tempDetails = {};
        vm.InputDetails = {};
        $scope.mySelections = [];
        $scope.SelectedTrainee = [];
        $scope.selectedIDs = [];
        $scope.selectedID = [];
        //vm.CompanyDts = {};
        //$scope.TraineeDropdownList = [];
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.tempIndex = 1;
        //vm.InputDetails.Name = "";
        vm.InputDetails.NRIC = "";
        vm.showPage = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        vm.TrainingType = 1;
        vm.tType = 2;
        vm.showPageContent = true;
        vm.showPrint = false;
        vm.WaitMsg = "1";
        vm.showTrainer = false;
        vm.showTrainee = false;
      

        // Method Declaration
        vm.SearchtraineeList = SearchtraineeList;
        vm.traineeListtable = traineeListtable;
        vm.sort = sort;       
        vm.LoadtraineeListDetails = LoadtraineeListDetails;
        vm.ExportToExcel = ExportToExcel;
        vm.checkAll = CheckAll;
        vm.PrintCertificate = PrintCertificate;
        vm.Exit = exit;
        vm.checkSingle = checkSingle;
        vm.OnchangeRecoredsperpage = OnchangeRecoredsperpage;
        vm.setPage = setPage;
        activate();

  
        // Method Definition
        function activate() {
         
            $stateParams.companyName = angular.element('#company_name').val();
            $stateParams.companyTypeID = angular.element('#companyTypeId').val();

            vm.InputDetails.CompanyName = $stateParams.companyName;
            vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
            vm.TrainingTypeID = 1;
        }
        function OnchangeRecoredsperpage() {
            $scope.selectedIDs = [];
            $scope.selectedID = [];

            $scope.PrintTrainerGrid.selectAll(false);
            $scope.PrintTraineeGrid.selectAll(false);

            vm.showTrainer = false;
            vm.showTrainee = false;
            vm.showPage = false;
            vm.showPrint = false;
            vm.InputDetails.pageIndex = 1;
            vm.TraineeListDetails = {};
            vm.InputDetails.searchText = "";
            vm.InputDetails.NRIC = "";
            setPage(0);
        }
        function LoadtraineeListDetails() {
            $scope.selectedIDs = [];
            $scope.selectedID = [];           

            vm.showTrainer = false;
            vm.showTrainee = false;
            vm.showPage = false;
            vm.TraineeListDetails = {};
            if (vm.tType == 1) {
                setPage(0);
              
            }
            else if (vm.tType == 2) {
                setPage(0);
               
            }
        }
           
        function getactiveTrainersList(InputDetails) {
               
            if ($stateParams.companyTypeID != 1) {
                vm.InputDetails.CompanyName = $stateParams.companyName;
                vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
            }
                        return printcertificateService.getactiveTrainers(InputDetails).then(function (data) {
                            vm.TraineeListDetails = data;
                            vm.tempDetails = data;
                            if (data.length > 0) {
                                vm.showPage = true;
                                vm.showTrainer = true;
                                vm.showTrainee = false;
                                $scope.totalItems = data[0].TotalRecords;
                                $scope.totalItemsTemp = data[0].TotalRecords;
                            }
                            else {
                                vm.showPage = false;
                                $scope.totalItems = 0;
                            }
                        });
                    }
        
        
        function gettraineelist(InputDetails) {
            
            if ($stateParams.companyTypeID != 1) {
                vm.InputDetails.CompanyName = $stateParams.companyName;
                vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
            }
                        return printcertificateService.gettraineelist(InputDetails).then(function (data) {
                            vm.TraineeListDetails = data;
                            vm.tempDetails = data;
                            if (data.length > 0) {
                                 vm.showPage = true;
                                 vm.showTrainee = true;
                                 vm.showTrainer = false;
                                 $scope.totalItems = data[0].TotalRecords;
                                 $scope.totalItemsTemp = data[0].TotalRecords;
                            }
                            else {
                                vm.showPage = false;
                                $scope.totalItems = 0;
                            }
                        });
                    }
    

        //Searching
        function SearchtraineeList(search) {
            vm.InputDetails.pageIndex = 1;
            vm.traineeListtable(search)
        }
        function traineeListtable(search) {
            vm.PageNo = 0;
            vm.currentPage = 0;
            vm.InputDetails.searchText == undefined ? "null" : vm.InputDetails.searchText.trim();

            vm.InputDetails.searchText = search;

            if (vm.InputDetails.searchText != "") {

                if (vm.tType == 1) {
                    setPage(vm.PageNo)
                    var promises = [getactiveTrainersList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if (vm.tType == 2) {
                    setPage(vm.PageNo)
                    var promises = [gettraineelist(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }

            }
            else {
                if (filterTextTimeout) $timeout.cancel(filterTextTimeout);
                vm.searchText = null;
            }


          
        }
        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
                //vm.descending = !vm.descending;
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            
            if (vm.tType == 1) {
                var promises = [getactiveTrainersList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else if (vm.tType == 2) {
                var promises = [gettraineelist(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        // Export To Excel
        function ExportToExcel() {
            if (vm.tType == 1) {
                window.location.href = config.baseURL + "StatusInquiry/ExporttrainerListPC?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&CompanyName=" + vm.InputDetails.CompanyName + "&companyTypeID=" + vm.InputDetails.companyTypeID + "&Name=" + vm.InputDetails.Name + "&NRIC=" + vm.InputDetails.NRIC + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems;
            }
            else if (vm.tType == 2) {
                window.location.href = config.baseURL + "StatusInquiry/ExporttraineeList?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&CompanyName=" + vm.InputDetails.CompanyName + "&companyTypeID=" + vm.InputDetails.companyTypeID + "&Name=" + vm.InputDetails.Name + "&NRIC=" + vm.InputDetails.NRIC + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems;
            }
        }
        //CheckBox Selection
        function checkSingle() {
            vm.showPrint = false;
            angular.forEach(vm.TraineeListDetails, function (item) {
                if (item.Selected) {
                    vm.showPrint = true;
                }
            });
        }
        function CheckAll() {
            
            if (vm.selectedAll)
            {
                vm.selectedAll = true;
                vm.showPrint = true;
            }
            else
            {
                vm.selectedAll = false;
                vm.showPrint = false;
            }
            angular.forEach(vm.TraineeListDetails, function (item) {
                item.Selected = vm.selectedAll;
            });
        }

        //Certificate Print
        function PrintCertificate() {
            vm.WaitMsg = "1";
            document.getElementById('loader').style.display = 'block';
            if (vm.tType == 1) {
                vm.check = [];
                var uncheck = [];
                //alert(JSON.stringify($scope.selectedIDs));
                angular.forEach($scope.selectedIDs, function (item) {
                    vm.check.push({ RefNo: item.RefNo + "|" + item.TraineeName + "|" + item.CompanyName + "|" + item.IC + "|" + item.TrainingDate + "|" + item.TrainerPicField });
                });
                $scope.totalItems = vm.check.length;
                return printcertificateService.SaveprintCerData(vm.check).then(function (data) {
                    if (data.success == true) {
                        $("#PrintPreview iframe").attr("src", config.baseURL + "CertifiedTrainees/PrintByAppendTrainers?GuidId=" + data.id);
                        vm.showPageContent = false;
                        vm.exitShow = true;
                    }
                });
            }
            if (vm.tType == 2) {
                vm.check = [];
                var uncheck = [];
                //alert(JSON.stringify($scope.selectedID));
                angular.forEach($scope.selectedID, function (item) {
                    vm.check.push({ RefNo: item.RefNo + "|" + item.TraineeName + "|" + item.CompanyName + "|" + item.IC + "|" + item.TrainingDate + "|" + item.Model });
                });
                $scope.totalItems = vm.check.length;
                return printcertificateService.SaveprintCerData(vm.check).then(function (data) {
                    if (data.success == true) {
                        $("#PrintPreview iframe").attr("src", config.baseURL + "CertifiedTrainees/PrintByAppendTrainees?GuidId=" + data.id);
                        vm.showPageContent = false;
                        vm.exitShow = true;
                    }
                });
            }
        }
        //Load text while certificate generation
        $(document).ready(function () {
            $('#iframe').on('load', function () {
                if (vm.WaitMsg == 1) {
                    //$('#loader').css('display', 'none');
                    document.getElementById('loader').style.display = 'none';
                }

            });
        });

        function exit() {
            $scope.totalItems = $scope.totalItemsTemp;
            $scope.PrintTrainerGrid.selectAll(false);
            $scope.PrintTraineeGrid.selectAll(false);

            vm.WaitMsg = "2";
            vm.showPageContent = true;
            vm.exitShow = false;
            //$('#loader').css('display', 'block');
            document.getElementById('loader').style.display = 'block';
            $("#PrintPreview iframe").attr("src", 'about:blank');
        }

   
        //Paging
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }
            var ps = [];
            var start;
            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }
            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;
            if (cPage != 0) {
                if (vm.tType == 1) {
                    var promises = [getactiveTrainersList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if (vm.tType == 2) {
                    var promises = [gettraineelist(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;
            if (cPage != vm.pageCount()) {
              
                if (vm.tType == 1) {
                    var promises = [getactiveTrainersList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if (vm.tType == 2) {
                    var promises = [gettraineelist(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }

            }
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };
          function setPage(n) {
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;

            if (vm.tType == 1) {
                var promises = [getactiveTrainersList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else if (vm.tType == 2) {
                var promises = [gettraineelist(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }

           
          };


          $scope.sortInfo = { fields: [''], directions: [''] };
          $scope.PrintTrainerGrid = {
                  data: 'vm.TraineeListDetails',
                  sortInfo: $scope.sortInfo,
                  enableSorting: true,
                  useExternalSorting: true,
                  keepLastSelected: true,
                  showColumnMenu: false,
                  enableColumnResize: true,
                  showSelectionCheckbox: true,
                  selectedItems: $scope.mySelections,
                  multiSelect: true,

                  afterSelectionChange: function () {
                      $scope.selectedIDs = [];
                      angular.forEach($scope.mySelections, function (item) {

                          $scope.selectedIDs.push(item)

                      });
                      if ($scope.selectedIDs.length > 0) {
                          vm.showPrint = true;
                      }
                      else {
                          vm.showPrint = false;
                      }

                  },
                  columnDefs: [
                  { field: 'TrainingDate', displayName: 'Training Date', width: '12%' },
                  { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
                  { field: 'TraineeName', displayName: 'Trainee Name', width: '15%' },
                  {
                      cellTemplate: '<div style="text-align:center;" class="ngCellText">1</div>',
                      displayName: 'No Of Years', width: '12%'
                  },
                  { field: 'Designation', displayName: 'Designation', width: '15%' },
                  { field: 'Dept', displayName: 'Dept', width: '15%' },
                  { field: 'IC', displayName: 'ID No.', width: '8%' },
                  { field: 'Model', displayName: 'Model', width: '8%' },
                  { field: 'ContactPerson', displayName: 'Contact Person', width: '15%' },
                  { field: 'ContactNo', displayName: 'Contact No', width: '15%' },
                  { field: 'TrainerName', displayName: 'Trainer Name', width: '15%' },
                  { field: 'TrainerPicField', displayName: 'TrainerPicFileId', visible:false },
                   { field: 'RefNo', displayName: 'Ref No', width: '8%' }, ]
              };

              $scope.$watch('PrintTrainerGrid.ngGrid.config.sortInfo', function () {

                  if ($scope.sortInfo.directions[0] == "asc")
                  { vm.descending = true; }
                  else
                  { vm.descending = false; }

                  if ($scope.sortInfo.fields[0] == "") {
                  }
                  else {
                      sort($scope.sortInfo.fields[0]);
                  }
              }, true);

              $(window).resize(function () {
              });
          
          
              $scope.PrintTraineeGrid = {
                  data: 'vm.TraineeListDetails',
                  sortInfo: $scope.sortInfo,
                  enableSorting: true,
                  useExternalSorting: true,
                  keepLastSelected: true,
                  showColumnMenu: false,
                  enableColumnResize: true,
                  showSelectionCheckbox: true,
                  selectedItems: $scope.SelectedTrainee,
                  multiSelect: true,
                  
                  afterSelectionChange: function () {
                      $scope.selectedID = [];
                      angular.forEach($scope.SelectedTrainee, function (item) {

                          $scope.selectedID.push(item)

                      });
                      if ($scope.selectedID.length > 0) {
                          vm.showPrint = true;
                      }
                      else {
                          vm.showPrint = false;
                      }

                  },
                  columnDefs: [
                  { field: 'TrainingDate', displayName: 'Training Date', width: '12%' },
                  { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
                  { field: 'TraineeName', displayName: 'Trainee Name', width: '15%' },
                  {
                      cellTemplate: '<div style="text-align:center;" class="ngCellText">1</div>',
                      displayName: 'No Of Years', width: '12%'
                  },
                  { field: 'Designation', displayName: 'Designation', width: '15%' },
                  { field: 'Dept', displayName: 'Dept', width: '15%' },
                  { field: 'IC', displayName: 'ID No.', width: '8%' },
                  { field: 'Model', displayName: 'Model', width: '8%' },
                  { field: 'ContactPerson', displayName: 'Contact Person', width: '15%' },
                  { field: 'ContactNo', displayName: 'Contact No', width: '15%' },
                  { field: 'TrainerName', displayName: 'Trainer Name', width: '15%' },
                   { field: 'RefNo', displayName: 'Ref No', width: '15%' }, ]
              };

              $scope.$watch('PrintTraineeGrid.ngGrid.config.sortInfo', function () {

                  if ($scope.sortInfo.directions[0] == "asc")
                  { vm.descending = true; }
                  else
                  { vm.descending = false; }

                  if ($scope.sortInfo.fields[0] == "") {
                  }
                  else {
                      sort($scope.sortInfo.fields[0]);
                  }
              }, true);

              $(window).resize(function () {
              });
          
    }
})();
