﻿(function () {
    'use strict';
    angular
        .module('docManager.trainTrainer', [])
        .factory('traintrainerService', traintrainerService)

    traintrainerService.$inject = ['$http', '$q', '$timeout', 'config'];

    function traintrainerService($http, $q, $timeout, config) {
        var service = {
            getCompaniesList: getCompaniesList,
            getTrainingType: getTrainingType,
            getTrainingTrainerDetails: getTrainingTrainerDetails,
            checkCompanyName: checkCompanyName,
            getDisCompaniesList: getDisCompaniesList,
            getCompaniesListFitTrain: getCompaniesListFitTrain,
            Logout: Logout,
            getTraineesList: getTraineesList
        };
        return service;

        function getCompaniesList(companyTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/CertifiedTraineesApi/GetCompaniesList/' + companyTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getTrainingType() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/eFitToolAdminApi/GetTrainingType'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;

        }

        function getTrainingTrainerDetails(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/TrainingTrainerApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function checkCompanyName(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/UserMaintenanceAdminApi/CheckCompanyName',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

         function getDisCompaniesList(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/DocMangerApi/GetDistributorCompaniesList',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
         }

         function getCompaniesListFitTrain(CompanyDts) {
             var deferred = $q.defer();
             $http({
                 method: 'Post',
                 url: config.baseURL + 'api/DocMangerApi/GetCompaniesListFitTrain',
                 data: JSON.stringify(CompanyDts),
                 contentType: "application/json"
             }).success(deferred.resolve).error(deferred.reject);
             return deferred.promise;
         }

         function Logout() {
             var deferred = $q.defer();
             $http({
                 method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
             }).success(deferred.resolve).error(deferred.reject);
             return deferred.promise;
         }

         function getTraineesList(InputDetails) {
             var deferred = $q.defer();
             $http({
                 method: 'Post',
                 url: config.baseURL + 'api/CustomerListingApi/GetTraineesList',
                 data: JSON.stringify(InputDetails),
                 contentType: "application/json"
             }).success(deferred.resolve).error(deferred.reject);
             return deferred.promise;
         }
    }
})();