﻿(function () {
    'use strict';

    angular
        .module('docManager.trainTrainer')

        .controller('TrainTrainerListCtrl', TrainTrainerListCtrl)

    TrainTrainerListCtrl.$inject = ['$state', '$q', 'traintrainerService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function TrainTrainerListCtrl($state, $q, traintrainerService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'TrainTrainer Details Ctrl';
        vm.TrainTrainerDetails = {};
        vm.tempDetails = {};
        vm.CompanyDts = {};
        vm.TrainingTypeDD = {};
        vm.InputDetails = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.traineeType = 2;
        vm.showPage = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        vm.InputDetails.companyTypeID = 0;
        vm.trainingDate = "";
        vm.searchText = "";
        //vm.RecordsPerPageList = [5, 10];
        //vm.pageNo = 0;
        vm.TTrainersList = false;
        vm.TTraineesList = false;
        vm.TTrainersListGrid = false;
        vm.title = "";
        vm.isSearch = false;
        vm.TrainingDateRef = "";

        // Method Declaration
        vm.SearchTrainerTraining = SearchTrainerTraining;
        vm.trainerTrainingtable = trainerTrainingtable;
        vm.sort = sort;
        vm.LoadTrainTheTrainersDetails = LoadTrainTheTrainersDetails;
        vm.ExportToExcel = ExportToExcel;     
        vm.setPage = setPage;

        vm.TraineesDetails = TraineesDetails;
        //activate();
        $stateParams.companyId = $stateParams.companyId == "" ? 0 : $stateParams.companyId;
        $stateParams.trainerId = $stateParams.trainerId == "" ? null : $stateParams.trainerId;

        $stateParams.comName = $stateParams.comName == "" ? null : $stateParams.comName;
        $stateParams.traDate = $stateParams.traDate == "" ? null : $stateParams.traDate;
        $stateParams.searchTxt = $stateParams.searchTxt == "" ? null : $stateParams.searchTxt;

        activate();

         //Method Definition
        function activate() {
            $stateParams.companyTypeId = 3;
            vm.CompanyDts.disID = 2;
            vm.CompanyDts.tID = 2;
            $stateParams.companyName = angular.element('#company_name').val();
            $stateParams.companyTypeID = angular.element('#companyTypeId').val();
            $stateParams.disCompanyName = angular.element('#dis_company_name').val();
            //vm.InputDetails.adminId = config.roleTicketId;


            //used For Dis User
            $stateParams.companyID = angular.element('#companyID').val();

            vm.InputDetails.companyTypeID = $stateParams.companyTypeID;

            if ($stateParams.companyName != "") {

                if ($stateParams.companyId > 0 && $stateParams.trainerId != null) {

                    vm.TTrainersList = false;
                    vm.TTraineesList = true;
                    vm.InputDetails.companyPriId = $stateParams.companyId;
                    vm.InputDetails.trainerId = $stateParams.trainerId;
                    vm.InputDetails.adminId = config.roleTicketId;
                    vm.InputDetails.companyId = $stateParams.companyID;
                    var promises = [getTraineesList(vm.InputDetails)];
                    return $q.all(promises).then(function () {
                    });

                }

                else {
                    vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
                    LoadTrainTheTrainersDetails($stateParams.companyName)
                }
                
            }
            else {

                if ($stateParams.companyId > 0 && $stateParams.trainerId != null) {

                    vm.TTrainersList = false;
                    vm.TTraineesList = true;
                    vm.InputDetails.companyPriId = $stateParams.companyId;
                    vm.InputDetails.trainerId = $stateParams.trainerId;
                    vm.InputDetails.adminId = config.roleTicketId;
                    vm.InputDetails.companyId = $stateParams.companyID;
                    setPage(0);
                  

                }

                else {

                    if ($stateParams.comName != undefined || $stateParams.traDate != undefined || $stateParams.searchTxt != undefined) {
                        LoadTrainTheTrainersDetails($stateParams.companyName)

                        if (config.roleTicketId == 3 || config.roleTicketId == 4) {


                            vm.CompanyDts.companyName = $stateParams.disCompanyName;
                            vm.InputDetails.companyName = $stateParams.disCompanyName;
                            //Load Dis Company Name
                            traintrainerService.getDisCompaniesList(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownListDis = data.companyName;
                            });

                        }
                        else {
                            traintrainerService.getCompaniesListFitTrain(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownList = data.companyName;
                            });
                        }
                    }
                    else {
                        vm.TTrainersList = true;

                        if (config.roleTicketId == 3 || config.roleTicketId == 4) {

                            vm.CompanyDts.disID = 1;
                            vm.CompanyDts.tID = 1;
                            vm.CompanyDts.companyName = $stateParams.disCompanyName;
                            vm.InputDetails.companyName = $stateParams.disCompanyName;
                            //Load Dis Company Name
                            traintrainerService.getCompaniesListFitTrain(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownListDis = data.companyName;
                            });

                        }
                        else {
                            traintrainerService.getCompaniesListFitTrain(vm.CompanyDts).then(function (data) {
                                $scope.CompanyDropdownList = data.companyName;
                            });
                        }
                    }
                }

            }

            
        }

        function LoadTrainTheTrainersDetails(CompanyName)
        {
            $stateParams.companyName = angular.element('#company_name').val();
            $stateParams.trainingDate = vm.trainingDate;
            vm.InputDetails.companyName = angular.element('#company_name').val();
            vm.InputDetails.trainingDate = vm.trainingDate;
            vm.InputDetails.searchText = vm.searchText;
            vm.InputDetails.trainingTypeID = 2;
            setPage(0);          
        }
        function getTrainingTrainer(InputDetails) {
            //if (vm.InputDetails.companyName != "" || vm.trainingDate != "" || vm.searchText != "") {
              
                return traintrainerService.getTrainingTrainerDetails(InputDetails).then(function (data) {
                    vm.TrainTrainerDetails = {};
                    vm.TrainTrainerDetails = data;
                    vm.tempDetails = data;
                    if (data.length > 0) {
                        vm.TTrainersListGrid = true;
                        vm.showPage = true;
                        $scope.totalItems = data[0].TotalRecords;
                    }
                    else {
                        vm.showPage = false;
                        $scope.totalItems = 0;
                        vm.TTrainersListGrid = false;
                    }
                });
            //}
            //else {
            //    logger.warning("Please select any one from the text boxes", "", "");
            //}
        }
        function LogOut() {
            traintrainerService.Logout().then(function (data) {
                if (data == "LogedOut") {
                    window.location = config.baseURL + "Login/index";
                }
            });
        }

        //Searching
        function SearchTrainerTraining(search) {
            vm.InputDetails.pageIndex = 1;
            vm.trainerTrainingtable(search)
        }
        function trainerTrainingtable(search) {
            vm.InputDetails.searchText = search;
            if ($stateParams.trainerId != null) {
                vm.trainerId = $stateParams.trainerId;
                setPage(0);

            }
            else {
                setPage(0);

            }
        }
        //Sorting
        function sort(newSortField) {

            if (vm.sortField == newSortField)
                //vm.descending = !vm.descending;
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            if ($stateParams.trainerId != null) {
                vm.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else {
                var promises = [getTrainingTrainer(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
          
        };
        // Export To Excel
        function ExportToExcel(tTID, searchText, sortColumn, sortOrder) {
            if ($stateParams.trainerId != null) {
                window.location.href = config.baseURL + "CustomerListing/ExportTrainees?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&TotalRecords=" + $scope.totalItems + "&companyPriId=" + $stateParams.companyId + "&trainerId=" + $stateParams.trainerId + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&disId=" + vm.InputDetails.companyId + "&adminID=" + vm.InputDetails.adminId;
            }
            else {
                window.location.href = config.baseURL + "DocManager/ExportTrainTheTrainer?searchText=" + encodeURIComponent(searchText) + "&CompanyName=" + encodeURIComponent(vm.InputDetails.companyName) + "&CompanyTypeId=" + vm.InputDetails.companyTypeID + "&TrainingDate=" + vm.InputDetails.trainingDate + "&TTID=" + vm.CompanyDts.tID + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems;
            }
        }
       

        //Paging
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
          
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }

            var ps = [];
            var start;

            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }

            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {

            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }

            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;

            if (cPage != 0) {
                if ($stateParams.trainerId != null) {
                    vm.TTraineesList = true;
                    vm.trainerId = $stateParams.trainerId;
                    var promises = [getTraineesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    vm.TTrainersList = true;
                    vm.trainerId = $stateParams.trainerId;
                    var promises = [getTrainingTrainer(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;

            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }

            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;

            if (cPage != vm.pageCount()) {
                if ($stateParams.trainerId != null) {
                    vm.TTraineesList = true;
                    vm.trainerId = $stateParams.trainerId;
                    var promises = [getTraineesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    vm.TTrainersList = true;
                    vm.trainerId = $stateParams.trainerId;
                    var promises = [getTrainingTrainer(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        };
           function setPage(n) {
            //alert(n);
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;

            if ($stateParams.trainerId != null) {
                vm.TTraineesList = true;
                vm.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else {
                vm.TTrainersList = true;
                vm.trainerId = $stateParams.trainerId;
                var promises = [getTrainingTrainer(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }

        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };

        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.TrainTheTrainerGrid = {
            data: 'vm.TrainTrainerDetails',
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            enableColumnResize: true,
            columnDefs: [
            //{ field: 'TRFDateS', displayName: 'Training Date', width: '20%' },
             {
                 cellTemplate: '<div class="link3"><a ng-click="vm.TraineesDetails(row.entity.CompanyId,row.entity.RefNo)">{{row.getProperty(\'TRFDateS\')}}</a></div>',
                 field: 'TRFDateS', displayName: 'Training Date', width: '20%'
             },
            { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
            { field: 'TrainerName', displayName: 'Trainer Name', width: '20%' },
            { field: 'TrainerCompanyName', displayName: 'Trainer Company Name', width: '20%' },
             { field: 'Email', displayName: 'Email', width: '20%' }, ]
        };
        $scope.$watch('TrainTheTrainerGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.fields[0] == "TRFDateS") {
                if ($scope.sortInfo.directions[0] == "asc")
                { vm.descending = true; }
                else
                { vm.descending = false; }
                sort("TrainingDate");
            }
            else {
                if ($scope.sortInfo.directions[0] == "asc")
                { vm.descending = true; }
                else
                { vm.descending = false; }
                sort($scope.sortInfo.fields[0]);
            }
        }, true);


        $(window).resize(function () {
        });



        //Trainees List - toggle

        function TraineesDetails(CompanyId, RefNo) {
            $state.transitionTo('efitmenu.TrainTrainer', { companyId: CompanyId, trainerId: RefNo }, { notify: true });
        };

        function getTraineesList(InputDetails) {

            return traintrainerService.getTraineesList(InputDetails).then(function (data) {
                //alert(JSON.stringify(data));
                vm.TraineesDetails = data;
                vm.TrainingDateRef = data[0].TrainingDate;
                vm.title = "Trainees Listing";
                vm.tempDetails = data;
                vm.isSearch = true;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }

            });
        }

        $scope.sortInfoTr = { fields: [''], directions: [''] };
        $scope.TrainTheTrainerTraineeGrid = {
            data: 'vm.TraineesDetails',
            enableColumnResize: true,
            sortInfo: $scope.sortInfoTr,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            columnDefs: [
            { field: 'TraineeName', displayName: 'Trainee Name', width: '20%' },
            { field: 'Designation', displayName: 'Designation', width: '20%' },
            { field: 'Dept', displayName: 'Dept', width: '20%' },
            { field: 'IC', displayName: 'ID No.', width: '20%' },
            { field: 'Model', displayName: 'Model', width: '20%' },
            { field: 'Outcome', displayName: 'Outcome', width: '20%' }, ]
        };
        $scope.$watch('TrainTheTrainerTraineeGrid.ngGrid.config.sortInfo', function () {

            if ($scope.sortInfoTr.directions[0] == "asc")
            { vm.descending = true; sort($scope.sortInfoTr.fields[0]); }
            else if ($scope.sortInfoTr.directions[0] == "desc")
            { vm.descending = false; sort($scope.sortInfoTr.fields[0]); }


        }, true);


        $(window).resize(function () {
        });

    }
})();
