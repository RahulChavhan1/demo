﻿(function () {
    'use strict';

    angular.module('docManager.core', [
        'docManager.printCertificate',
        'docManager.fitTestRecord',
        'docManager.trainTrainer'
    ]);
})();
