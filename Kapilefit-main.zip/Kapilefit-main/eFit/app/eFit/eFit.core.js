﻿(function () {
    'use strict';

    angular.module('app.eFit', [
        'customerListing.core',
        'certifiedTrainers.core',
        'certifiedTrainees.core',
        'docManager.core',
        'statusInquiry.core'
    ]);
})();
