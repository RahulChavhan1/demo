﻿(function () {
    'use strict';
    //  angular.module('ui.filters', []);
    angular
        .module('statusInquiry.traineeList', [])
        .factory('traineelistService', traineelistService)

        traineelistService.$inject = ['$http', '$q', '$timeout', 'config'];

        function traineelistService($http, $q, $timeout, config) {
        var service = {
            gettraineelist: gettraineelist,
            getTraineeName: getTraineeName
        };
        return service;

        //Method Definition
        function getTraineeName(companyTypeId)
        {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/StatusInquiryApi/GettraineeName/' + companyTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function gettraineelist(TraineeName, NRIC, searchText, pageIndex, pageSize, sortColumn, sortOrder) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/StatusInquiryApi/GetTraineeList/' + TraineeName + '/' + NRIC + '/' + searchText + '/' +
                    pageIndex + '/' + pageSize + '/' + sortColumn + '/' + sortOrder, data: {
                        id: TraineeName
                    }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;        
        }
    }
})();