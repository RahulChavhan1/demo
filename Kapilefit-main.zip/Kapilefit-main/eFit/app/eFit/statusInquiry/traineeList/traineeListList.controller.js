﻿(function () {
    'use strict';

    angular
        .module('statusInquiry.traineeList')

        .controller('TraineeListListCtrl', TraineeListListCtrl)

    TraineeListListCtrl.$inject = ['$state', '$q', 'traineelistService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function TraineeListListCtrl($state, $q, traineelistService, logger, $timeout, $filter, $stateParams, $scope, config) {

         //Variable Declaration
        var vm = this;
        vm.title = 'TraineeList Details Ctrl';
        vm.TraineeListDetails = {};
        vm.tempDetails = {};
        $scope.TraineeDropdownList = [];
        vm.searchText = "";
        vm.pageSize = 50;
        vm.pageIndex = 1;
        vm.sortColumn = "TrainingDate";
        vm.sortOrder = true;
        vm.tempIndex = 1;
        vm.Name = "";
        vm.NRIC = "";
        vm.showPage = false;
        vm.itemsPerPage = vm.pageSize;
        vm.currentPage = 0;
        //vm.RecordsPerPageList = [5, 10, 15];
        //vm.pageNo = 0;

        // Method Declaration
        vm.SearchtraineeList = SearchtraineeList;
        vm.traineeListtable = traineeListtable;
        vm.sort = sort;
        //vm.paginate = paginate;
        vm.LoadtraineeListDetails = LoadtraineeListDetails;
        activate();
        vm.ExportToExcel = ExportToExcel;
        //vm.OnchangeRecoredsperpage = OnchangeRecoredsperpage;
        vm.setPage = setPage;



        // Method Definition
        function activate() {
            $stateParams.companyTypeID = 1;
            return traineelistService.getTraineeName($stateParams.companyTypeID).then(function (data) {
                $scope.TraineeDropdownList = data.TraineeName;
            });     
        }
        function LoadtraineeListDetails() {         
            var promises = [gettraineelist(vm.Name, vm.NRIC, vm.searchText, vm.pageIndex, vm.pageSize, vm.sortColumn, vm.sortOrder), ]
            return $q.all(promises).then(function () {
            });
        }
        function gettraineelist(TraineeName, NRIC, searchText, pageIndex, pageSize, sortColumn, sortOrder) {
            if (searchText == "")
            { searchText = null }
            if (TraineeName == "")
            { TraineeName = null}
            if (NRIC == "")
            { NRIC = null }
            return traineelistService.gettraineelist(TraineeName, NRIC, searchText, pageIndex, pageSize, sortColumn, sortOrder).then(function (data) {
                vm.TraineeListDetails = data;
                vm.tempDetails = data;
                 if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else { $scope.totalItems = 0; }
            });
        }

        //Searching
        function SearchtraineeList(search) {
            vm.traineeListtable(search)
        }
        function traineeListtable(search) {        
            vm.searchText = search;
            var promises = [gettraineelist(vm.Name, vm.NRIC, vm.searchText, vm.pageIndex, vm.pageSize, vm.sortColumn, vm.sortOrder), ];
            return $q.all(promises).then(function () {
            });
        }

        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
                vm.descending = !vm.descending;
            vm.sortField = newSortField;
            vm.sortOrder = vm.descending;
            vm.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            if (vm.descending)
                $('#' + newSortField + ' i').removeClass().addClass('sorts glyphicon glyphicon-sort-by-attributes');
            else
                $('#' + newSortField + ' i').removeClass().addClass('sorts glyphicon glyphicon-sort-by-attributes-alt');
            var promises = [gettraineelist(vm.Name, vm.NRIC, vm.searchText, vm.pageIndex, vm.pageSize, vm.sortColumn, vm.sortOrder), ];
            return $q.all(promises).then(function () {
            });
        };

        // Export To Excel
        function ExportToExcel(Name, NRIC, searchText) {
            window.location.href = config.baseURL + "StatusInquiry/ExporttraineeList?searchText=" + searchText + "&Name=" + Name + "&NRIC=" + NRIC + "&TotalRecords=" + $scope.totalItems;
        }

      
            //Paging
            var rangeVal = vm.itemsPerPage;
            vm.range = function () {
                var dataCount = $scope.totalItems;
                var rangeSize;
                if (dataCount > 0 && dataCount <= rangeVal)
                { rangeSize = 1; }
                else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
                { rangeSize = 2; }
                else
                { rangeSize = 3; }
                var ps = [];
                var start;
                start = vm.currentPage;
                if (start > vm.pageCount() - rangeSize) {
                    start = vm.pageCount() - rangeSize + 1;
                }
                for (var i = start; i < start + rangeSize; i++) {
                    ps.push(i);
                }
                return ps;
            };
            vm.prevPage = function () {
                var cPage = vm.currentPage;
                if (vm.currentPage > 0) {
                    vm.currentPage--;
                }
                vm.pageSize = vm.itemsPerPage;
                vm.pageIndex = vm.currentPage + 1;
                if (cPage != 0) {
                    var promises = [gettraineelist(vm.Name, vm.NRIC, vm.searchText, vm.pageIndex, vm.pageSize, vm.sortColumn, vm.sortOrder), ];
                    return $q.all(promises).then(function () {
                    });
                }
            };
            vm.DisablePrevPage = function () {
                return vm.currentPage === 0 ? "disabled" : "";
            };
            vm.pageCount = function () {
                return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
            };
            vm.nextPage = function () {
                var cPage = vm.currentPage;
                if (vm.currentPage < vm.pageCount()) {
                    vm.currentPage++;
                }
                vm.pageSize = vm.itemsPerPage;
                vm.pageIndex = cPage + 2;
                if (cPage != vm.pageCount()) {
                    var promises = [gettraineelist(vm.Name, vm.NRIC, vm.searchText, vm.pageIndex, vm.pageSize, vm.sortColumn, vm.sortOrder), ];
                    return $q.all(promises).then(function () {
                    });
                }
            };
            vm.DisableNextPage = function () {
                return vm.currentPage === vm.pageCount() ? "disabled" : "";
            };
            function setPage(n) {
                vm.currentPage = n;
                vm.PageNo = vm.itemsPerPage;
                vm.RecordsPerPage = n + 1;
                var promises = [gettraineelist(vm.Name, vm.NRIC, vm.searchText, vm.pageIndex, vm.pageSize, vm.sortColumn, vm.sortOrder), ];
                return $q.all(promises).then(function () {
                });
            };
        }   
})();

       
