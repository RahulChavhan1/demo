﻿(function () {
    'use strict';

    angular
        .module('statusInquiry.core')
        .controller('StatusInquiryListingCtrl', StatusInquiryListingCtrl);

    StatusInquiryListingCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function StatusInquiryListingCtrl($state, $stateParams, $q, $rootScope) {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'StatusInquiry Listing Shell';
        $rootScope.showMenu = true;
        vm.StatusInquiryDetails = {};
        activate();


        function activate() {

            //$state.transitionTo('client.details', { clientID: '2' }, { notify: true });

        }

    }

})();
