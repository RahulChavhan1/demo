﻿(function () {
    'use strict';

    angular
        .module('statusInquiry.trainerList')

        .controller('TrainerListListCtrl', TrainerListListCtrl)

    TrainerListListCtrl.$inject = ['$state', '$q', 'trainerlistService', 'logger', '$timeout', '$filter', '$stateParams','$scope','config'];

    function TrainerListListCtrl($state, $q, trainerlistService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'TrainerList Details Ctrl';
        vm.TrainerListDetails = {};
        vm.tempDetails = {};
        vm.searchText = "";
        vm.pageSize = 50;
        vm.pageIndex = 0;
        vm.sortColumn = "CompanyName";
        vm.sortOrder = true;
        vm.tempIndex = 1;
        vm.showPage = false;
        vm.itemsPerPage = vm.pageSize;
        vm.currentPage = 0;

        vm.InputDetails = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.traineeType = 1;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        //vm.RecordsPerPageList = [5, 10, 15];
        //vm.pageNo = 0;


        
        //vm.totalrec = 0;

        // Method Declaration
        vm.SearchtrainerList = SearchtrainerList;
        vm.trainerListtable = trainerListtable;
        vm.sort = sort;
        activate();
        vm.ExportToExcel = ExportToExcel;
        //vm.OnchangeRecoredsperpage = OnchangeRecoredsperpage;
        vm.setPage = setPage;


        // Method Definition
        function activate() {
            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }

        function gettrainerlist(InputDetails) {
            vm.trainerListDetails = {};
            if  (vm.InputDetails.searchText  == "")
            {  vm.InputDetails.searchText  = null }
            return trainerlistService.gettrainerlist(InputDetails).then(function (data) {
                //alert(JSON.stringify(data));
                vm.trainerListDetails = data;
                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                    //vm.totalrec = data[0].TotalRecords;
                    //alert(vm.totalrec);
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                    //vm.totalrec = 0;
                    //alert(vm.totalrec);
                }
            });
        }

        //Searching
        function SearchtrainerList(search) {
            vm.trainerListtable(search)
        }
        function trainerListtable(search) {
            vm.InputDetails.searchText = search;
            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }
        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
                vm.descending = !vm.descending;
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            if (vm.descending)
                $('#' + newSortField + ' i').removeClass().addClass('sorts glyphicon glyphicon-sort-by-attributes');
            else
                $('#' + newSortField + ' i').removeClass().addClass('sorts glyphicon glyphicon-sort-by-attributes-alt');

            var promises = [gettrainerlist(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        // Export To Excel
        function ExportToExcel(CompanyName, searchText) {

            window.location.href = config.baseURL + "StatusInquiry/ExporttrainerList?searchText=" + searchText + "&CompanyName=" + CompanyName + "&TotalRecords=" + $scope.totalItems;
        }

        //function OnchangeRecoredsperpage(Records) {
        //    vm.InputDetails.pageSize = Records;
        //    vm.itemsPerPage = Records;
        //    rangeVal = vm.itemsPerPage;
        //    vm.PageNo = 0;
        //    vm.pageIndex = 1;
        //    gettrainerlist();
        //    setPage(vm.PageNo)
        //}

            //Paging
            var rangeVal = vm.itemsPerPage;
            vm.range = function () {
                var dataCount = $scope.totalItems;
                var rangeSize;
                if (dataCount > 0 && dataCount <= rangeVal)
                { rangeSize = 1; }
                else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
                { rangeSize = 2; }
                else
                { rangeSize = 3; }

                var ps = [];
                var start;

                start = vm.currentPage;
                if (start > vm.pageCount() - rangeSize) {
                    start = vm.pageCount() - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++) {
                    ps.push(i);
                }
                return ps;
            };
            vm.prevPage = function () {

                var cPage = vm.currentPage;
                if (vm.currentPage > 0) {
                    vm.currentPage--;
                }

                vm.InputDetails.pageSize = vm.itemsPerPage;
                vm.InputDetails.pageIndex = vm.currentPage + 1;

                if (cPage != 0) {
                    var promises = [gettrainerlist(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            };
            vm.pageCount = function () {
                return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
            };
            vm.nextPage = function () {
                var cPage = vm.currentPage;

                if (vm.currentPage < vm.pageCount()) {
                    vm.currentPage++;
                }

                vm.InputDetails.pageSize = vm.itemsPerPage;
                vm.InputDetails.pageIndex = cPage + 2;

                if (cPage != vm.pageCount()) {
                    var promises = [gettrainerlist(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            };
          function setPage(n) {
                //alert(n);
                vm.currentPage = n;
                vm.InputDetails.pageSize = vm.itemsPerPage;
                vm.InputDetails.pageIndex = n + 1;

                var promises = [gettrainerlist(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });



            };
            vm.DisablePrevPage = function () {
                return vm.currentPage === 0 ? "disabled" : "";
            };
            vm.DisableNextPage = function () {
                return vm.currentPage === vm.pageCount() ? "disabled" : "";
            };

        }
})();
