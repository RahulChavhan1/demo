﻿(function () {
    'use strict';

    angular.module('statusInquiry.trainerList', [

    ]);
})();