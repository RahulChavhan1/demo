﻿(function () {
    'use strict';
    angular
        .module('statusInquiry.trainerList', [])
        .factory('trainerlistService', trainerlistService)
    trainerlistService.$inject = ['$http', '$q', '$timeout', 'config'];

    function trainerlistService($http, $q, $timeout, config) {
        var service = {
            gettrainerlist: gettrainerlist,
        };
        return service;
        function gettrainerlist(InputDetails) {
          
                var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/StatusInquiryApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();