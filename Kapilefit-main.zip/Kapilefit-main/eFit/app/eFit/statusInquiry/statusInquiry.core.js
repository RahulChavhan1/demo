﻿(function () {
    'use strict';

    angular.module('statusInquiry.core', [
        'statusInquiry.traineeList',
        'statusInquiry.trainerList',
    ]);
})();
