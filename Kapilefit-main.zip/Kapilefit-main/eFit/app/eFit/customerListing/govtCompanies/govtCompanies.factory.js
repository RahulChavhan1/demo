﻿(function () {
    'use strict';
    angular
        .module('customerListing.govtCompanies', [])
        .factory('govtcompaniesService', govtcompaniesService)
    govtcompaniesService.$inject = ['$http', '$q', '$timeout', 'config'];
    function govtcompaniesService($http, $q, $timeout, config) {
        var service = {
            getgovtCompanies: getgovtCompanies,
            getTrainerList: getTrainerList,
            getTraineesList: getTraineesList,
            getDisName: getDisName,
            Logout: Logout,
        };
        return service;

        function getgovtCompanies(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetgovtCompanies',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTrainerList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetTrainersList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTraineesList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetTraineesList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getDisName(Id) {

            var deferred = $q.defer();

            $http({
                method: 'Get', url: config.baseURL + 'api/CustomerListingApi/GetDisName/' + Id
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();