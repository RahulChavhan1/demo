﻿(function () {
    'use strict';

    angular.module('customerListing.govtCompanies', [

    ]);
})();