﻿(function () {
    'use strict';

    angular
        .module('customerListing.core')
        .controller('CustomerListingCtrl', CustomerListingCtrl);

    CustomerListingCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function CustomerListingCtrl($state, $stateParams, $q, $rootScope) {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'Customer Listing Shell';
        $rootScope.showMenu = true;
        vm.CustomerListingDetails = {};
        activate();


        function activate() {

            //$state.transitionTo('client.details', { clientID: '2' }, { notify: true });
            
        }

    }

})();
