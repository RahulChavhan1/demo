﻿(function () {
    'use strict';

    angular
        .module('customerListing.privateCompanies')
        .controller('PrivateCompaniesListCtrl', PrivateCompaniesListCtrl)

    PrivateCompaniesListCtrl.$inject = ['$state', '$q', 'PrivatecompaniesService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config', '$rootScope'];

    function PrivateCompaniesListCtrl($state, $q, PrivatecompaniesService, logger, $timeout, $filter, $stateParams, $scope, config, $rootScope) {

        // Variable Declaration
        var vm = this;
        vm.title = 'Private Companies Details Ctrl';
        vm.PrivateCompaniesDetails = {};
        vm.tempDetails = {};
        vm.TrainersDetails = {};
        vm.TraineesDetails = {};
        vm.InputDetails = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "DistributorName";
        vm.InputDetails.sortOrder = true;
        vm.tempIndex = 1;
        vm.showPage = false;
        vm.TPrivateCompanies = false;
        vm.TTrainersList = false;
        vm.TTraineesList = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        vm.title = "";
        vm.showPrivateCompaniesLink = false;
        vm.showTrainersLink = false;
        vm.showTraineesLink = false;
        vm.RecordsPerPageList = [1, 2, 3, 4, 5];
        vm.pageNo = 0;
        vm.companyNameRe = "";
        vm.TrainingDateRef = "";
        vm.navCompanies = false;

        //// Method Declaration
        vm.SearchPrivateCompanies = SearchPrivateCompanies;
        vm.PrivateCompaniestable = PrivateCompaniestable;
        vm.TrainersDetails = TrainersDetails;
        vm.TraineesDetails = TraineesDetails;
        vm.sort = sort;
        vm.ExportToExcel = ExportToExcel;
        $stateParams.companyPriId = $stateParams.companyPriId == "" ? 0 : $stateParams.companyPriId;
        $stateParams.trainerId = $stateParams.trainerId == "" ? null : $stateParams.trainerId;
        vm.setPage = setPage;
        $stateParams.companyNameRe = $stateParams.comName == "" ? null : $stateParams.comName;

        $stateParams.companyTypeName = angular.element('#companyTypeName').val();

        //used For Dis User
        $stateParams.companyID = angular.element('#companyID').val();

        vm.InputDetails.disCompanyName = $stateParams.companyTypeName;

        activate();

        // Method Definition
        function activate() {

            //To Get Private Company Name
            if ($stateParams.companyPriId != null) {
                PrivatecompaniesService.getDisName($stateParams.companyPriId).then(function (data) {
                    if (data != null) {
                        $rootScope.comName = data;
                    }

                });
            }

            //To get Trainees Details
            if ($stateParams.trainerId != null) {
                vm.TTraineesList = !vm.TTraineesList;
                vm.showPrivateCompaniesLink = true;
                vm.showTrainersLink = true;
                vm.showTraineesLink = false;
                vm.priComId = $stateParams.companyPriId;
                vm.trainerId = $stateParams.trainerId;
                vm.companyNameRe = $stateParams.companyNameRe;

                vm.InputDetails.adminId = config.roleTicketId;
                vm.InputDetails.companyId = $stateParams.companyID;
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
                //To get Trainers Details
            else if ($stateParams.companyPriId > 0) {
                vm.TTrainersList = !vm.TTrainersList;
                vm.showPrivateCompaniesLink = true;
                vm.showTrainersLink = false;
                vm.showTraineesLink = false;
                vm.priComId = $stateParams.companyPriId;
                vm.trainerId = $stateParams.trainerId;
                vm.companyNameRe = $stateParams.companyNameRe;

                vm.InputDetails.companyId = $stateParams.companyID;
                vm.InputDetails.adminId = config.roleTicketId;
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                var promises = [getTrainerList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            //To get Private Companies
            else {
                $stateParams.companyTypeId = 2;
                vm.TPrivateCompanies = !vm.TPrivateCompanies;
                vm.priComId = $stateParams.companyPriId;
                vm.trainerId = $stateParams.trainerId;
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        }
        function getPrivateCompaniesList(InputDetails) {
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return PrivatecompaniesService.getPrivateCompanies(InputDetails).then(function (data) {
                vm.PrivateCompaniesDetails = data;
                vm.title = "Private Companies";

                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }

            });
        }
        function getTrainerList(InputDetails) {
            vm.navCompanies = true;
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return PrivatecompaniesService.getTrainerList(InputDetails).then(function (data) {
                if (data[0].access != false) {
                    vm.TrainersDetails = data;
                    vm.title = "Trainers Listing";
                    vm.tempDetails = data;
                    if (data.length > 0) {
                        vm.showPage = true;
                        $scope.totalItems = data[0].TotalRecords;
                    }
                    else {
                        vm.showPage = false;
                        $scope.totalItems = 0;
                    }
                }
                else {
                    LogOut();
                }

            });
        }
        function getTraineesList(InputDetails) {
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return PrivatecompaniesService.getTraineesList(InputDetails).then(function (data) {
                if (data[0].access != false) {
                    vm.TraineesDetails = data;
                    vm.TrainingDateRef = data[0].TrainingDate;
                    vm.title = "Trainees Listing";
                    vm.tempDetails = data;
                    if (data.length > 0) {
                        vm.showPage = true;
                        $scope.totalItems = data[0].TotalRecords;
                    }
                    else {
                        vm.showPage = false;
                        $scope.totalItems = 0;
                    }
                }
                else {
                    LogOut();
                }

            });
        }
        function LogOut()
        {
            PrivatecompaniesService.Logout().then(function (data) {
                if (data == "LogedOut") {
                    window.location = config.baseURL + "Login/index";
                }
            });
        }
        //Searching
        function SearchPrivateCompanies(search) {
            vm.InputDetails.pageIndex = 1;
            vm.PrivateCompaniestable(search)
        }
        function PrivateCompaniestable(search) {
            vm.InputDetails.searchText = search;
            if ($stateParams.trainerId != null) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                setPage(0);
            }
            else if ($stateParams.companyPriId > 0) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                setPage(0);
            }
            else {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                setPage(0);
            }
        }
        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            if ($stateParams.trainerId != null) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else if ($stateParams.companyPriId > 0) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                var promises = [getTrainerList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        }

            // Export To Excel
        function ExportToExcel() {
            if ($stateParams.trainerId != null) {
                window.location.href = config.baseURL + "CustomerListing/ExportTrainees?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&TotalRecords=" + $scope.totalItems + "&companyPriId=" + $stateParams.companyPriId + "&trainerId=" + $stateParams.trainerId + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&disId=" + vm.InputDetails.companyId + "&adminID=" + vm.InputDetails.adminId;
                }
                else if ($stateParams.companyPriId > 0) {
                    window.location.href = config.baseURL + "CustomerListing/ExportTrainers?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&TotalRecords=" + $scope.totalItems + "&companyPriId=" + $stateParams.companyPriId + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&disId=" + vm.InputDetails.companyId + "&adminID=" + vm.InputDetails.adminId;
                }
                else {
                    window.location.href = config.baseURL + "CustomerListing/ExportPrivateCompanies?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems + "&disCompanyName=" + encodeURIComponent(vm.InputDetails.disCompanyName);
                }
            }
           
            //Paging  
            var rangeVal = vm.itemsPerPage;
            vm.range = function () {
                var dataCount = $scope.totalItems;
                var rangeSize;
                if (dataCount > 0 && dataCount <= rangeVal)
                { rangeSize = 1; }
                else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
                { rangeSize = 2; }
                else
                { rangeSize = 3; }
                var ps = [];
                var start;
                start = vm.currentPage;
                if (start > vm.pageCount() - rangeSize) {
                    start = vm.pageCount() - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++) {
                    ps.push(i);
                }
                return ps;
            };
            vm.prevPage = function () {
                var cPage = vm.currentPage;
                if (vm.currentPage > 0) {
                    vm.currentPage--;
                }
                vm.InputDetails.pageSize = vm.itemsPerPage;
                vm.InputDetails.pageIndex = vm.currentPage + 1;
                if (cPage != 0) {
                    if ($stateParams.trainerId != null) {
                        vm.InputDetails.companyPriId = $stateParams.companyPriId;
                        vm.InputDetails.trainerId = $stateParams.trainerId;
                        var promises = [getTraineesList(vm.InputDetails), ];
                        return $q.all(promises).then(function () {
                        });
                    }
                    else if ($stateParams.companyPriId > 0) {
                        vm.InputDetails.companyPriId = $stateParams.companyPriId;
                        var promises = [getTrainerList(vm.InputDetails), ];
                        return $q.all(promises).then(function () {
                        });
                    }
                    else {
                        vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                        var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                        return $q.all(promises).then(function () {
                        });
                    }
                }
            };
            vm.pageCount = function () {
                return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
            };
            vm.nextPage = function () {
                var cPage = vm.currentPage;
                if (vm.currentPage < vm.pageCount()) {
                    vm.currentPage++;
                }
                vm.InputDetails.pageSize = vm.itemsPerPage;
                vm.InputDetails.pageIndex = cPage + 2;
                if (cPage != vm.pageCount()) {
                    if ($stateParams.trainerId != null) {
                        vm.InputDetails.companyPriId = $stateParams.companyPriId;
                        vm.InputDetails.trainerId = $stateParams.trainerId;
                        var promises = [getTraineesList(vm.InputDetails), ];
                        return $q.all(promises).then(function () {
                        });
                    }
                    else if ($stateParams.companyPriId > 0) {
                        vm.InputDetails.companyPriId = $stateParams.companyPriId;
                        var promises = [getTrainerList(InputDetails), ];
                        return $q.all(promises).then(function () {
                        });
                    }
                    else {
                        vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                        var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                        return $q.all(promises).then(function () {
                        });
                    }
                }
            };
            function setPage(n) {
                vm.currentPage = n;
                vm.InputDetails.pageSize = vm.itemsPerPage;
                vm.InputDetails.pageIndex = n + 1;
                if ($stateParams.trainerId != null) {
                    vm.InputDetails.companyPriId = $stateParams.companyPriId;
                    vm.InputDetails.trainerId = $stateParams.trainerId;
                    var promises = [getTraineesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if ($stateParams.companyPriId > 0) {
                    vm.InputDetails.companyPriId = $stateParams.companyPriId;
                    var promises = [getTrainerList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                    var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            };
            vm.DisablePrevPage = function () {
                return vm.currentPage === 0 ? "disabled" : "";
            };
            vm.DisableNextPage = function () {
                return vm.currentPage === vm.pageCount() ? "disabled" : "";
            };
            
            //To get Grid Details
            function TrainersDetails(CompanyID, CompanyName) {
                $state.transitionTo('efitmenu.PrivateCompaniesCompanyPriId', { companyPriId: CompanyID }, { notify: true });
                $rootScope.comName = CompanyName;

            };

            function TraineesDetails(priComId, companyNameRe, RefNo) {
                $state.transitionTo('efitmenu.PrivateCompaniesTrainerId', { companyPriId: vm.priComId, comName: vm.companyNameRe, trainerId: RefNo }, { notify: true });
            };
            
            $scope.sortInfo = { fields: [''], directions: [''] };
            $scope.PrivateGrid = {
                data: 'vm.PrivateCompaniesDetails',
                enableColumnResize: true,
                sortInfo: $scope.sortInfo,
                enableSorting: true,
                showFilter: false,
                enablePaging: false,
                useExternalSorting: true,
                keepLastSelected: true,
                showColumnMenu: false,
                columnDefs: [
                     {
                         cellTemplate: '<div class="link3"><a ng-click="vm.TrainersDetails(row.entity.CompanyID,row.entity.CompanyName)">{{row.getProperty(\'CompanyName\')}}</a>',
                         field: 'CompanyName', displayName: 'Company Name', width: '20%'
                     },
                { field: 'DistributorName', displayName: 'Distributor Name', width: '20%' },
                { field: 'Address', displayName: 'Address', width: '20%' },
                { field: 'PostalCode', displayName: 'Postal Code', width: '20%' },
                { field: 'ContactPerson', displayName: 'Contact Person', width: '20%' },
                { field: 'ContactDesignation', displayName: 'Designation', width: '20%' },
                { field: 'ContactNumber', displayName: 'Contact No', width: '20%' },
                 ]
            };
            $scope.$watch('PrivateGrid.ngGrid.config.sortInfo', function () {
                if ($scope.sortInfo.fields[0] == "CompanyName") {
                    if ($scope.sortInfo.directions[0] == "asc")
                    { vm.descending = true; }
                    else
                    { vm.descending = false; }
                    sort("DistributorName")
                    //if ($stateParams.companyTypeName != "")
                    //{ sort("CompanyName"); }
                    //else
                    //{sort("DistributorName");}
                    
                }
                else if($scope.sortInfo.fields[0] == "ContactDesignation")
                {
                    if ($scope.sortInfo.directions[0] == "asc")
                    { vm.descending = true; }
                    else
                    { vm.descending = false; }
                    sort("Designation");
                }
                else if ($scope.sortInfo.fields[0] == "ContactNumber")
                {
                    if ($scope.sortInfo.directions[0] == "asc")
                    { vm.descending = true; }
                    else
                    { vm.descending = false; }
                    sort("ContactNo");
                }
                else if ($scope.sortInfo.fields[0] == "DistributorName") {
                    if ($scope.sortInfo.directions[0] == "asc")
                    { vm.descending = true; }
                    else
                    { vm.descending = false; }
                    sort("DistributorNames");
                    //if ($stateParams.companyTypeName != "") { sort("DistributorName"); }
                    //else { sort("DistributorNames"); }
                    
                }
                else if ($scope.sortInfo.fields[0] == "") {
                }
                else
                {
                    if ($scope.sortInfo.directions[0] == "asc")
                    { vm.descending = true; }
                    else
                    { vm.descending = false; }
                    sort($scope.sortInfo.fields[0]);
                }
                
            }, true);
            $(window).resize(function () {
            });
            
            $scope.sortInfoT = { fields: [''], directions: [''] };
            $scope.TrainerGrid = {
                data: 'vm.TrainersDetails',
                enableColumnResize: true,
                sortInfo: $scope.sortInfoT,
                enableSorting: true,
                showFilter: false,
                enablePaging: false,
                useExternalSorting: true,
                keepLastSelected: true,
                showColumnMenu: false,
                columnDefs: [
                     {
                         cellTemplate: '<div class="link3"><a ng-click="vm.TraineesDetails(vm.priComId,vm.companyNameRe,row.entity.RefNo)">{{row.getProperty(\'TrainingDate\')}}</a>',
                         field: 'TrainingDate', displayName: 'Training Date', width: '20%'
                     },
                {
                    field: 'counting', displayName: 'No.Of Trainees', width: '20%',
                    cellTemplate: '<div style="text-align:center;" class="ngCellText">{{row.getProperty(col.field)}}</div>'
                },
                { field: 'TrainingType', displayName: 'Training Type', width: '20%' },
                { field: 'TrainerCompany', displayName: 'Trainer Company', width: '20%' },
                { field: 'TopicsCovered', displayName: 'Topics Covered', width: '20%' },
                { field: 'TrainingCompany', displayName: 'Training Company', width: '20%' },
                 { field: 'TrainerName', displayName: 'Trainer Name', width: '20%' }, ]
            };
            $scope.$watch('TrainerGrid.ngGrid.config.sortInfo', function () {
                if ($scope.sortInfoT.directions[0] == "asc")
                { vm.descending = true; }
                else
                { vm.descending = false; }
                sort($scope.sortInfoT.fields[0]);
            }, true);

            $(window).resize(function () {
            });

            $scope.sortInfoTr = { fields: [''], directions: [''] };
            $scope.TraineeGrid = {
                data: 'vm.TraineesDetails',
                enableColumnResize: true,
                sortInfo: $scope.sortInfoTr,
                enableSorting: true,
                showFilter: false,
                enablePaging: false,
                useExternalSorting: true,
                keepLastSelected: true,
                showColumnMenu: false,
                columnDefs: [
                { field: 'TraineeName', displayName: 'Trainee Name', width: '20%' },
                { field: 'Designation', displayName: 'Designation', width: '20%' },
                { field: 'Dept', displayName: 'Dept', width: '20%' },
                { field: 'IC', displayName: 'ID No.', width: '20%' },
                { field: 'Model', displayName: 'Model', width: '20%' },
                { field: 'Outcome', displayName: 'Outcome', width: '20%' }, ]
            };
            $scope.$watch('TraineeGrid.ngGrid.config.sortInfo', function () {
                if ($scope.sortInfoTr.directions[0] == "asc")
                { vm.descending = true; }
                else
                { vm.descending = false; }
                sort($scope.sortInfoTr.fields[0]);
            }, true);

            $(window).resize(function () {
            });
    }
})();
