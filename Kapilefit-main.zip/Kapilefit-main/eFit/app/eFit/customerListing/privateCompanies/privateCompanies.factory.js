﻿(function () {
    'use strict';
    angular
        .module('customerListing.privateCompanies', [])
        .factory('PrivatecompaniesService', PrivatecompaniesService)
    PrivatecompaniesService.$inject = ['$http', '$q', '$timeout', 'config'];
    function PrivatecompaniesService($http, $q, $timeout, config) {
        var service = {
            getPrivateCompanies: getPrivateCompanies,
            getTrainerList: getTrainerList,
            getTraineesList: getTraineesList,
            getDisName: getDisName,
            Logout: Logout,
        };
        return service;

        function getPrivateCompanies(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetPrivateCompanies',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTrainerList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetTrainersList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTraineesList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetTraineesList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getDisName(Id) {

            var deferred = $q.defer();

            $http({
                method: 'Get', url: config.baseURL + 'api/CustomerListingApi/GetDisName/' + Id
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();