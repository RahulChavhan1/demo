﻿(function () {
    'use strict';

    angular.module('customerListing.distributors', [

    ]);
})();