﻿(function () {
    'use strict';
    angular
        .module('customerListing.distributors', [])
        .factory('distributorsService', distributorsService)
    distributorsService.$inject = ['$http', '$q', '$timeout', 'config'];
    function distributorsService($http, $q, $timeout, config) {
        var service = {
            getdistributors: getdistributors,
            getPrivateCompanies: getPrivateCompanies,
            getTrainerList: getTrainerList,
            getTraineesList: getTraineesList,
            getRoleId:getRoleId,
            getDisName: getDisName,
            Logout: Logout,
            
        };
        return service;

        function getdistributors(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetDistributors',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getPrivateCompanies(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetDisPrivateCompanies',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTrainerList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetTrainersList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getTraineesList(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CustomerListingApi/GetTraineesList',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getDisName(Id) {

            var deferred = $q.defer();

            $http({
                method: 'Get', url: config.baseURL + 'api/CustomerListingApi/GetDisName/' + Id
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        function getRoleId(Id) {

            var deferred = $q.defer();

            $http({
                method: 'Get', url: config.baseURL + 'api/CustomerListingApi/GetRoleId/' + Id
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();