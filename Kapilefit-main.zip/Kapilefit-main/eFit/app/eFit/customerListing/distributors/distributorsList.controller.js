﻿(function () {
    'use strict';
    angular
        .module('customerListing.distributors')
        .controller('DistributorsListCtrl', DistributorsListCtrl)
    DistributorsListCtrl.$inject = ['$state', '$q', 'distributorsService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config', '$rootScope'];

    function DistributorsListCtrl($state, $q, distributorsService, logger, $timeout, $filter, $stateParams, $scope, config, $rootScope) {

        // Variable Declaration       
        var vm = this;
        vm.title = 'Distributors Details Ctrl';
        vm.DistributorsDetails = {};
        vm.PrivateCompaniesDetails = {};
        vm.TrainersDetails = {};
        vm.TraineesDetails = {};
        vm.InputDetails = {};
        vm.tempDetails = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.tempIndex = 1;
        vm.showPage = false;
        vm.TDistributors = false;
        vm.TPrivateCompanies = false;
        vm.TTrainersList = false;
        vm.TTraineesList = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.currentPage = 0;
        vm.title = "";
        vm.navCompanies = false;
        vm.navTrainers = false;
        vm.showDistributorLink = false;
        vm.showPrivateCompaniesLink = false;
        vm.showTrainersLink = false;
        vm.showTraineesLink = false;
        vm.disNameRe = "";
        vm.companyNameRe = "";
        vm.TrainingDateRef = "";
        vm.RecordsPerPageList = [1, 2, 3];
        vm.pageNo = 0;
       
        // Method Declaration
        vm.SearchDistributors = SearchDistributors;
        vm.distributorstable = distributorstable;
        vm.sort = sort;
        vm.ExportToExcel = ExportToExcel;
        vm.PrivateCompaniesDetails = PrivateCompaniesDetails;
        vm.TrainersDetails = TrainersDetails;
        vm.TraineesDetails = TraineesDetails;

        vm.OnchangeRecoredsperpage = OnchangeRecoredsperpage;
        $stateParams.companyId = $stateParams.companyId == "" ? 0 : $stateParams.companyId;
        $stateParams.companyPriId = $stateParams.companyPriId == "" ? 0 : $stateParams.companyPriId;
        $stateParams.trainerId = $stateParams.trainerId == "" ? null : $stateParams.trainerId;
        $stateParams.disNameRe = $stateParams.disName == "" ? null : $stateParams.disName;
        $stateParams.companyNameRe = $stateParams.comName == "" ? null : $stateParams.comName;
        vm.setPage = setPage;

        //Role Authentication
            activate();
       
        // Method Definition
        function activate() {
           
            //To Get Dis Name
            if ($stateParams.companyId != null) {
                distributorsService.getDisName($stateParams.companyId).then(function (data) {
                    if (data != null) {
                        $rootScope.disName = data;
                    }

                });
            }

            //To Get Private Company Name
            if ($stateParams.companyPriId != null) {
                distributorsService.getDisName($stateParams.companyPriId).then(function (data) {
                    if (data != null) {
                        $rootScope.comName = data;
                    }

                });
            }


            //To get Trainees Details
            if ($stateParams.trainerId != null) {
                vm.TTraineesList = !vm.TTraineesList;
                vm.showDistributorLink = true;
                vm.showPrivateCompaniesLink = true;
                vm.showTrainersLink = true;
                vm.showTraineesLink = false;
                vm.disNameRe = $stateParams.disNameRe;
                vm.companyNameRe = $stateParams.companyNameRe;
                vm.disId = $stateParams.companyId;
                vm.priComId = $stateParams.companyPriId;
                vm.trainerId = $stateParams.trainerId;

                vm.InputDetails.adminId = config.roleTicketId;
                vm.InputDetails.companyId = $stateParams.companyId;

                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }

            //To get Trainers Details
            else if ($stateParams.companyPriId > 0) {
                //alert($stateParams.companyId);
                vm.TTrainersList = !vm.TTrainersList;
                vm.showDistributorLink = true;
                vm.showPrivateCompaniesLink = true;
                vm.showTrainersLink = false;
                vm.showTraineesLink = false;
                vm.disId = $stateParams.companyId;
                vm.priComId = $stateParams.companyPriId;
                vm.trainerId = $stateParams.trainerId;
                vm.disNameRe = $stateParams.disNameRe;
                vm.companyNameRe = $stateParams.companyNameRe;
                vm.InputDetails.adminId = config.roleTicketId;
                vm.InputDetails.companyId = $stateParams.companyId;
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                var promises = [getTrainerList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }

            //To get private companies
            else if ($stateParams.companyId > 0)
            {
                vm.TPrivateCompanies = !vm.TPrivateCompanies;
                vm.showDistributorLink = true;
                vm.showPrivateCompaniesLink = false;
                vm.showTrainersLink = false;
                vm.showTraineesLink = false;
                vm.disId = $stateParams.companyId;
                vm.priComId = $stateParams.companyPriId;
                vm.trainerId = $stateParams.trainerId;
                vm.disNameRe = $stateParams.disNameRe;
                vm.companyNameRe = $stateParams.companyNameRe;
               
                vm.InputDetails.companyId = $stateParams.companyId;
                var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else
            {
                $stateParams.companyTypeId = 3;
                vm.TDistributors = !vm.TDistributors;
                vm.disId = $stateParams.companyId;
                vm.priComId = $stateParams.companyPriId;
                vm.trainerId = $stateParams.trainerId;
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getdistributorsList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        }

        function getdistributorsList(InputDetails) {
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return distributorsService.getdistributors(InputDetails).then(function (data) {
                vm.DistributorsDetails = data;
                vm.title = "Distributors";
                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }
            });
        }

        function getPrivateCompaniesList(InputDetails) {
            vm.navCompanies = true;
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return distributorsService.getPrivateCompanies(InputDetails).then(function (data) {
                vm.PrivateCompaniesDetails = data;
                vm.title = "Private Companies";
                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }
            });
        }

        function getTrainerList(InputDetails) {
            vm.navTrainers = true;
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return distributorsService.getTrainerList(InputDetails).then(function (data) {
                if (data[0].access != false) {
                    vm.TrainersDetails = data;
                    vm.title = "Trainers Listing";
                    vm.tempDetails = data;
                    if (data.length > 0) {
                        vm.showPage = true;
                        $scope.totalItems = data[0].TotalRecords;
                    }
                    else {
                        vm.showPage = false;
                        $scope.totalItems = 0;
                    }
                }
                else {
                    LogOut();
                }
            });
        }

        function getTraineesList(InputDetails) {
            if (vm.InputDetails.searchText == "")
            { vm.InputDetails.searchText = null }
            return distributorsService.getTraineesList(InputDetails).then(function (data) {
                if (data[0].access != false) {
                    vm.TraineesDetails = data;
                    vm.TrainingDateRef = data[0].TrainingDate;
                    vm.title = "Trainees Listing";
                    vm.tempDetails = data;
                    if (data.length > 0) {
                        vm.showPage = true;
                        $scope.totalItems = data[0].TotalRecords;
                    }
                    else {
                        vm.showPage = false;
                        $scope.totalItems = 0;
                    }
                }
                else {
                    LogOut();
                }
            });
        }

        function LogOut() {
            distributorsService.Logout().then(function (data) {
                if (data == "LogedOut") {
                    window.location = config.baseURL + "Login/index";
                }
            });
        }
        //Searching
        function SearchDistributors(search) {
            vm.InputDetails.pageIndex = 1;
            vm.distributorstable(search)
        }
        function distributorstable(search) {
            vm.InputDetails.searchText = search;
            if ($stateParams.trainerId != null)
            {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                setPage(0);
            }
            else if ($stateParams.companyPriId > 0)
            {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                setPage(0);
            }
            else if ($stateParams.companyId > 0) {
                vm.InputDetails.companyId = $stateParams.companyId;
                setPage(0);
            }
            else {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                setPage(0);
            }
        }
        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            if ($stateParams.trainerId != null) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else if ($stateParams.companyPriId > 0) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                var promises = [getTrainerList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else if ($stateParams.companyId > 0) {
                vm.InputDetails.companyId = $stateParams.companyId;
                var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getdistributorsList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };

        // Export To Excel
        function ExportToExcel() {
            var tCount = 0;
            if ($stateParams.trainerId != null) {
                window.location.href = config.baseURL + "CustomerListing/ExportTrainees?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&TotalRecords=" + $scope.totalItems + "&companyPriId=" + $stateParams.companyPriId + "&trainerId=" + $stateParams.trainerId + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&disId=" + vm.InputDetails.companyId + "&adminID=" + vm.InputDetails.adminId;
            }
            else if ($stateParams.companyPriId > 0) {
                window.location.href = config.baseURL + "CustomerListing/ExportTrainers?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&TotalRecords=" + $scope.totalItems + "&companyPriId=" + $stateParams.companyPriId + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&disId=" + vm.InputDetails.companyId + "&adminID=" + vm.InputDetails.adminId;
            }
            else if ($stateParams.companyId > 0) {
                window.location.href = config.baseURL + "CustomerListing/ExportCompanies?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&TotalRecords=" + $scope.totalItems + "&companyId=" + $stateParams.companyId + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder;
            }
            else {
                if ($scope.totalItems < 50) {
                    tCount = 50;
                }
                else {
                    tCount = $scope.totalItems;
                }

                window.location.href = config.baseURL + "CustomerListing/ExportDistributors?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + tCount;
            }
        }

        function OnchangeRecoredsperpage(Records) {
            vm.pageSize = Records;
            vm.itemsPerPage = Records;
            rangeVal = vm.itemsPerPage;
            vm.PageNo = 0;
            vm.pageIndex = 1;
            getdistributorsList();
            setPage(vm.PageNo)
        }

        //Paging     
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }

            var ps = [];
            var start;

            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }

            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {

            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;

            if (cPage != 0) {
                if ($stateParams.trainerId != null) {
                    vm.InputDetails.companyPriId = $stateParams.companyPriId;
                    vm.InputDetails.trainerId = $stateParams.trainerId;
                    var promises = [getTraineesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if ($stateParams.companyPriId > 0) {
                    vm.InputDetails.companyPriId = $stateParams.companyPriId;
                    var promises = [getTrainerList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if ($stateParams.companyId > 0) {
                    vm.InputDetails.companyId = $stateParams.companyId;
                    var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                    var promises = [getdistributorsList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;

            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;
            if (cPage != vm.pageCount()) {
                if ($stateParams.trainerId != null) {
                    vm.InputDetails.companyPriId = $stateParams.companyPriId;
                    vm.InputDetails.trainerId = $stateParams.trainerId;
                    var promises = [getTraineesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if ($stateParams.companyPriId > 0) {
                    vm.InputDetails.companyPriId = $stateParams.companyPriId;
                    var promises = [getTrainerList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else if ($stateParams.companyId > 0) {
                    vm.InputDetails.companyId = $stateParams.companyId;
                    var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
                else {
                    vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                    var promises = [getdistributorsList(vm.InputDetails), ];
                    return $q.all(promises).then(function () {
                    });
                }
            }
        };
        function setPage(n) {
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;
            if ($stateParams.trainerId != null) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                vm.InputDetails.trainerId = $stateParams.trainerId;
                var promises = [getTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else if ($stateParams.companyPriId > 0) {
                vm.InputDetails.companyPriId = $stateParams.companyPriId;
                var promises = [getTrainerList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else if ($stateParams.companyId > 0) {
                vm.InputDetails.companyId = $stateParams.companyId;
                var promises = [getPrivateCompaniesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
            else {
                vm.InputDetails.companyTypeId = $stateParams.companyTypeId;
                var promises = [getdistributorsList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };

        //To get Grid Details
        function PrivateCompaniesDetails(CompanyID, CompanyName) {
            $state.transitionTo('efitmenu.DistributorsCompId', { companyId: CompanyID }, { notify: true });
            $rootScope.disName = CompanyName;
        };

        function TrainersDetails(disId, disNameRe, CompanyID, CompanyName) {
            $state.transitionTo('efitmenu.DistributorsCompPriId', { companyId: disId, companyPriId: CompanyID }, { notify: true });
            $rootScope.comName = CompanyName;
        };

        function TraineesDetails(disId, priComId, disNameRe, companyNameRe, RefNo) {
            $state.transitionTo('efitmenu.DistributorsTrainerId', { companyId: vm.disId, companyPriId: vm.priComId, disName: vm.disNameRe, comName: vm.companyNameRe, trainerId: RefNo }, { notify: true });
            
        };

        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.DistributorGrid = {
            data: 'vm.DistributorsDetails',
            enableColumnResize: true,
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            columnDefs: [
                {
                    cellTemplate: '<div class="link3"><a ng-click="vm.PrivateCompaniesDetails(row.entity.CompanyID,row.entity.CompanyName)">{{row.getProperty(\'CompanyName\')}}</a></div>',
                    field: 'CompanyName', displayName: 'Distributor Name', width: '20%'
                },
            { field: 'Address', displayName: 'Address', width: '20%' },
            { field: 'PostalCode', displayName: 'Postal Code', width: '20%' },
            { field: 'ContactPerson', displayName: 'Contact Person', width: '20%' },
             { field: 'ContactDesignation', displayName: 'Designation', width: '20%' },
              { field: 'ContactNumber', displayName: 'Contact No', width: '20%' }, ]
        };

        $scope.$watch('DistributorGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }

            if ($scope.sortInfo.fields[0] == "CompanyName") {
                sort("DistributorName");
            }
            else if($scope.sortInfo.fields[0] == "ContactDesignation") {
                sort("Designation");
            }
            else if ($scope.sortInfo.fields[0] == "ContactNumber") {
                sort("ContactNo");
            }
            else if ($scope.sortInfo.fields[0] == "") {
            }
            else {
                sort($scope.sortInfo.fields[0]);
            }
        }, true);
        $(window).resize(function () {
        });

        $scope.sortInfoP = { fields: [''], directions: [''] };
        $scope.PrivateGrid = {
            data: 'vm.PrivateCompaniesDetails',
            enableColumnResize: true,
            sortInfo: $scope.sortInfoP,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            columnDefs: [
                 {
                     cellTemplate: '<div class="link3"><a ng-click="vm.TrainersDetails(vm.disId,vm.disNameRe,row.entity.CompanyID,row.entity.CompanyName)">{{row.getProperty(\'CompanyName\')}}</a></div>',
                     field: 'CompanyName', displayName: 'Company Name', width: '20%'
                 },
            { field: 'Address', displayName: 'Address', width: '20%' },
            { field: 'PostalCode', displayName: 'Postal Code', width: '20%' },
            { field: 'ContactPerson', displayName: 'Contact Person', width: '20%' },
             { field: 'ContactDesignation', displayName: 'Designation', width: '20%' },
              { field: 'ContactNumber', displayName: 'Contact No', width: '20%' },
             { field: 'DistributorName', displayName: 'Distributor Name', width: '20%' }, ]
        };

        $scope.$watch('PrivateGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfoP.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            if ($scope.sortInfoP.fields[0] == "ContactDesignation") {
             
                sort("Designation");
            }
            else if ($scope.sortInfoP.fields[0] == "ContactNumber") {
               
                sort("ContactNo");
            }
            else if ($scope.sortInfoP.fields[0] == "DistributorName") {
               
                sort("DistributorNames");
            }
            else if ($scope.sortInfo.fields[0] == "") {
            }
            else {
              
                sort($scope.sortInfoP.fields[0]);
            }
        }, true);
        $(window).resize(function () {
        });

        $scope.sortInfoT = { fields: [''], directions: [''] };
        $scope.TrainerGrid = {
            data: 'vm.TrainersDetails',
            enableColumnResize: true,
            sortInfo: $scope.sortInfoT,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            columnDefs: [
                 {
                     cellTemplate: '<div class="link3"><a ng-click="vm.TraineesDetails(vm.disId,vm.priComId,vm.disNameRe,vm.companyNameRe,row.entity.RefNo)">{{row.getProperty(\'TrainingDate\')}}</a></div>',
                     field: 'TrainingDate', displayName: 'Training Date', width: '20%'
                 },
            {
                field: 'counting', displayName: 'No.Of Trainees', width: '20%',
                cellTemplate: '<div style="text-align:center;" class="ngCellText">{{row.getProperty(col.field)}}</div>'
            },
            { field: 'TrainingType', displayName: 'Training Type', width: '20%' },
            { field: 'TrainerCompany', displayName: 'Trainer Company', width: '20%' },
            { field: 'TopicsCovered', displayName: 'Topics Covered', width: '20%' },
            { field: 'TrainingCompany', displayName: 'Training Company', width: '20%' },
             { field: 'TrainerName', displayName: 'Trainer Name', width: '20%' }, ]
        };

        $scope.$watch('TrainerGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfoT.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            sort($scope.sortInfoT.fields[0]);
        }, true);
        $(window).resize(function () {
        });

        $scope.sortInfoTr = { fields: [''], directions: [''] };
        $scope.TraineeGrid = {
            data: 'vm.TraineesDetails',
            enableColumnResize: true,
            sortInfo: $scope.sortInfoTr,
            enableSorting: true,
            showFilter: false,
            enablePaging: false,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            columnDefs: [
            { field: 'TraineeName', displayName: 'Trainee Name', width: '20%' },
            { field: 'Designation', displayName: 'Designation', width: '20%' },
            { field: 'Dept', displayName: 'Dept', width: '20%' },
            { field: 'IC', displayName: 'ID No.', width: '20%' },
            { field: 'Model', displayName: 'Model', width: '20%' },
            { field: 'Outcome', displayName: 'Outcome', width: '20%' }, ]
        };

        $scope.$watch('TraineeGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfoTr.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            sort($scope.sortInfoTr.fields[0]);
        }, true);
        $(window).resize(function () {
        });

    }
})();
