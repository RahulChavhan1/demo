﻿(function () {
    'use strict';

    angular.module('customerListing.core', [
        'customerListing.distributors',
        'customerListing.govtCompanies',
        'customerListing.privateCompanies'
    ]);
})();
