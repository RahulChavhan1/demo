﻿(function () {
    'use strict';

    angular
        .module('app.eFit')
        .controller('EfitCtrl', EfitCtrl);

    EfitCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function EfitCtrl($state, $stateParams, $q, $rootScope) {

        //variable Declaration
        var vm = this;
        vm.title = 'EFit Listing Shell';
        $rootScope.showMenu = true;
        vm.EFitDetails = {};

        //Menthod Declaration
        activate();

        //Method Definition
        function activate() {
        }
    }
})();
