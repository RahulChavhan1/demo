﻿(function () {
    'use strict';

    angular.module('certifiedTrainees.core', [
        'certifiedTrainees.activeTrainees',
        'certifiedTrainees.dueOfRenewalTrainees',
        'certifiedTrainees.expiredTrainees'
    ]);
})();
