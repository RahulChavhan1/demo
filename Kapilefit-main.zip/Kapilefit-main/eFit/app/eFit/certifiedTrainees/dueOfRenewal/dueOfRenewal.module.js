﻿(function () {
    'use strict';

    angular.module('certifiedTrainees.dueOfRenewalTrainees', [

    ]);
})();