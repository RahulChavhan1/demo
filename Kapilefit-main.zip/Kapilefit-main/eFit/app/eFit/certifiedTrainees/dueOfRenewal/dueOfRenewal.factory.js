﻿(function () {
    'use strict';
    angular
        .module('certifiedTrainees.dueOfRenewalTrainees', [])
        .factory('dueofrenewaltraineesService', dueofrenewaltraineesService)

    dueofrenewaltraineesService.$inject = ['$http', '$q', '$timeout', 'config'];
    function dueofrenewaltraineesService($http, $q, $timeout, config) {
        var service = {
            getdueOfRenewalTrainees: getdueOfRenewalTrainees,
            getDistributorCompaniesList : getDistributorCompaniesList,
            getCompaniesList: getCompaniesList,
        };
        return service;

        function getCompaniesList(companyTypeId, traTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', cache: false, url: config.baseURL + 'api/CertifiedTraineesApi/GetCertifiedCompanyName/' + companyTypeId + '/' + traTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getdueOfRenewalTrainees(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CertifiedTraineesApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getDistributorCompaniesList(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                cache: false,
                url: config.baseURL + 'api/CertifiedTraineesApi/GetDistributorCompaniesList',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();