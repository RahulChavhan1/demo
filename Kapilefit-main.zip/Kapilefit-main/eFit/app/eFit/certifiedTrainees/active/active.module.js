﻿(function () {
    'use strict';

    angular.module('certifiedTrainees.activeTrainees', [
        'autocomplete'
    ]);
})();