﻿(function () {
    'use strict';

    angular
        .module('certifiedTrainees.activeTrainees')

        .controller('ActiveTraineesListCtrl', ActiveTraineesListCtrl)

    ActiveTraineesListCtrl.$inject = ['$state', '$q', 'activetraineesService', 'logger', '$timeout', '$filter', '$stateParams', '$scope', 'config'];

    function ActiveTraineesListCtrl($state, $q, activetraineesService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration      
        var vm = this;
        vm.title = 'Active Trainees Details Ctrl';
        vm.ActiveTraineesDetails = {};
        $scope.CompanyDropdownList = [];
        $scope.CompanyDropdownListDis = [];
        vm.tempDetails = {};
        vm.InputDetails = {};
        vm.CompanyDts = {};
        $scope.selectedIDs = [];
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 1;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.traineeType = 1;
        vm.showPage = false;
        vm.showPageContent = true;
        vm.exitShow = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.InputDetails.companyTypeID = 0;
        vm.currentPage = 0;
        vm.showPrint = false;
        vm.WaitMsg = "1";

        // Method Declaration
        vm.SearchActiveTrainees = SearchActiveTrainees;
        vm.activeTraineestable = activeTraineestable;
        vm.sort = sort;
        vm.LoadActiveTraineesDetails = LoadActiveTraineesDetails;
        vm.ExportToExcel = ExportToExcel;
        vm.checkAll = CheckAll;
        vm.PrintCertificate = PrintCertificate;
        vm.Exit = exit;
        vm.checkSingle = checkSingle;
        activate();
        vm.setPage = setPage;

        // Method Definition
        function activate() {
            $stateParams.companyTypeId = 3;
            $stateParams.companyTypeID = angular.element('#companyTypeId').val();

            $stateParams.disCompanyName = angular.element('#dis_company_name').val();
            
            //Private and Govt Companies Users
            if ($stateParams.disCompanyName != "" && $stateParams.companyTypeID != 3) {
                vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
                LoadActiveTraineesDetails($stateParams.disCompanyName)
            }

            //Distributors Users
            if ($stateParams.companyTypeID == 3) {
                vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
                vm.InputDetails.companyName = angular.element('#company_name').val();
                vm.InputDetails.disCompanyName = angular.element('#dis_company_name').val();
                //vm.InputDetails.companyName = angular.element('#dis_company_name').val();
                vm.CompanyDts.CompanyName = $stateParams.disCompanyName;
                vm.CompanyDts.tID = 1;
                vm.CompanyDts.disID = 2;
                return activetraineesService.getDistributorCompaniesList(vm.CompanyDts).then(function (data) {
                    $scope.CompanyDropdownListDis = data.companyName;
                });
            }

            //Admin
            else {
                return activetraineesService.getCompaniesList($stateParams.companyTypeID, 1).then(function (data) {
                    $scope.CompanyDropdownList = data.companyName;
                });
            }
        }
        function LoadActiveTraineesDetails(CompanyName) {
            $stateParams.companyName = angular.element('#company_name').val();
            $stateParams.trainingDate = vm.trainingDate;
            vm.InputDetails.companyName = angular.element('#company_name').val();
            vm.InputDetails.disCompanyName = angular.element('#dis_company_name').val();
            vm.InputDetails.trainingDate = vm.trainingDate;
            vm.InputDetails.searchText = vm.searchText;
            setPage(0);
        }
        function getActiveTraineesList(InputDetails) {
                        return activetraineesService.getactiveTrainees(InputDetails).then(function (data) {
                            vm.ActiveTraineesDetails = data;
                            vm.tempDetails = data;
                            if (data.length > 0) {
                                vm.showPage = true;
                                $scope.totalItems = data[0].TotalRecords;
                                $scope.totalItemsTemp = data[0].TotalRecords;
                            }
                            else {
                                vm.showPage = false;
                                $scope.totalItems = 0;
                            }
                        });
                    }
           
        //Searching
        function SearchActiveTrainees(search) {
            vm.InputDetails.pageIndex = 1;
            vm.activeTraineestable(search)
        }
        function activeTraineestable(search) {
            vm.InputDetails.searchText = search;
            vm.InputDetails.companyName = angular.element('#company_name').val();
            var promises = [getActiveTraineesList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }
        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            var promises = [getActiveTraineesList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        // Export To Excel
        function ExportToExcel(CompanyName, searchText, sortColumn, sortOrder) {
            //if ($stateParams.companyTypeID == 3) {
            //    CompanyName = angular.element('#dis_company_name').val();
            //}

            window.location.href = config.baseURL + "CertifiedTrainees/ExportCertifiedActiveTrainees?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&CompanyName=" + encodeURIComponent(vm.InputDetails.companyName) + "&CompanyTypeId=" + vm.InputDetails.companyTypeID + "&TrainingDate=" + vm.InputDetails.trainingDate + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems + "&disName=" + encodeURIComponent(vm.InputDetails.disCompanyName);
        }

        //CheckBox Selection
        function checkSingle() {
            vm.showPrint = false;
                angular.forEach(vm.ActiveTraineesDetails, function (item) {
                    if (item.Selected) {                        
                        vm.showPrint = true;
                    }
                });
            }
        function CheckAll() {
            if (vm.selectedAll)
            {
                vm.selectedAll = true;
                vm.showPrint = true;
            }
            else
            {
                vm.selectedAll = false;
                vm.showPrint = false;
            }
            angular.forEach(vm.ActiveTraineesDetails, function (item) {
                item.Selected = vm.selectedAll;
            });
        }
        //Certificate Print
        function PrintCertificate() {
            vm.check = [];
            var uncheck = [];
            vm.WaitMsg = "1";
            document.getElementById('loader').style.display = 'block';
            angular.forEach($scope.selectedIDs, function (item) {
                    vm.check.push({ RefNo: item.RefNo + "|" + item.TraineeName + "|" + item.CompanyName + "|" + item.IC + "|" + item.TrainingDate + "|" + item.Model });
            });

            $scope.totalItems = vm.check.length;

            return activetraineesService.SaveprintCerData(vm.check).then(function (data) {
                if (data.success == true) {
                    $("#PrintPreview iframe").attr("src", config.baseURL + "CertifiedTrainees/PrintByAppendTrainees?GuidId=" + data.id);
                    vm.showPageContent = false;
                    vm.exitShow = true;
                }
            });
        }

        //Load text while certificate generation
        $(document).ready(function () {
            $('#iframe').on('load', function () {
                if (vm.WaitMsg == 1) {
                    document.getElementById('loader').style.display = 'none';
                }

            });
        });

        function exit() {
            $scope.totalItems = $scope.totalItemsTemp;
            $scope.ActiveGrid.selectAll(false);
            vm.WaitMsg = "2";
            vm.showPageContent = true;
            vm.exitShow = false;
            document.getElementById('loader').style.display = 'block';
            $("#PrintPreview iframe").attr("src", 'about:blank');
        }

        //Paging
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }
            var ps = [];
            var start;
            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }
            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;

            if (cPage != 0) {
                var promises = [getActiveTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;
            if (cPage != vm.pageCount()) {
                var promises = [getActiveTraineesList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        function setPage(n) {
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;
            var promises = [getActiveTraineesList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };

        //ng- Grid Options
        $scope.mySelections = [];
        $scope.selectedIDs = [];
        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.ActiveGrid = {
            data: 'vm.ActiveTraineesDetails',
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            enableColumnResize: true,
            showSelectionCheckbox: true,
            selectedItems: $scope.mySelections,
            multiSelect: true,
            afterSelectionChange: function () {
                $scope.selectedIDs = [];
                angular.forEach($scope.mySelections, function (item) {
                    $scope.selectedIDs.push(item)
                });
                if ($scope.selectedIDs.length > 0) {
                    vm.showPrint = true;
                }
                else {
                    vm.showPrint = false;
                }
            },
            columnDefs: [
            { field: 'TrainingDate', displayName: 'Training Date', width: '12%' },
            { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
            {
                cellTemplate: '<div style="text-align:center;" class="ngCellText">1</div>',
                displayName: 'No Of Years', width: '12%'
            },
            { field: 'TraineeName', displayName: 'Trainee Name', width: '15%' },
            { field: 'Designation', displayName: 'Designation', width: '15%' },
            { field: 'Dept', displayName: 'Dept', width: '15%' },
            { field: 'IC', displayName: 'ID No.', width: '8%' },
            { field: 'Model', displayName: 'Model', width: '8%' },
            { field: 'ContactPerson', displayName: 'Contact Person', width: '15%' },
            { field: 'ContactNo', displayName: 'Contact No', width: '15%' },
            { field: 'TrainerName', displayName: 'Trainer Name', width: '15%' },
             ]
        };
        $scope.$watch('ActiveGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            if ($scope.sortInfo.fields[0] == "") {
            }
            else {
                sort($scope.sortInfo.fields[0]);
            }
        }, true);

        $(window).resize(function () {
        });
    }
})();
