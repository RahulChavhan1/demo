﻿(function () {
    'use strict';   
    angular
        .module('certifiedTrainees.expiredTrainees', [])
        .factory('expiredtraineesService', expiredtraineesService)

    expiredtraineesService.$inject = ['$http', '$q', '$timeout', 'config'];

    function expiredtraineesService($http, $q, $timeout, config) {
        var service = {
            getexpiredTrainees: getexpiredTrainees,
            getDistributorCompaniesList: getDistributorCompaniesList,
            getCompaniesList: getCompaniesList,
        };
        return service;

        function getCompaniesList(companyTypeId, traTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', cache: false, url: config.baseURL + 'api/CertifiedTraineesApi/GetCertifiedCompanyName/' + companyTypeId + '/' + traTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getexpiredTrainees(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                cache: false,
                url: config.baseURL + 'api/CertifiedTraineesApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getDistributorCompaniesList(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                cache: false,
                url: config.baseURL + 'api/CertifiedTraineesApi/GetDistributorCompaniesList',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();