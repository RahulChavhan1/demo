﻿(function () {
    'use strict';

    angular
        .module('certifiedTrainees.core')
        .controller('certifiedTraineesCtrl', certifiedTraineesCtrl);

    certifiedTraineesCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function certifiedTraineesCtrl($state, $stateParams, $q, $rootScope) {
        
        //variable Declaration
        var vm = this;
        vm.title = 'Certified Trainees Shell';
        $rootScope.showMenu = true;
        vm.CertifiedTraineesDetails = {};

        //Menthod Declaration
        activate();

        //Method Definition
        function activate() {
        }
    }
})();
