﻿(function () {
    'use strict';

    angular.module('certifiedTrainers.dueOfRenewalTrainers', [

    ]);
})();