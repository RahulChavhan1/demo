﻿(function () {
    'use strict';
    angular
        .module('certifiedTrainers.dueOfRenewalTrainers', [])
        .factory('dueofrenewalTrainersService', dueofrenewalTrainersService)

    dueofrenewalTrainersService.$inject = ['$http', '$q', '$timeout', 'config'];

    function dueofrenewalTrainersService($http, $q, $timeout, config) {
        var service = {
            getdueofrenewalTrainers: getdueofrenewalTrainers,
            getDistributorCompaniesList: getDistributorCompaniesList,
            getCompaniesList: getCompaniesList,
            printCerData: printCerData,
            Logout: Logout,
        };
        return service;
        function getCompaniesList(companyTypeId, traTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/CertifiedTrainersApi/GetTrainerCompanyName/' + companyTypeId + '/' + traTypeId, data: {
                    id: companyTypeId
                }
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getdueofrenewalTrainers(InputDetails) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CertifiedTrainersApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function printCerData(checkedData) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'PrintCertificate/PrintActiveTrainer/',
                data: JSON.stringify(checkedData),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getDistributorCompaniesList(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CertifiedTraineesApi/GetDistributorCompaniesList',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();