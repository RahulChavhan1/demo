﻿(function () {
    'use strict';

    angular
        .module('certifiedTrainers.core')
        .controller('certifiedTrainersCtrl', certifiedTrainersCtrl);

    certifiedTrainersCtrl.$inject = ['$state', '$stateParams', '$q', '$rootScope'];

    function certifiedTrainersCtrl($state, $stateParams, $q, $rootScope) {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'Certified Trainers Shell';
        $rootScope.showMenu = true;
        vm.CertifiedTrainersDetails = {};
        activate();


        function activate() {

            //$state.transitionTo('client.details', { clientID: '2' }, { notify: true });

        }

    }

})();
