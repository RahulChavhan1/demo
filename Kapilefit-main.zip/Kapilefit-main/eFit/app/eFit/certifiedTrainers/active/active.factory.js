﻿(function () {
    'use strict';
    angular
        .module('certifiedTrainers.activeTrainers', [])
        .factory('activeTrainersService', activeTrainersService)

    activeTrainersService.$inject = ['$http', '$q', '$timeout', 'config'];

    function activeTrainersService($http, $q, $timeout, config) {
        var service = {
            getactiveTrainers: getactiveTrainers,
            getDistributorCompaniesList: getDistributorCompaniesList,
            getCompaniesList: getCompaniesList,
            SaveprintCerData: SaveprintCerData,
            Logout: Logout,
        };
        return service;

        function getCompaniesList(companyTypeId, traTypeId) {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/CertifiedTrainersApi/GetTrainerCompanyName/' + companyTypeId + '/' + traTypeId, data: {
                    id: companyTypeId
                }
        }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getactiveTrainers(InputDetails) {
        var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CertifiedTrainersApi/',
                data: JSON.stringify(InputDetails),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function SaveprintCerData(checkedData) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/PrintCertificateApi/',
                data: JSON.stringify({ refNo: checkedData }),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function getDistributorCompaniesList(CompanyDts) {
            var deferred = $q.defer();
            $http({
                method: 'Post',
                url: config.baseURL + 'api/CertifiedTraineesApi/GetDistributorCompaniesList',
                data: JSON.stringify(CompanyDts),
                contentType: "application/json"
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/Login/LogOff/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();