﻿(function () {
    'use strict';

    angular.module('certifiedTrainers.activeTrainers', [

    ]);
})();