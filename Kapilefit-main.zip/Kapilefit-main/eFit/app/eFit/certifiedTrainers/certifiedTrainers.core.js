﻿(function () {
    'use strict';

    angular.module('certifiedTrainers.core', [
        'certifiedTrainers.activeTrainers',
        'certifiedTrainers.dueOfRenewalTrainers',
        'certifiedTrainers.expiredTrainers'
    ]);
})();
