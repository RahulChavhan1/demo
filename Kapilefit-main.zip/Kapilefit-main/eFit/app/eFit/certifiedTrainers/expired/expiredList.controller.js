﻿(function () {
    'use strict';

    angular
        .module('certifiedTrainers.expiredTrainers')

        .controller('ExpiredTrainersListCtrl', ExpiredTrainersListCtrl)

    ExpiredTrainersListCtrl.$inject = ['$state', '$q', 'expiredTrainersService', 'logger', '$timeout', '$filter', '$stateParams','$scope', 'config'];

    function ExpiredTrainersListCtrl($state, $q, expiredTrainersService, logger, $timeout, $filter, $stateParams, $scope, config) {

        // Variable Declaration
        var vm = this;
        vm.title = 'Expired Trainers Details Ctrl';
        vm.ExpiredTrainersDetails = {};
        $scope.CompanyDropdownList = [];
        vm.tempDetails = {};
        vm.InputDetails = {};
        vm.CompanyDts = {};
        vm.InputDetails.searchText = null;
        vm.InputDetails.pageSize = 50;
        vm.InputDetails.pageIndex = 0;
        vm.InputDetails.sortColumn = "CompanyName";
        vm.InputDetails.sortOrder = true;
        vm.InputDetails.traineeType = 3;
        vm.showPage = false;
        vm.itemsPerPage = vm.InputDetails.pageSize;
        vm.InputDetails.companyTypeID = 0;
        vm.currentPage = 0;


        // Method Declaration
        vm.SearchexpiredTrainers = SearchexpiredTrainers;
        vm.expiredTrainerstable = expiredTrainerstable;
        vm.sort = sort;
        vm.LoadexpiredTrainersDetails = LoadexpiredTrainersDetails;
        vm.ExportToExcel = ExportToExcel;
        vm.setPage = setPage;
        //activate();

        activate();

        // Method Definition
        function activate() {
            $stateParams.companyTypeId = 1;
            $stateParams.disCompanyName = angular.element('#dis_company_name').val();
            $stateParams.companyTypeID = angular.element('#companyTypeId').val();

            if ($stateParams.disCompanyName != "" && $stateParams.companyTypeID != 3) {
                vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
                LoadexpiredTrainersDetails($stateParams.disCompanyName)
            }

            if ($stateParams.companyTypeID == 3) {
                vm.InputDetails.companyTypeID = $stateParams.companyTypeID;
                vm.InputDetails.companyName = angular.element('#company_name').val();
                vm.InputDetails.disCompanyName = angular.element('#dis_company_name').val();
                vm.CompanyDts.CompanyName = $stateParams.disCompanyName;
                vm.CompanyDts.tID = 3;
                vm.CompanyDts.disID = 1;
                return expiredTrainersService.getDistributorCompaniesList(vm.CompanyDts).then(function (data) {
                    $scope.CompanyDropdownListDis = data.companyName;
                });
            }
            else {
                return expiredTrainersService.getCompaniesList($stateParams.companyTypeId,3).then(function (data) {
                    $scope.CompanyDropdownList = data.companyName;
                });
            }
        }
        function LoadexpiredTrainersDetails(CompanyName) {
            $stateParams.companyName = CompanyName;
            $stateParams.traineeType = 1;
            vm.InputDetails.companyName = angular.element('#company_name').val();
            vm.InputDetails.disCompanyName = angular.element('#dis_company_name').val();
            vm.InputDetails.trainingDate = vm.trainingDate;
            vm.InputDetails.searchText = vm.searchText;
            setPage(0);
        }
        function getexpiredTrainersList(InputDetails) {
            return expiredTrainersService.getexpiredTrainers(vm.InputDetails).then(function (data) {
                vm.ExpiredTrainersDetails = data;
                vm.tempDetails = data;
                if (data.length > 0) {
                    vm.showPage = true;
                    $scope.totalItems = data[0].TotalRecords;
                }
                else {
                    vm.showPage = false;
                    $scope.totalItems = 0;
                }
            });
                    }
        function LogOut() {
            expiredTrainersService.Logout().then(function (data) {
                if (data == "LogedOut") {
                    window.location = config.baseURL + "Login/index";
                }
            });
        }
        //Searching
        function SearchexpiredTrainers(search) {
            vm.InputDetails.pageIndex = 1;
            vm.expiredTrainerstable(search)
        }
        function expiredTrainerstable(search) {
            vm.InputDetails.searchText = search;
            vm.InputDetails.companyName = angular.element('#company_name').val();
            var promises = [getexpiredTrainersList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        }

        //Sorting
        function sort(newSortField) {
            if (vm.sortField == newSortField)
            vm.sortField = newSortField;
            vm.InputDetails.sortOrder = vm.descending;
            vm.InputDetails.sortColumn = newSortField;
            $('th i').each(function () {
                $(this).removeClass().addClass();  // reset sort icon for columns with existing icons
            });
            var promises = [getexpiredTrainersList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };

        // Export To Excel
        function ExportToExcel(CompanyName, searchText, sortColumn, sortOrder) {
            window.location.href = config.baseURL + "CertifiedTrainers/ExportCertifiedExpiredTrainers?searchText=" + encodeURIComponent(vm.InputDetails.searchText) + "&CompanyName=" + encodeURIComponent(vm.InputDetails.companyName) + "&CompanyTypeId=" + vm.InputDetails.companyTypeID + "&TrainingDate=" + vm.InputDetails.trainingDate + "&sortColumn=" + vm.InputDetails.sortColumn + "&sortOrder=" + vm.InputDetails.sortOrder + "&TotalRecords=" + $scope.totalItems+ "&disName=" + encodeURIComponent(vm.InputDetails.disCompanyName);
        } 
        
        //Paging
        var rangeVal = vm.itemsPerPage;
        vm.range = function () {
            var dataCount = $scope.totalItems;
            var rangeSize;
            if (dataCount > 0 && dataCount <= rangeVal)
            { rangeSize = 1; }
            else if (dataCount > rangeVal && dataCount <= rangeVal + rangeVal)
            { rangeSize = 2; }
            else
            { rangeSize = 3; }
            var ps = [];
            var start;
            start = vm.currentPage;
            if (start > vm.pageCount() - rangeSize) {
                start = vm.pageCount() - rangeSize + 1;
            }
            for (var i = start; i < start + rangeSize; i++) {
                ps.push(i);
            }
            return ps;
        };
        vm.prevPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage > 0) {
                vm.currentPage--;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = vm.currentPage + 1;
            if (cPage != 0) {
                var promises = [getexpiredTrainersList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisablePrevPage = function () {
            return vm.currentPage === 0 ? "disabled" : "";
        };
        vm.pageCount = function () {
            return Math.ceil($scope.totalItems / vm.itemsPerPage) - 1;
        };
        vm.nextPage = function () {
            var cPage = vm.currentPage;
            if (vm.currentPage < vm.pageCount()) {
                vm.currentPage++;
            }
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = cPage + 2;
            if (cPage != vm.pageCount()) {
                var promises = [getexpiredTrainersList(vm.InputDetails), ];
                return $q.all(promises).then(function () {
                });
            }
        };
        vm.DisableNextPage = function () {
            return vm.currentPage === vm.pageCount() ? "disabled" : "";
        };
        function setPage(n) {
            vm.currentPage = n;
            vm.InputDetails.pageSize = vm.itemsPerPage;
            vm.InputDetails.pageIndex = n + 1;
            var promises = [getexpiredTrainersList(vm.InputDetails), ];
            return $q.all(promises).then(function () {
            });
        };
        
        //To get Grid Details
        $scope.sortInfo = { fields: [''], directions: [''] };
        $scope.ExpiredGrid = {
            data: 'vm.ExpiredTrainersDetails',
            sortInfo: $scope.sortInfo,
            enableSorting: true,
            useExternalSorting: true,
            keepLastSelected: true,
            showColumnMenu: false,
            enableColumnResize: true,
            columnDefs: [
            { field: 'TrainingDate', displayName: 'Training Date', width: '12%' },
            { field: 'CompanyName', displayName: 'Company Name', width: '20%' },
             { field: 'TraineeName', displayName: 'Certified Trainer', width: '15%' },
            {
                cellTemplate: '<div style="text-align:center;" class="ngCellText">1</div>',
                displayName: 'No Of Years', width: '12%'
            },
            { field: 'TrainerName', displayName: '3M Trainer', width: '15%' },
            { field: 'Designation', displayName: 'Designation', width: '15%' },
            { field: 'Dept', displayName: 'Dept', width: '15%' },
            { field: 'IC', displayName: 'ID No.', width: '8%' },
            { field: 'Model', displayName: 'Model', width: '8%' },
            { field: 'ContactPerson', displayName: 'Contact Person', width: '15%' },
            { field: 'ContactNo', displayName: 'Contact No', width: '15%' },
           
              ]
        };
        $scope.$watch('ExpiredGrid.ngGrid.config.sortInfo', function () {
            if ($scope.sortInfo.directions[0] == "asc")
            { vm.descending = true; }
            else
            { vm.descending = false; }
            if ($scope.sortInfo.fields[0] == "") {
            }
            else {
                sort($scope.sortInfo.fields[0]);
            }
        }, true);
        $(window).resize(function () {
        });
    }
})();
