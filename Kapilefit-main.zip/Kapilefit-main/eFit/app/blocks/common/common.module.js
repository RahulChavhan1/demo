﻿(function () {
   
    'use strict';

    angular.module('blocks.common.directive', []);
})();