﻿(function () {
    'use strict';

    angular.module('blocks.common.directive', [])
        .directive('autoComplete', function ($timeout) {
            return {
                scope: true,

                link: function (scope, iElement, iAttrs) {
                    scope.check = function () {
                        iElement.autocomplete({
                            source: scope[iAttrs.uiItems],
                            minLength: 0,
                            select: function () {
                                $timeout(function () {
                                    if (iAttrs.id == "company_name") {
                                    }
                                    else if (iAttrs.id == "company_name_Load") {

                                        scope.vm.LoadCompanyDetails();
                                        scope.vm.UploadDetails.CompanyName = angular.element('#company_name_Load').val();
                                    }
                                    else if (iAttrs.id == "inputCompanyName") {

                                        scope.vm.UserSaveDetails.CompanyName = angular.element('#inputCompanyName').val();
                                    }
                                    else if (iAttrs.id == "inputNameofTraining") {
                                        scope.vm.GetTrainerName();
                                        scope.vm.UploadDetails.TrainerCompanyName = angular.element('#inputNameofTraining').val();
                                    }
                                    else if (iAttrs.id == "TrainerName") {
                                        scope.vm.UploadDetails.TrainerName = angular.element('#TrainerName').val();
                                    }                                  
                                    return false;
                                }, 0);
                            }
                        });                            

                        var pl = $timeout(scope.check, 0);
                       
                    }

                    scope.check();

                }
            }
          
        });

})();


