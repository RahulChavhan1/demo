﻿
(function () {
    'use strict';

    angular
        .module('psUpload', [])
        .directive('psUpload', psUpload);

    psUpload.$inject = ['$parse'];

    function psUpload($parse) {
        var directive = {
            link: link,
            restrict: 'A'
        };
        return directive;

        function link(scope, element, attrs) {
            var options = {};
            scope.uploadFlag = false;
            if (attrs.hasOwnProperty("targetFrame")) {
                options.targetiFrame = attrs['targetFrame'];
            }
            else {
                options.targetiFrame = "upload_iframe";
            }

            if (attrs['psUpload']) {
                element.attr("target", options.targetiFrame);
                element.attr("method", "post");

                // Append a timestamp field to the url to prevent browser caching results
                element.attr("action", element.attr("action") + "?_t=" + new Date().getTime());
                element.attr("enctype", "multipart/form-data");
                element.attr("encoding", "multipart/form-data");


                var fn = attrs['psUpload'].split('(')[0];
                var callbackFn = scope.$eval(fn);
                if (callbackFn == null || callbackFn == undefined || !angular.isFunction(callbackFn)) {
                    var message = "The expression on the psUpload directive does not point to a valid functio at ps-upload attribute";
                    throw message + "\n";
                }



                var addNewDisposableIframe = function () {
                    // create a new iframe
                    var iframe = $("<iframe id='" + options.targetiFrame + "' name='" + options.targetiFrame + "'border='0' width='0' height='0' style='width: 0px; height: 0px; border: none; display: none' />");

                    // attach function to load event of the iframe
                    iframe.bind('load', function () {

                        // get content - requires jQuery
                        var content = iframe.contents().find('body').text();

                        // execute the upload response function in the active scope
                        scope.$apply(function () {
                            callbackFn(content, content !== "" /* upload completed */);
                            scope.uploadFlag = false;
                        });

                        // remove iframe
                        if (content != "") // Fixes a bug in Google Chrome that dispose the iframe before content is ready.
                        {
                            setTimeout(function () {
                                iframe.remove();

                            }, 250);


                        }


                    });

                    // add the new iframe to application
                    element.parent().append(iframe);
                };


                angular.element('.upload-submit', element).click(
                     function () {

                         addNewDisposableIframe();
                         scope.$apply(function () {
                             callbackFn("Please wait...", false /* upload not completed */);
                             scope.uploadFlag = true;
                         });

                         angular.element(element).submit();
                     }
                 )

            }
            else {
                console.log("No callback function found on the psUpload directive.");
            }
        }
    }

    angular
       .module('psUpload')
    .directive('validateFile', ValidateFile);

    function ValidateFile() {
        var directive = {
            require: 'ngModel',
            link: link

        };
        return directive;

        function link(scope, element, attrs, ngModel) {
            var fun = attrs['fileSelect'].split('(')[0];
            var callback = scope.$eval(fun);
            if (callback == null || callback == undefined || !angular.isFunction(callback)) {
                var message = "The expression on the ValidateFile directive does not point to a valid function  file-select attribute";
                throw message + "\n";
            }
            ngModel.$render = function () {
                ngModel.$setViewValue(element.val());
            };

            element.bind('change', function (e) {
                scope.$apply(function () {
                    callback(e);
                    ngModel.$render();
                });
            });

        }
    }

    angular
     .module('psUpload')
    .directive('psSubmit', function () {
        return {
            link: function (scope, elm, attrs) {
                scope.$on(attrs.psSubmit, function () {
                    setTimeout(function () {
                        //elm.trigger('click');
                        elm.click();
                    });
                });
            }
        };
    })
    .directive('psKeyEnter', function () {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    scope.$apply(function () {
                        scope.$eval(attrs.psKeyEnter, { 'event': event });
                    });

                    event.preventDefault();
                }
            });
        };
    });
})();