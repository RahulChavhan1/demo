﻿(function () {
  
    'use strict';
     angular
        .module('blocks.common.directive')
        .directive('psValidationMessage', validationMessage)
        .directive('psValidationTooltip', validationTooltip)
 
     function validationMessage() {
        
        return {
            restrict: 'A',
            priority: 1000,
            replace: true,
            require: '^psValidationTooltip',
            link: function (scope, element, attr, ctrl, transcludeFn) {
                ctrl.$addExpression(attr.ngIf || true);
            }
        }
    }
   
    validationTooltip.$inject = ['$timeout']
    function validationTooltip($timeout) {
  
         return {
            restrict: 'E',
            transclude: true,
            require: '^form',
            replace: true,
            scope: {},
            template: '<div>  <span class="label-err" style="cursor:pointer" ng-show="errorCount > 0"></span></div>',
            controller: function ($scope) {
                var expressions = [];
                $scope.errorCount = 0;

                this.$addExpression = function (expr) {
                    expressions.push(expr);
                }
                $scope.$watch(function () {
                    var count = 0;
                    angular.forEach(expressions, function (expr) {
                        if ($scope.$eval(expr)) {
                            ++count;
                        }
                    });
                    return count;

                }, function (newVal) {
                    $scope.errorCount = newVal;
                });

            },
            link: function (scope, element, attr, formController, transcludeFn) {
                scope.$form = formController;
                transcludeFn(scope, function (clone) {
                    var badge = element.find('.label-err');
                    var tooltip = angular.element('<div class="validationMessageTemplate tooltip-danger" />');
                    tooltip.append(clone);
                    element.append(tooltip);
                    $timeout(function () {

                        scope.$field = formController[attr.target];
                        badge.tooltip({
                            placement: attr.position == undefined || attr.position == null ? 'left' : attr.position,
                            html: true,
                            title: clone
                        });

                    });
                });

            }

        }
    }

})();
