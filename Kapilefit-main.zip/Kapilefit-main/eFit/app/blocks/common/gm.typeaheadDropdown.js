﻿

(function () {
    'use strict';
    angular
       .module('blocks.common.directive')

  .directive('typeaheadDropdown', function () {
      return {
          templateUrl: 'templates/typeaheadDropdown.tpl.html',
          scope: {
              model: '=ngModel',
              getOptions: '&options',
              config: '=?',
              required: '=?ngRequired'
          },
          replace: true,
          controller: ['$scope', '$q', function ($scope, $q) {
              $scope.config = angular.extend({
                  modelLabel: "name",
                  optionLabel: "name"
              }, $scope.config);

              $q.when($scope.getOptions())
              .then(function (options) {
                  $scope.options = options;
              });

              $scope.onSelect = function ($item, $model, $label) {
                  angular.extend($scope.model, $item);
                  $scope.model[$scope.config.modelLabel] = $item[$scope.config.optionLabel];
              }
          }]
      }
  })

})();