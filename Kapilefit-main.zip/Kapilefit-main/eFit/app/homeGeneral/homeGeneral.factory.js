﻿(function () {
    'use strict';

    angular
        .module('app.homeGeneral')
       .factory('homeGeneralService', homeGeneralService);
    homeGeneralService.$inject = ['$http', '$q', 'config'];
    function homeGeneralService($http, $q, config) {
        var service = {
            getHitCount: getHitCount,
            getQuickLinksDetail: getQuickLinksDetail
        };
        return service;
        function getHitCount()
        {
            var deferred = $q.defer();

            $http({
                method: 'Get',url: config.baseURL + 'api/LoginApi/getHitCountTotal'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }

        function getQuickLinksDetail(flag) {

            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'api/HomeAPI/' + flag
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
     
    }
})();