﻿(function () {
    'use strict';

    angular
        .module('app.homeGeneral')
        .controller('homeGeneralShellCtrl', homeGeneralShellCtrl)


    homeGeneralShellCtrl.$inject = ['$state', '$q','$scope', 'homeGeneralService', '$rootScope', 'config'];

    function homeGeneralShellCtrl($state, $q, $scope, homeGeneralService, $rootScope, config) {

        //variable Declaration
        var vm = this;
        vm.getHitCount = {};
        vm.QuickLinksList = {};
        //Menthod Declaration
       
        activate();

        //Method Definition
        function activate() {
            var promises = [getHitCount(), getQuickLinksDetail()];
            return $q.all(promises).then(function () { });

        }
        function getHitCount()
        {
            return homeGeneralService.getHitCount().then(function (data) {
                vm.getHitCount = data;
            });
        }

        function getQuickLinksDetail() {
            return homeGeneralService.getQuickLinksDetail(2).then(function (data) {
                vm.QuickLinksList = data;
            });

           // vm.QuickLinksList.Name = 2;
        }

       
       
    }

})();
