﻿(function () {
    'use strict';

    angular
        .module('app.homemenu')
        .controller('homemenuShellCtrl', homemenuShellCtrl)


    homemenuShellCtrl.$inject = ['$state', '$q', '$scope', '$rootScope'];

    function homemenuShellCtrl($state, $q, $scope, $rootScope) {
        var vm = this;       
        vm.ParentModule = {};
        activate();
        function activate() {
           
            //$state.transitionTo('homemenu.General');
        }
    }
})();
