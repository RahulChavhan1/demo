﻿(function () {
    'use strict';
    
    angular
        .module('app.home')
        .controller('homeShellCtrl', homeShellCtrl)
       
   
    homeShellCtrl.$inject = ['$state', '$q', '$scope', 'mySharedService', '$rootScope','config'];
   
    function homeShellCtrl($state, $q, $scope, mySharedService, $rootScope, config) {

        //variable Declaration
        var vm = this;       
        vm.ParentModule = {};

        //Menthod Declaration
        vm.exportmasterfile = exportmasterfile;
        vm.Logout = Logout
        activate();

        //Method Definition
        function activate()
        {
            mySharedService.getRoleId(1).then(function (data) {
                if (data != null) {
                    config.roleTicketId = data;
                }
            });
            $state.transitionTo('homemenu');
        }
        function exportmasterfile() {
            var url = '..'+ config.baseURL +'DownloadForm/eFitForm.xls';
            window.open(url, 'Download');
        }
        function Logout() {
            mySharedService.Logout().then(function (data) {
                if (data.Message == "LogedOut") {
                    window.location = "https://wslqa.mmm.com/logout/securityLogout?urlstring=http://sgohesp-qa.lapa.mmm.com/eFitPS";
                }
            });
        }

        function getParameterByName(name) {
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(location.search);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }
    }
   
})();
