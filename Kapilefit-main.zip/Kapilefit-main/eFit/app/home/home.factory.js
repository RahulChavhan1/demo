﻿(function () {
    'use strict';

    angular
        .module('app.home')
       .factory('mySharedService', mySharedService);
    mySharedService.$inject = ['$http', '$q', 'config'];
    function mySharedService($http, $q, config) {
        var service = {
            GetParentModule: GetParentModule,
            Logout: Logout,
            getRoleId: getRoleId
        };
        return service;
        function GetParentModule() {
            var deferred = $q.defer();
            $http({
                method: 'Get',cache:false, url: '/api/MenuAPI/'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
        function Logout() {
            var deferred = $q.defer();
            $http({
                method: 'Get', url: config.baseURL + 'Login/LogOut?id=' + 1,
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }


        function getRoleId(Id) {

            var deferred = $q.defer();

            $http({
                method: 'Get', cache: false, url: config.baseURL + 'CustomerListing/GetRoleId'
            }).success(deferred.resolve).error(deferred.reject);
            return deferred.promise;
        }
    }
})();