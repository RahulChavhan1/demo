﻿using System.Linq;
using System.IO;
using System.Data;
using System;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using OHES.eFit.Data.Utility;
namespace OHES.eFit.OpenXML
{
    public class Excel
    {

        /// <summary>
        /// Creates the workbook
        /// </summary>
        /// <returns>Spreadsheet created</returns>
        public static DocumentFormat.OpenXml.Packaging.SpreadsheetDocument CreateWorkbook(MemoryStream fileName)
        {
            DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = null;
            DocumentFormat.OpenXml.Packaging.SharedStringTablePart sharedStringTablePart;
            DocumentFormat.OpenXml.Packaging.WorkbookStylesPart workbookStylesPart;
            System.Threading.Thread.CurrentThread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("da-DK");
            try
            {
                // Create the Excel workbook
                spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Create(fileName, DocumentFormat.OpenXml.SpreadsheetDocumentType.Workbook, false);

                // Create the parts and the corresponding objects

                // Workbook
                spreadSheet.AddWorkbookPart();
                spreadSheet.WorkbookPart.Workbook = new DocumentFormat.OpenXml.Spreadsheet.Workbook();
                spreadSheet.WorkbookPart.Workbook.Save();

                // Shared string table
                sharedStringTablePart = spreadSheet.WorkbookPart.AddNewPart<DocumentFormat.OpenXml.Packaging.SharedStringTablePart>();
                sharedStringTablePart.SharedStringTable = new DocumentFormat.OpenXml.Spreadsheet.SharedStringTable();
                sharedStringTablePart.SharedStringTable.Save();

                // Sheets collection
                spreadSheet.WorkbookPart.Workbook.Sheets = new DocumentFormat.OpenXml.Spreadsheet.Sheets();
                spreadSheet.WorkbookPart.Workbook.Save();

                // Stylesheet
                workbookStylesPart = spreadSheet.WorkbookPart.AddNewPart<DocumentFormat.OpenXml.Packaging.WorkbookStylesPart>();
                workbookStylesPart.Stylesheet = new DocumentFormat.OpenXml.Spreadsheet.Stylesheet();
                workbookStylesPart.Stylesheet.Save();
            }
            catch (System.Exception ex)
            {
                Utility.LogException(ex);
                // System.Windows.MessageBox.Show(exception.Message, "Excel OpenXML basics", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Hand);
            }


            return spreadSheet;
        }

        /// <summary>
        /// Adds a new worksheet to the workbook
        /// </summary>
        /// <param name="spreadsheet">Spreadsheet to use</param>
        /// <param name="name">Name of the worksheet</param>
        /// <returns>True if succesful</returns>
        public static bool AddWorksheet(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, string name)
        {
            DocumentFormat.OpenXml.Spreadsheet.Sheets sheets = spreadsheet.WorkbookPart.Workbook.GetFirstChild<DocumentFormat.OpenXml.Spreadsheet.Sheets>();
            DocumentFormat.OpenXml.Spreadsheet.Sheet sheet;
            DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart;

            // Add the worksheetpart
            worksheetPart = spreadsheet.WorkbookPart.AddNewPart<DocumentFormat.OpenXml.Packaging.WorksheetPart>();
            worksheetPart.Worksheet = new DocumentFormat.OpenXml.Spreadsheet.Worksheet(new DocumentFormat.OpenXml.Spreadsheet.SheetData());
            worksheetPart.Worksheet.Save();

            // Add the sheet and make relation to workbook
            sheet = new DocumentFormat.OpenXml.Spreadsheet.Sheet()
            {
                Id = spreadsheet.WorkbookPart.GetIdOfPart(worksheetPart),
                SheetId = (uint)(spreadsheet.WorkbookPart.Workbook.Sheets.Count() + 1),
                Name = name
            };
            sheets.Append(sheet);
            spreadsheet.WorkbookPart.Workbook.Save();

            return true;
        }

        public static bool AddBasicStyles(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet)
        {
            DocumentFormat.OpenXml.Spreadsheet.Stylesheet ss = spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet;

            Fonts fts = new Fonts();
            DocumentFormat.OpenXml.Spreadsheet.Font ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            FontName ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            FontSize ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(11);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            fts.Append(ft);

            //Font colour white with bold
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(11);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            ft.Bold = new Bold();
            ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "FFFFFFFF" } };
            fts.Append(ft);

            //Font colour black with bold
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(11);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            ft.Bold = new Bold();
            ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "000000" } };
            fts.Append(ft);

            //Font colour red with bold
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(11);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "FF0000" } };
            fts.Append(ft);

            //This font for customer name in report ---5
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(18);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            // ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "000000" } };
            fts.Append(ft);



            fts.Count = UInt32Value.FromUInt32((uint)fts.ChildElements.Count);

            Fills fills = new Fills();
            Fill fill;
            PatternFill patternFill;

            //fill = new Fill();
            //patternFill = new PatternFill();
            //patternFill.PatternType = PatternValues.Solid;
            //fill.PatternFill = patternFill;
            //fills.Append(fill);

            //fill = new Fill();
            //patternFill = new PatternFill();
            //patternFill.PatternType = PatternValues.Gray125;
            //fill.PatternFill = patternFill;
            //fills.Append(fill);

            fill = new Fill();// index 0
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("FFFFFF");
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill(); // index 1
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("FFFFFF");
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill(); // index 2
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("2E6390");  // efit-color
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill(); // index 3
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("000000"); //Azure2
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = HexBinaryValue.FromString("FFFFFF"); //Azure2
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill();// index 4
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("265100"); //green
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill();// index 5
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("C20A24"); //Red
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill();// index 6
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("F2930C"); //orange
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            //fill = new Fill();// index 7
            //patternFill = new PatternFill();
            //patternFill.PatternType = PatternValues.Solid;
            //patternFill.ForegroundColor = new ForegroundColor();
            //patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("FFFFFF"); //Red
            //patternFill.BackgroundColor = new BackgroundColor();
            //patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            //fill.PatternFill = patternFill;
            //fills.Append(fill);

            fills.Count = UInt32Value.FromUInt32((uint)fills.ChildElements.Count);

            Borders borders = new Borders();
            Border border = new Border();
            border.LeftBorder = new LeftBorder();
            border.RightBorder = new RightBorder();
            border.TopBorder = new TopBorder();
            border.BottomBorder = new BottomBorder();
            border.DiagonalBorder = new DiagonalBorder();
            borders.Append(border);

            border = new Border();
            border.LeftBorder = new LeftBorder();
            border.LeftBorder.Style = BorderStyleValues.None;
            border.RightBorder = new RightBorder();
            border.RightBorder.Style = BorderStyleValues.None;
            border.TopBorder = new TopBorder();
            border.TopBorder.Style = BorderStyleValues.Thick;
            border.TopBorder.Color = new Color() { Rgb = new HexBinaryValue() { Value = "666699" } };
            border.BottomBorder = new BottomBorder();
            border.BottomBorder.Style = BorderStyleValues.Double;
            border.BottomBorder.Color = new Color() { Rgb = new HexBinaryValue() { Value = "666699" } };
            border.DiagonalBorder = new DiagonalBorder();
            borders.Append(border);
            borders.Count = UInt32Value.FromUInt32((uint)borders.ChildElements.Count);

            CellStyleFormats csfs = new CellStyleFormats();
            CellFormat cf = new CellFormat();
            cf.NumberFormatId = 0;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            csfs.Append(cf);
            csfs.Count = UInt32Value.FromUInt32((uint)csfs.ChildElements.Count);

            uint iExcelIndex = 164;
            NumberingFormats nfs = new NumberingFormats();
            CellFormats cfs = new CellFormats();


            NumberingFormat nfDateTime = new NumberingFormat();
            nfDateTime.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            nfDateTime.FormatCode = StringValue.FromString("dd/mm/yyyy hh:mm");
            nfs.Append(nfDateTime);

            //NumberingFormat nf4decimal = new NumberingFormat();
            //nf4decimal.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            //nf4decimal.FormatCode = StringValue.FromString("#,##0.0000");
            //nfs.Append(nf4decimal);

            //// #,##0.00 is also Excel style index 4
            //NumberingFormat nf2decimal = new NumberingFormat();
            //nf2decimal.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            //nf2decimal.FormatCode = StringValue.FromString("#,##0.00");
            //nfs.Append(nf2decimal);

            // @ is also Excel style index 49
            NumberingFormat nfForcedText = new NumberingFormat();
            nfForcedText.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            nfForcedText.FormatCode = StringValue.FromString("@");
            nfs.Append(nfForcedText);

            //date only
            NumberingFormat nfDate = new NumberingFormat();
            nfDate.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            nfDate.FormatCode = StringValue.FromString("dd/mm/yyyy");
            nfs.Append(nfDate);

            //// #,0 rounded integer value
            //NumberingFormat nf0decimal = new NumberingFormat();
            //nf0decimal.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            //nf0decimal.FormatCode = StringValue.FromString("#,0");
            //nfs.Append(nf0decimal);

            //style index 0
            cf = new CellFormat();
            cf.NumberFormatId = 0;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cfs.Append(cf);


            //style index 1
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 2
            cf = new CellFormat();
            //   cf.NumberFormatId = nf2decimal.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 3
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 4
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 5
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center };
            cf.FontId = 1;
            cf.FillId = 2;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 6            
            cf = new CellFormat();
            //cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 5;
            // cf.FillId = 3;
            //cf.BorderId = 0;
            //cf.FormatId = 0;
            //cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center };
            //cf.Alignment = new Alignment() { Vertical = VerticalAlignmentValues.Center };
            cf.ApplyAlignment = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 7            
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 2;
            cf.FillId = 4;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 8            
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 2;
            cf.BorderId = 1;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 9
            // Date format column
            cf = new CellFormat();
            cf.NumberFormatId = nfDateTime.NumberFormatId;
            // cf.NumberFormatId = nfDate.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 10
            // decimal value with color and right alignment
            cf = new CellFormat();
            //   cf.NumberFormatId = nf2decimal.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 2;
            cf.BorderId = 1;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 11
            // text with color and right alignment
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 2;
            cf.BorderId = 1;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //index 12
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 2;
            // cf.FillId = 3;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            // cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center };
            cf.Alignment = new Alignment() { Vertical = VerticalAlignmentValues.Center };
            cf.ApplyAlignment = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 13
            // Date format column
            cf = new CellFormat();
            cf.NumberFormatId = nfDate.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //Style index 14 Converted string to decimal values font color red
            cf = new CellFormat();
            //   cf.NumberFormatId = nf2decimal.NumberFormatId;
            cf.FontId = 3;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Right };
            cf.ApplyAlignment = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //Style index 15 Converted string to decimal values font color black
            cf = new CellFormat();
            //     cf.NumberFormatId = nf2decimal.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Right };
            cf.ApplyAlignment = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 16 backGround red color           
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 2;
            cf.FillId = 5;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);


            //style index 17 backGround Orange color           
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.FontId = 2;
            cf.FillId = 6;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);


            //style index 18 - rounded integer value with thousand separator
            cf = new CellFormat();
            //     cf.NumberFormatId = nf0decimal.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            // nfs.Count = UInt32Value.FromUInt32((uint)nfs.ChildElements.Count);
            cfs.Count = UInt32Value.FromUInt32((uint)cfs.ChildElements.Count);

            ss.Append(nfs);
            ss.Append(fts);
            ss.Append(fills);
            ss.Append(borders);
            ss.Append(csfs);
            ss.Append(cfs);


            return true;
        }
               
   
        /// <summary>
        /// Add a single string to shared strings table.
        /// Shared string table is created if it doesn't exist.
        /// </summary>
        /// <param name="spreadsheet">Spreadsheet to use</param>
        /// <param name="stringItem">string to add</param>
        /// <param name="save">Save the shared string table</param>
        /// <returns></returns>
        public static bool AddSharedString(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, string stringItem, bool save = true)
        {
            DocumentFormat.OpenXml.Spreadsheet.SharedStringTable sharedStringTable = spreadsheet.WorkbookPart.SharedStringTablePart.SharedStringTable;

            if (0 == sharedStringTable.Where(item => item.InnerText == stringItem).Count())
            {
                sharedStringTable.AppendChild(
                   new DocumentFormat.OpenXml.Spreadsheet.SharedStringItem(
                      new DocumentFormat.OpenXml.Spreadsheet.Text(stringItem)));

                // Save the changes
                if (save)
                {
                    sharedStringTable.Save();
                }
            }

            return true;
        }
        /// <summary>
        /// Returns the index of a shared string.
        /// </summary>
        /// <param name="spreadsheet">Spreadsheet to use</param>
        /// <param name="stringItem">String to search for</param>
        /// <returns>Index of a shared string. -1 if not found</returns>
        public static int IndexOfSharedString(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, string stringItem)
        {
            DocumentFormat.OpenXml.Spreadsheet.SharedStringTable sharedStringTable = spreadsheet.WorkbookPart.SharedStringTablePart.SharedStringTable;
            bool found = false;
            int index = 0;

            foreach (DocumentFormat.OpenXml.Spreadsheet.SharedStringItem sharedString in sharedStringTable.Elements<DocumentFormat.OpenXml.Spreadsheet.SharedStringItem>())
            {
                if (sharedString.InnerText == stringItem)
                {
                    found = true;
                    break; ;
                }
                index++;
            }

            return found ? index : -1;
        }

        /// <summary>
        /// Converts a column number to column name (i.e. A, B, C..., AA, AB...)
        /// </summary>
        /// <param name="columnIndex">Index of the column</param>
        /// <returns>Column name</returns>
        public static string ColumnNameFromIndex(uint columnIndex)
        {
            uint remainder;
            string columnName = "";

            while (columnIndex > 0)
            {
                remainder = (columnIndex - 1) % 26;
                columnName = System.Convert.ToChar(65 + remainder).ToString() + columnName;
                columnIndex = (uint)((columnIndex - remainder) / 26);
            }

            return columnName;
        }

        public static bool SetCellValue_customerName(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet, uint columnIndex, uint rowIndex, string stringValue, bool useSharedString, bool save = true)
        {
            string columnValue = stringValue;
            DocumentFormat.OpenXml.Spreadsheet.CellValues cellValueType;
            DocumentFormat.OpenXml.Spreadsheet.Stylesheet stylesheet = spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet;

            // Add the shared string if necessary
            if (useSharedString)
            {
                if (Excel.IndexOfSharedString(spreadsheet, stringValue) == -1)
                {
                    Excel.AddSharedString(spreadsheet, stringValue, true);
                }
                columnValue = Excel.IndexOfSharedString(spreadsheet, stringValue).ToString();
                cellValueType = DocumentFormat.OpenXml.Spreadsheet.CellValues.SharedString;
            }
            else
            {
                cellValueType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
            }

            return SetCellValue(spreadsheet, worksheet, columnIndex, rowIndex, cellValueType, columnValue, 6, save);
        }


        public static bool SetCellValue(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet, uint columnIndex, uint rowIndex, string stringValue, bool useSharedString, bool save = true)
        {
            string columnValue = stringValue;
            DocumentFormat.OpenXml.Spreadsheet.CellValues cellValueType;
            DocumentFormat.OpenXml.Spreadsheet.Stylesheet stylesheet = spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet;

            // Add the shared string if necessary
            if (useSharedString)
            {
                if (Excel.IndexOfSharedString(spreadsheet, stringValue) == -1)
                {
                    Excel.AddSharedString(spreadsheet, stringValue, true);
                }
                columnValue = Excel.IndexOfSharedString(spreadsheet, stringValue).ToString();
                cellValueType = DocumentFormat.OpenXml.Spreadsheet.CellValues.SharedString;
            }
            else
            {
                cellValueType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String;
            }

            return SetCellValue(spreadsheet, worksheet, columnIndex, rowIndex, cellValueType, columnValue, null, save);
        }


        /// <summary>
        /// Sets a cell value with double number
        /// </summary>
        /// <param name="spreadsheet">Spreadsheet to use</param>
        /// <param name="worksheet">Worksheet to use</param>
        /// <param name="columnIndex">Index of the column</param>
        /// <param name="rowIndex">Index of the row</param>
        /// <param name="doubleValue">Double value</param>
        /// <param name="styleIndex">Style to use</param>
        /// <param name="save">Save the worksheet</param>
        /// <returns>True if succesful</returns>
        public static bool SetCellValue(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet, uint columnIndex, uint rowIndex, double doubleValue, uint? styleIndex, bool save = true)
        {
#if EN_US_CULTURE
         string columnValue = doubleValue.ToString();
#else
            string columnValue = doubleValue.ToString().Replace(",", ".");
#endif

            return SetCellValue(spreadsheet, worksheet, columnIndex, rowIndex, DocumentFormat.OpenXml.Spreadsheet.CellValues.Number, columnValue, styleIndex, save);
        }

      
        /// <summary>
        /// Sets the column width
        /// </summary>
        /// <param name="worksheet">Worksheet to use</param>
        /// <param name="columnIndex">Index of the column</param>
        /// <param name="width">Width to set</param>
        /// <returns>True if succesful</returns>
        public static bool SetColumnWidth(DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet, int columnIndex, int width)
        {
            DocumentFormat.OpenXml.Spreadsheet.Columns columns;
            DocumentFormat.OpenXml.Spreadsheet.Column column;

            // Get the column collection exists
            columns = worksheet.Elements<DocumentFormat.OpenXml.Spreadsheet.Columns>().FirstOrDefault();
            if (columns == null)
            {
                return false;
            }
            // Get the column
            column = columns.Elements<DocumentFormat.OpenXml.Spreadsheet.Column>().Where(item => item.Min == columnIndex).FirstOrDefault();
            if (columns == null)
            {
                return false;
            }

            column.Width = width;
            column.CustomWidth = true;

            worksheet.Save();

            return true;
        }

        /// <summary>
        /// Sets a cell value. The row and the cell are created if they do not exist. If the cell exists, the contents of the cell is overwritten
        /// </summary>
        /// <param name="spreadsheet">Spreadsheet to use</param>
        /// <param name="worksheet">Worksheet to use</param>
        /// <param name="columnIndex">Index of the column</param>
        /// <param name="rowIndex">Index of the row</param>
        /// <param name="valueType">Type of the value</param>
        /// <param name="value">The actual value</param>
        /// <param name="styleIndex">Index of the style to use. Null if no style is to be defined</param>
        /// <param name="save">Save the worksheet?</param>
        /// <returns>True if succesful</returns>
        private static bool SetCellValue(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet, uint columnIndex, uint rowIndex, DocumentFormat.OpenXml.Spreadsheet.CellValues valueType, string value, uint? styleIndex, bool save = true)
        {
            DocumentFormat.OpenXml.Spreadsheet.SheetData sheetData = worksheet.GetFirstChild<DocumentFormat.OpenXml.Spreadsheet.SheetData>();
            DocumentFormat.OpenXml.Spreadsheet.Row row;
            DocumentFormat.OpenXml.Spreadsheet.Row previousRow = null;
            DocumentFormat.OpenXml.Spreadsheet.Cell cell;
            DocumentFormat.OpenXml.Spreadsheet.Cell previousCell = null;
            DocumentFormat.OpenXml.Spreadsheet.Columns columns;
            DocumentFormat.OpenXml.Spreadsheet.Column previousColumn = null;
            string cellAddress = Excel.ColumnNameFromIndex(columnIndex) + rowIndex;

            DocumentFormat.OpenXml.Spreadsheet.Stylesheet stylesheet = spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet;

            // Check if the row exists, create if necessary
            if (sheetData.Elements<DocumentFormat.OpenXml.Spreadsheet.Row>().Where(item => item.RowIndex == rowIndex).Count() != 0)
            {
                row = sheetData.Elements<DocumentFormat.OpenXml.Spreadsheet.Row>().Where(item => item.RowIndex == rowIndex).First();
            }
            else
            {
                row = new DocumentFormat.OpenXml.Spreadsheet.Row() { RowIndex = rowIndex };
                //sheetData.Append(row);
                for (uint counter = rowIndex - 1; counter > 0; counter--)
                {
                    previousRow = sheetData.Elements<DocumentFormat.OpenXml.Spreadsheet.Row>().Where(item => item.RowIndex == counter).FirstOrDefault();
                    if (previousRow != null)
                    {
                        break;
                    }
                }
                sheetData.InsertAfter(row, previousRow);
            }

            // Check if the cell exists, create if necessary
            if (row.Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>().Where(item => item.CellReference.Value == cellAddress).Count() > 0)
            {
                cell = row.Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>().Where(item => item.CellReference.Value == cellAddress).First();
            }
            else
            {
                // Find the previous existing cell in the row
                for (uint counter = columnIndex - 1; counter > 0; counter--)
                {
                    previousCell = row.Elements<DocumentFormat.OpenXml.Spreadsheet.Cell>().Where(item => item.CellReference.Value == Excel.ColumnNameFromIndex(counter) + rowIndex).FirstOrDefault();
                    if (previousCell != null)
                    {
                        break;
                    }
                }
                cell = new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellReference = cellAddress };
                row.InsertAfter(cell, previousCell);
                // PatternFill pf = GetCellPatternFill(cell, spreadsheet);  
            }

            // Check if the column collection exists
            columns = worksheet.Elements<DocumentFormat.OpenXml.Spreadsheet.Columns>().FirstOrDefault();
            if (columns == null)
            {
                columns = worksheet.InsertAt(new DocumentFormat.OpenXml.Spreadsheet.Columns(), 0);
            }
            // Check if the column exists
            if (columns.Elements<DocumentFormat.OpenXml.Spreadsheet.Column>().Where(item => item.Min == columnIndex).Count() == 0)
            {
                // Find the previous existing column in the columns
                for (uint counter = columnIndex - 1; counter > 0; counter--)
                {
                    previousColumn = columns.Elements<DocumentFormat.OpenXml.Spreadsheet.Column>().Where(item => item.Min == counter).FirstOrDefault();
                    if (previousColumn != null)
                    {
                        break;
                    }
                }

                //Set column width for Migration ColorMarking based on EnergySavings
                if ((columnIndex == 13 && value == "ColorMarking") || (columnIndex == 15 && value == "ColorMarking"))
                {
                    columns.InsertAfter(
                       new DocumentFormat.OpenXml.Spreadsheet.Column()
                       {
                           Min = columnIndex,
                           Max = columnIndex,
                           CustomWidth = true,
                           Width = 2


                       }, previousColumn);
                }
                else
                {
                    columns.InsertAfter(
                       new DocumentFormat.OpenXml.Spreadsheet.Column()
                       {
                           Min = columnIndex,
                           Max = columnIndex,
                           CustomWidth = true,
                           Width = 27


                       }, previousColumn);
                }
            }


            // Add the value
            if (value == "ColorMarking")
                cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue("");
            else
                cell.CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(value);

            if (styleIndex != null)
            {
                cell.StyleIndex = styleIndex;
                // cell.StyleIndex = 3;
            }

            // added by raj
            if (styleIndex == 5)
            {

                //back ground color - pattern
                stylesheet.Fills.AppendChild(new Fill(new PatternFill(new ForegroundColor() { Rgb = new HexBinaryValue() { Value = "254061" } }) { PatternType = PatternValues.Solid }));
                //font color - font styles
                stylesheet.Fonts.AppendChild(new Font(new Bold(), new FontSize() { Val = 16 }, new Color() { Rgb = new HexBinaryValue() { Value = "000000" } }, new FontName() { Val = "Calibri" }));
                spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet.Save();
                CellFormats cellFormats = spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet.CellFormats;
                // pick tthe first cell format.
                CellFormat cellFormat = (CellFormat)cellFormats.ElementAt(0);

                CellFormat cf = new CellFormat(cellFormat.OuterXml);
                cf.FontId = stylesheet.Fonts.Count;

                cf.FontId = (UInt32)2;
                cf.FillId = (UInt32)4;
                cellFormats.AppendChild(cf);
                cell.StyleIndex = 5;
            }



            // added by raj

            if (valueType != DocumentFormat.OpenXml.Spreadsheet.CellValues.Date)
            {
                cell.DataType = new DocumentFormat.OpenXml.EnumValue<DocumentFormat.OpenXml.Spreadsheet.CellValues>(valueType);
            }

            // temp starts -- Commented by Raghu(becoz it will take to much time - performance issue)
            //if (save)
            //{
            //    worksheet.Save();
            //}

            // temp ends
            return true;
        }

        /// <summary>
        /// Adds a predefined style from the given xml
        /// </summary>
        /// <param name="spreadsheet">Spreadsheet to use</param>
        /// <param name="xml">Style definition as xml</param>
        /// <returns>True if succesful</returns>
        public static bool AddPredefinedStyles(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet, string xml)
        {


            spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet.InnerXml = xml;
            //  spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet.Append(fills1);
            spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet.Save();
            //  ends 
            return true;
        }


        /// <summary>
        /// Creates a basic workbook
        /// </summary>
        /// <param name="workbookName">Name of the workbook</param>
        /// <param name="createStylesInCode">Create the styles in code?</param>
        public void CreateBasicWorkbook(MemoryStream workbookName, DataTable table, bool isSubHeader, DataTable subHeaderContent, bool createStylesInCode,string sheetName)
        {
            DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet;
            DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet;
            System.IO.StreamReader styleXmlReader;
            string styleXml;

            spreadsheet = Excel.CreateWorkbook(workbookName);
            if (spreadsheet == null)
            {
                return;
            }

            if (createStylesInCode)
            {
                Excel.AddBasicStyles(spreadsheet);
                // Excel.AddPredefinedStyles(spreadsheet, null);
            }
            else
            {
                using (styleXmlReader = new System.IO.StreamReader("PredefinedStyles.xml"))
                {
                    styleXml = styleXmlReader.ReadToEnd();
                    Excel.AddPredefinedStyles(spreadsheet, styleXml);
                }
            }

            Excel.AddSharedString(spreadsheet, "Shared string");
            Excel.AddWorksheet(spreadsheet, !string.IsNullOrEmpty(sheetName)?sheetName:"Sheet1");
            // Excel.AddWorksheet(spreadsheet, "Test 2");
            worksheet = spreadsheet.WorkbookPart.WorksheetParts.First().Worksheet;
            uint i = 0;

            //add column names to the first row
            //Row header = new Row();
            //header.RowIndex = (UInt32)1;

            // if subheader is true then generate the subheader and its  content.
            if (isSubHeader)
            {
                if (subHeaderContent != null)
                {
                    ++i;

                    foreach (DataColumn column in subHeaderContent.Columns)
                    {
                        Excel.SetCellValue_customerName(spreadsheet, worksheet, 1, i, column.ColumnName.ToString(), true, false);
                        ++i;

                    }

                    //foreach (var row in subHeaderContent.Rows)
                    //{
                    //    System.Data.DataRow dRow = (DataRow)row;
                    //    int count = dRow.ItemArray.Count();
                    //    for (uint k = 1; k <= count; k++)
                    //    {
                    //        double doubleValue;
                    //        int intValue;
                    //        DateTime dateValue;
                    //        if (Double.TryParse(dRow.ItemArray[k - 1].ToString(), out doubleValue))
                    //        {
                    //            // Add a string

                    //            // Excel.SetCellValue(spreadsheet, worksheet, columnIndex, RowIndex, "Date", styleindex, false);
                    //            // Add date
                    //            Excel.SetCellValue(spreadsheet, worksheet, k == 1 ? k + 1 : k + 2, i, doubleValue, 4, true);


                    //        }
                    //        else if (int.TryParse(dRow.ItemArray[k - 1].ToString(), out intValue))
                    //        {
                    //            Excel.SetCellValue(spreadsheet, worksheet, k == 1 ? k + 1 : k + 2, i, intValue, null, true);

                    //        }
                    //        else if (DateTime.TryParse(dRow.ItemArray[k - 1].ToString(), out dateValue))
                    //        {
                    //            Excel.SetCellValue(spreadsheet, worksheet, k == 1 ? k + 1 : k + 2, i, dateValue.ToOADate(), 9, true);
                    //        }
                    //        else
                    //        {
                    //            Excel.SetCellValue(spreadsheet, worksheet, k == 1 ? k + 1 : k + 2, i, dRow.ItemArray[k - 1].ToString(), true);
                    //        }

                    //    }
                    //}

                }
                // subHeaderContent.
            }

            // for next row Header
            if (isSubHeader)
                i = i + 2;
            else
                i = i + 1;
            foreach (DataColumn column in table.Columns)
            {
                int colintex = table.Columns.IndexOf(column) + 1;
                Excel.SetCellValue(spreadsheet, worksheet, (uint)colintex, i, CellValues.String, column.ColumnName, 5, false);
            }

            foreach (var row in table.Rows)
            {

                System.Data.DataRow dRow = (DataRow)row;
                int count = dRow.ItemArray.Count();
                for (uint k = 1; k <= count; k++)
                {
                    double doubleValue;
                    int intValue;
                    DateTime dateValue;
                    //check the data type of the cell content to apply basic formatting
                    int colCount = Convert.ToInt32(k) - 1;
                    if (table.Columns[colCount].DataType.ToString() == "System.Decimal")
                    {
                        double.TryParse(dRow.ItemArray[k - 1].ToString(), out doubleValue);
                        Excel.SetCellValue(spreadsheet, worksheet, k, i + 1, doubleValue, 2, true);
                    }
                    else if (DateTime.TryParse(dRow.ItemArray[k - 1].ToString(), out dateValue))
                    {
                        // Add a string

                        // Excel.SetCellValue(spreadsheet, worksheet, columnIndex, RowIndex, "Date", styleindex, false);
                        // Add date
                        Excel.SetCellValue(spreadsheet, worksheet, k, i + 1, dateValue.ToOADate(), 13, true);

                    }
                    else if (int.TryParse(dRow.ItemArray[k - 1].ToString(), out intValue))
                    {
                        Excel.SetCellValue(spreadsheet, worksheet, k, i + 1, intValue, null, true);

                    }
                    //else if (Double.TryParse(dRow.ItemArray[k - 1].ToString(), out doubleValue))
                    //{
                    //    Excel.SetCellValue(spreadsheet, worksheet, k, i + 1, doubleValue, 2, true);
                    //}
                    else
                    {
                        Excel.SetCellValue(spreadsheet, worksheet, k, i + 1, dRow.ItemArray[k - 1].ToString(), true);
                    }



                }
                ++i;
            }
            MergeCells mergeCells;

            if (worksheet.Elements<MergeCells>().Count() > 0)
                mergeCells = worksheet.Elements<MergeCells>().First();
            else
            {
                mergeCells = new MergeCells();
                // Insert a MergeCells object into the specified position.
                if (worksheet.Elements<CustomSheetView>().Count() > 0)
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<CustomSheetView>().First());
                else
                {
                    worksheet.InsertAfter(mergeCells, worksheet.Elements<SheetData>().First());
                }
            }


            // Create the merged cell and append it to the MergeCells collection.
            int colCounts = table.Columns.Count;
            string[] Sheetname = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

            MergeCell mergeCell = new MergeCell()
            {
                Reference = new StringValue("A1" + ":" + Sheetname[colCounts - 1] + "1")
            };
            MergeCell mergeCell1 = new MergeCell()
            {
                Reference = new StringValue("A2" + ":" + Sheetname[colCounts - 1] + "2")
            };
            MergeCell mergeCell2 = new MergeCell()
            {
                Reference = new StringValue("A3" + ":" + Sheetname[colCounts - 1] + "3")
            };

            mergeCells.Append(mergeCell);

            mergeCells.Append(mergeCell1);
            mergeCells.Append(mergeCell2);

            worksheet.Save();
            spreadsheet.Close();

        }
               
     

    }
}