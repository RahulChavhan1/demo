﻿
//Create by     : Irsathameen.k
//Create On     : 01-june-2015
//Created for   : Export Excel

#region NameSpace

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Data;
using System.Reflection;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using OHES.eFit.Data.Utility;
#endregion

namespace OHES.eFit.OpenXML
{
    public class CreateExcelFile
    {

        public static bool CreateExcelDocument<T>(List<T> list, MemoryStream workbookName, string sheetName, bool isHeader, string headerText)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(ListToDataTable(list));

            return CreateExcelDocument(ds, workbookName, sheetName, isHeader, headerText);
        }

        public static DataTable ListToDataTable<T>(List<T> list)
        {
            DataTable dt = new DataTable();

            foreach (PropertyInfo info in typeof(T).GetProperties())
            {
                dt.Columns.Add(new DataColumn(info.Name, GetNullableType(info.PropertyType)));
            }
            foreach (T t in list)
            {
                DataRow row = dt.NewRow();
                foreach (PropertyInfo info in typeof(T).GetProperties())
                {
                    if (!IsNullableType(info.PropertyType))
                        row[info.Name] = info.GetValue(t, null);
                    else
                        row[info.Name] = (info.GetValue(t, null) ?? DBNull.Value);
                }
                dt.Rows.Add(row);
            }
            return dt;
        }
        private static Type GetNullableType(Type t)
        {
            Type returnType = t;
            if (t.IsGenericType && t.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
            {
                returnType = Nullable.GetUnderlyingType(t);
            }
            return returnType;
        }
        private static bool IsNullableType(Type type)
        {
            return (type == typeof(string) ||
                    type.IsArray ||
                    (type.IsGenericType &&
                     type.GetGenericTypeDefinition().Equals(typeof(Nullable<>))));
        }

        public static bool CreateExcelDocument(DataTable dt, MemoryStream workbookName, string sheetName, bool isHeader, string headerText)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            bool result = CreateExcelDocument(ds, workbookName, sheetName, isHeader, headerText);
            ds.Tables.Remove(dt);
            return result;
        }



        /// <summary>
        /// Create an Excel file, and write it to a file.
        /// </summary>
        /// <param name="ds">DataSet containing the data to be written to the Excel.</param>
        /// <param name="excelFilename">Name of file to be written.</param>
        /// <returns>True if successful, false if something went wrong.</returns>
        public static bool CreateExcelDocument(DataSet ds, MemoryStream workbookName, string sheetName, bool isHeader, string headerText)
        {
            try
            {
                using (SpreadsheetDocument document = SpreadsheetDocument.Create(workbookName, SpreadsheetDocumentType.Workbook))
                {
                    WriteExcelFile(ds, document, sheetName, isHeader, headerText);
                }
                return true;
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
                return false;
            }
        }

        private static void WriteExcelFile(DataSet ds, SpreadsheetDocument spreadsheet, string sheetName, bool isHeader, string headerText)
        {
            //  Create the Excel file contents.  This function is used when creating an Excel file either writing 
            //  to a file, or writing to a MemoryStream.
            spreadsheet.AddWorkbookPart();
            spreadsheet.WorkbookPart.Workbook = new DocumentFormat.OpenXml.Spreadsheet.Workbook();

            // which prevents crashes in Excel 2010
            spreadsheet.WorkbookPart.Workbook.Append(new BookViews(new WorkbookView()));

            //  If we don't add a "WorkbookStylesPart", OLEDB will refuse to connect to this .xlsx file !
            WorkbookStylesPart workbookStylesPart = spreadsheet.WorkbookPart.AddNewPart<WorkbookStylesPart>("rIdStyles");

            Stylesheet stylesheet = new Stylesheet();
            workbookStylesPart.Stylesheet = stylesheet;


            //  Loop through each of the DataTables in our DataSet, and create a new Excel Worksheet for each.
            uint worksheetNumber = 1;
            Sheets sheets = spreadsheet.WorkbookPart.Workbook.AppendChild<Sheets>(new Sheets());
            CreateExcelFile.AddBasicStyles(spreadsheet);
            int index = 0;

            foreach (DataTable dt in ds.Tables)
            {
                //  For each worksheet you want to create
               // string worksheetName = dt.TableName;
                string worksheetName = sheetName;

                //  Create worksheet part, and add it to the sheets collection in workbook
                WorksheetPart newWorksheetPart = spreadsheet.WorkbookPart.AddNewPart<WorksheetPart>();
                Sheet sheet = new Sheet() { Id = spreadsheet.WorkbookPart.GetIdOfPart(newWorksheetPart), SheetId = worksheetNumber, Name = worksheetName };
                DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet;
                // If you want to define the Column Widths for a Worksheet, you need to do this *before* appending the SheetData
                // http://social.msdn.microsoft.com/Forums/en-US/oxmlsdk/thread/1d93eca8-2949-4d12-8dd9-15cc24128b10/

                sheets.Append(sheet);

                //  Append this worksheet's data to our Workbook, using OpenXmlWriter, to prevent memory problems
                WriteDataTableToExcelWorksheet(dt, newWorksheetPart, isHeader, headerText);
                worksheet = spreadsheet.WorkbookPart.WorksheetParts.ElementAt(index).Worksheet;

                //Set Column Width
                //Begin
                SetColumnWidth(dt, worksheet);
                //End


                // Merge header
                //Begin
                if (isHeader)
                {
                    //Merging cells for header
                    MergeCells mergeCells;

                    if (worksheet.Elements<MergeCells>().Count() > 0)
                        mergeCells = worksheet.Elements<MergeCells>().First();
                    else
                    {
                        mergeCells = new MergeCells();
                        // Insert a MergeCells object into the specified position.
                        if (worksheet.Elements<CustomSheetView>().Count() > 0)
                            worksheet.InsertAfter(mergeCells, worksheet.Elements<CustomSheetView>().First());
                        else
                        {
                            worksheet.InsertAfter(mergeCells, worksheet.Elements<SheetData>().First());
                        }
                    }

                    MergeCell mergeCell_1 = new MergeCell()
                    {
                        Reference = new StringValue("A1" + ":" + GetExcelColumnName(dt.Columns.Count - 1) + "1")
                    };
                    MergeCell mergeCell_2 = new MergeCell()
                    {
                        Reference = new StringValue("A2" + ":" + GetExcelColumnName(dt.Columns.Count - 1) + "2")
                    };
                    MergeCell mergeCell_3 = new MergeCell()
                    {
                        Reference = new StringValue("A3" + ":" + GetExcelColumnName(dt.Columns.Count - 1) + "3")
                    };

                    mergeCells.Append(mergeCell_1);
                    mergeCells.Append(mergeCell_2);
                    mergeCells.Append(mergeCell_3);
                }
                //End mergin header
                // End Merging  cell
                worksheetNumber++;
                index++;

            } //for each ds

            spreadsheet.WorkbookPart.Workbook.Save();
        }

        private static void WriteDataTableToExcelWorksheet(DataTable dt, WorksheetPart worksheetPart, bool isHeader, string headerText)
        {
            OpenXmlWriter writer = OpenXmlWriter.Create(worksheetPart, Encoding.ASCII);
            writer.WriteStartElement(new Worksheet());
            writer.WriteStartElement(new SheetData());

            string cellValue = "";

            //  Create a Header Row in our Excel file, containing one header for each Column of data in our DataTable.
            //
            //  We'll also create an array, showing which type each column of data is (Text or Numeric), so when we come to write the actual
            //  cells of data, we'll know if to write Text values or Numeric cell values.
            int numberOfColumns = dt.Columns.Count;
            bool[] IsNumericColumn_RounderValues = new bool[numberOfColumns];
            bool[] IsNumericColumn_DecimalValues = new bool[numberOfColumns];
            bool[] IsDateColumn = new bool[numberOfColumns];

            string[] excelColumnNames = new string[numberOfColumns];
            for (int n = 0; n < numberOfColumns; n++)
                excelColumnNames[n] = GetExcelColumnName(n);

            //
            //  Create the Header row in our Excel Worksheet
            //

            uint rowIndex;

            //Create Header
            //Begin
            if (isHeader)
            {
                rowIndex = 4;
                writer.WriteStartElement(new Row { RowIndex = 1 });
                ushort styleindex = 2;
                // first argument for address of the cell 2.header text, 3.openxml writter 4.styleindex
                // styleindex 2  -> font size 14 and bold 
                AppendTextCell("A1", headerText, ref writer, styleindex);
                writer.WriteEndElement();   //  End of header "Row"

            }
            //End // Create header
            else
            {
                rowIndex = 1;
            }


            writer.WriteStartElement(new Row { RowIndex = rowIndex });
            for (int colInx = 0; colInx < numberOfColumns; colInx++)
            {
                DataColumn col = dt.Columns[colInx];
                AppendTextCell(excelColumnNames[colInx] + rowIndex, col.ColumnName, ref writer, 1);

                IsNumericColumn_RounderValues[colInx] = (col.DataType.FullName == "System.Int32") || (col.DataType.FullName == "System.Single");
                IsNumericColumn_DecimalValues[colInx] = (col.DataType.FullName == "System.Decimal") || (col.DataType.FullName == "System.Double");
                IsDateColumn[colInx] = (col.DataType.FullName == "System.DateTime");

            }
            writer.WriteEndElement();   //  End of header "Row"

            //
            //  Now, step through each row of data in our DataTable...
            //
            double cellNumericValue = 0;
            foreach (DataRow dr in dt.Rows)
            {
                // ...create a new row, and append a set of this row's data to it.
                ++rowIndex;

                writer.WriteStartElement(new Row { RowIndex = rowIndex });

                for (int colInx = 0; colInx < numberOfColumns; colInx++)
                {
                    cellValue = dr.ItemArray[colInx].ToString();
                    cellValue = ReplaceHexadecimalSymbols(cellValue);

                    // Create cell with data (interger or sigle rounded values)
                    if (IsNumericColumn_RounderValues[colInx])
                    {
                        //  For numeric cells, make sure our input data IS a number, then write it out to the Excel file.
                        //  If this numeric value is NULL, then don't write anything to the Excel file.
                        cellNumericValue = 0;
                        if (double.TryParse(cellValue, out cellNumericValue))
                        {
                            cellValue = cellNumericValue.ToString();
                            AppendNumericCell(excelColumnNames[colInx] + rowIndex.ToString(), cellValue, ref writer, 0);
                        }
                    }
                    // Create cell with data (decimeal values)
                    else if (IsNumericColumn_DecimalValues[colInx])
                    {
                        //  For numeric cells, make sure our input data IS a number, then write it out to the Excel file.
                        //  If this numeric value is NULL, then don't write anything to the Excel file.
                        cellNumericValue = 0;
                        if (double.TryParse(cellValue, out cellNumericValue))
                        {
                            cellValue = cellNumericValue.ToString();
                            //here style index =3 for 2 place decimal values with comma separator
                            AppendNumericCell(excelColumnNames[colInx] + rowIndex.ToString(), cellValue, ref writer, 3);
                        }
                    }
                    else if (IsDateColumn[colInx])
                    {
                        //  This is a date value.
                        DateTime dtValue;
                        string strValue = "";
                        if (DateTime.TryParse(cellValue, out dtValue))
                            strValue = dtValue.ToShortDateString();
                        AppendTextCell(excelColumnNames[colInx] + rowIndex.ToString(), strValue, ref writer, 0);
                    }
                    else
                    {
                        //  For text cells, just write the input data straight out to the Excel file.
                        AppendTextCell(excelColumnNames[colInx] + rowIndex.ToString(), cellValue, ref writer, 0);
                    }
                }

                writer.WriteEndElement(); //  End of Row
            }

            writer.WriteEndElement(); //  End of SheetData
            writer.WriteEndElement(); //  End of worksheet

            writer.Close();
        }

        private static void AppendTextCell(string cellReference, string cellStringValue, ref OpenXmlWriter writer, UInt16 styleIndex)
        {
            //  Add a new Excel Cell to our Row 
            writer.WriteElement(new Cell
            {

                CellValue = new CellValue(cellStringValue),
                CellReference = cellReference,
                DataType = CellValues.String,
                StyleIndex = styleIndex

            });
        }

        private static void AppendNumericCell(string cellReference, string cellStringValue, ref OpenXmlWriter writer, UInt16 styleIndex)
        {
            //  Add a new Excel Cell to our Row 
            writer.WriteElement(new Cell
            {
                CellValue = new CellValue(cellStringValue),
                CellReference = cellReference,
                DataType = CellValues.Number,
                StyleIndex = styleIndex
            });
        }

        private static string ReplaceHexadecimalSymbols(string txt)
        {
            string r = "[\x00-\x08\x0B\x0C\x0E-\x1F\x26]";
            return Regex.Replace(txt, r, "", RegexOptions.Compiled);
        }

        //  Convert a zero-based column index into an Excel column reference  (A, B, C.. Y, Y, AA, AB, AC... AY, AZ, B1, B2..)
        public static string GetExcelColumnName(int columnIndex)
        {
            //  eg  (0) should return "A"
            //      (1) should return "B"
            //      (25) should return "Z"
            //      (26) should return "AA"
            //      (27) should return "AB"
            //      ..etc..
            char firstChar;
            char secondChar;
            char thirdChar;

            if (columnIndex < 26)
            {
                return ((char)('A' + columnIndex)).ToString();
            }

            if (columnIndex < 702)
            {
                firstChar = (char)('A' + (columnIndex / 26) - 1);
                secondChar = (char)('A' + (columnIndex % 26));

                return string.Format("{0}{1}", firstChar, secondChar);
            }

            int firstInt = columnIndex / 26 / 26;
            int secondInt = (columnIndex - firstInt * 26 * 26) / 26;
            if (secondInt == 0)
            {
                secondInt = 26;
                firstInt = firstInt - 1;
            }
            int thirdInt = (columnIndex - firstInt * 26 * 26 - secondInt * 26);

            firstChar = (char)('A' + firstInt - 1);
            secondChar = (char)('A' + secondInt - 1);
            thirdChar = (char)('A' + thirdInt);

            return string.Format("{0}{1}{2}", firstChar, secondChar, thirdChar);
        }

        //Add style for cells
        public static bool AddBasicStyles(DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadsheet)
        {
            DocumentFormat.OpenXml.Spreadsheet.Stylesheet ss = spreadsheet.WorkbookPart.WorkbookStylesPart.Stylesheet;

            Fonts fts = new Fonts();
            DocumentFormat.OpenXml.Spreadsheet.Font ft = new DocumentFormat.OpenXml.Spreadsheet.Font();

            //Font index 0
            FontName ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            FontSize ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(11);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            fts.Append(ft);

            //Font index 1
            //Font colour white with bold
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(11);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            ft.Bold = new Bold();
            ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "FFFFFFFF" } };
            fts.Append(ft);

            //Font index 2
            //Font colour black with bold
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(11);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            ft.Bold = new Bold();
            ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "000000" } };
            fts.Append(ft);

            //Font index 3
            //Font colour red with block
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(14);
            ft.Bold = new Bold();
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            //ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "FF0000" } };
            fts.Append(ft);

            //Font index 4
            //This font for customer name in report 
            ft = new DocumentFormat.OpenXml.Spreadsheet.Font();
            ftn = new FontName();
            ftn.Val = StringValue.FromString("Calibri");
            ftsz = new FontSize();
            ftsz.Val = DoubleValue.FromDouble(18);
            ft.FontName = ftn;
            ft.FontSize = ftsz;
            // ft.Color = new Color() { Rgb = new HexBinaryValue() { Value = "000000" } };
            fts.Append(ft);


            Fills fills = new Fills();
            Fill fill;
            PatternFill patternFill;

            fill = new Fill();// index 0
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("FFFFFF");
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill(); // index 1
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("FFFFFF");
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill(); // index 2
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("2E6390");  // efit-color
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);

            fill = new Fill();// index 3
            patternFill = new PatternFill();
            patternFill.PatternType = PatternValues.Solid;
            patternFill.ForegroundColor = new ForegroundColor();
            patternFill.ForegroundColor.Rgb = HexBinaryValue.FromString("C20A24"); //Red
            patternFill.BackgroundColor = new BackgroundColor();
            patternFill.BackgroundColor.Rgb = patternFill.ForegroundColor.Rgb;
            fill.PatternFill = patternFill;
            fills.Append(fill);



            fills.Count = UInt32Value.FromUInt32((uint)fills.ChildElements.Count);

            Borders borders = new Borders();
            Border border = new Border();
            border.LeftBorder = new LeftBorder();
            border.RightBorder = new RightBorder();
            border.TopBorder = new TopBorder();
            border.BottomBorder = new BottomBorder();
            border.DiagonalBorder = new DiagonalBorder();
            borders.Append(border);

            border = new Border();
            border.LeftBorder = new LeftBorder();
            border.LeftBorder.Style = BorderStyleValues.None;
            border.RightBorder = new RightBorder();
            border.RightBorder.Style = BorderStyleValues.None;
            border.TopBorder = new TopBorder();
            border.TopBorder.Style = BorderStyleValues.Thick;
            border.TopBorder.Color = new Color() { Rgb = new HexBinaryValue() { Value = "666699" } };
            border.BottomBorder = new BottomBorder();
            border.BottomBorder.Style = BorderStyleValues.Double;
            border.BottomBorder.Color = new Color() { Rgb = new HexBinaryValue() { Value = "666699" } };
            border.DiagonalBorder = new DiagonalBorder();
            borders.Append(border);
            borders.Count = UInt32Value.FromUInt32((uint)borders.ChildElements.Count);

            CellStyleFormats csfs = new CellStyleFormats();
            CellFormat cf = new CellFormat();
            cf.NumberFormatId = 0;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            csfs.Append(cf);
            csfs.Count = UInt32Value.FromUInt32((uint)csfs.ChildElements.Count);

            uint iExcelIndex = 164;
            NumberingFormats nfs = new NumberingFormats();
            CellFormats cfs = new CellFormats();

            //Index 0 Date Time format 
            NumberingFormat nfDateTime = new NumberingFormat();
            nfDateTime.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            nfDateTime.FormatCode = StringValue.FromString("dd/mm/yyyy hh:mm");
            nfs.Append(nfDateTime);

            // @ is also Excel style index 1 
            NumberingFormat nfForcedText = new NumberingFormat();
            nfForcedText.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            nfForcedText.FormatCode = StringValue.FromString("@");
            nfs.Append(nfForcedText);

            //Index 2 date only
            NumberingFormat nfDate = new NumberingFormat();
            nfDate.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            nfDate.FormatCode = StringValue.FromString("dd/mm/yyyy");
            nfs.Append(nfDate);

            // Index 3 #,##0.00 is also Excel style index 4
            NumberingFormat nf2decimal = new NumberingFormat();
            nf2decimal.NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++);
            nf2decimal.FormatCode = StringValue.FromString("#,##0.00");
            nfs.Append(nf2decimal);

            //style index 0
            cf = new CellFormat();
            cf.NumberFormatId = 0;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cfs.Append(cf);



            //style index 1
            cf = new CellFormat();
            cf.NumberFormatId = nfForcedText.NumberFormatId;
            cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center };
            cf.FontId = 1;
            cf.FillId = 2;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 2
            cf = new CellFormat();
            cf.FontId = 3;
            cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center };
            cf.ApplyAlignment = BooleanValue.FromBoolean(true);
            cfs.Append(cf);


            //style index 3 decimal
            cf = new CellFormat();
            cf.NumberFormatId = nf2decimal.NumberFormatId;
            cf.FontId = 0;
            cf.FontId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cf.Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Right, Vertical = VerticalAlignmentValues.Center };
            cf.ApplyAlignment = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            //style index 4
            // Date format column
            cf = new CellFormat();
            cf.NumberFormatId = nfDate.NumberFormatId;
            cf.FontId = 0;
            cf.FillId = 0;
            cf.BorderId = 0;
            cf.FormatId = 0;
            cf.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            cfs.Append(cf);

            cfs.Count = UInt32Value.FromUInt32((uint)cfs.ChildElements.Count);

            ss.Append(nfs);
            ss.Append(fts);
            ss.Append(fills);
            ss.Append(borders);
            ss.Append(csfs);
            ss.Append(cfs);


            return true;
        }

        // set columns width
        public static void SetColumnWidth(DataTable dt, Worksheet worksheet)
        {
            DocumentFormat.OpenXml.Spreadsheet.Columns columns;
            DocumentFormat.OpenXml.Spreadsheet.Column previousColumn = null;
            foreach (DataColumn column in dt.Columns)
            {
                int columnIndex = dt.Columns.IndexOf(column) + 1;

                // Check if the column collection exists
                columns = worksheet.Elements<DocumentFormat.OpenXml.Spreadsheet.Columns>().FirstOrDefault();
                if (columns == null)
                {
                    columns = worksheet.InsertAt(new DocumentFormat.OpenXml.Spreadsheet.Columns(), 0);
                }
                // Check if the column exists
                if (columns.Elements<DocumentFormat.OpenXml.Spreadsheet.Column>().Where(item => item.Min == columnIndex).Count() == 0)
                {
                    // Find the previous existing column in the columns
                    for (int counter = dt.Columns.Count - 1; counter > 0; counter--)
                    {
                        previousColumn = columns.Elements<DocumentFormat.OpenXml.Spreadsheet.Column>().Where(item => item.Min == counter).FirstOrDefault();
                        if (previousColumn != null)
                        {
                            break;
                        }
                    }


                    columns.InsertAfter(
                       new DocumentFormat.OpenXml.Spreadsheet.Column()
                       {
                           Min = (uint)columnIndex,
                           Max = (uint)columnIndex,
                           CustomWidth = true,
                           Width = 27
                       }, previousColumn);

                }
            } //foreach

        }


        // This function only for efit project.if you use this class to other project  you can delete the following functions [WITH ONLY FOR EFIT  PROJECT REGION FUNCTIONS]
        //1.CreateExcelDocument_ExtraRowsNextToHeader
        //2.CreateExcelDocument_ExtraRowsNextToHeader
        //3.WriteExcelFile_ExtraRowsNextToHeader
        //4.WriteDataTableToExcelWorksheet_ExtraRowsNextToHeader

        #region ONLY FOR EFIT PROJECT

        public static bool CreateExcelDocument_ExtraRowsNextToHeader(DataTable dt, MemoryStream workbookName, string sheetName, bool isHeader, string headerText, Dictionary<string, string> objDictionary)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            bool result = CreateExcelDocument_ExtraRowsNextToHeader(ds, workbookName, sheetName, isHeader, headerText, objDictionary);
            ds.Tables.Remove(dt);
            return result;
        }



        /// <summary>
        /// Create an Excel file, and write it to a file.
        /// </summary>
        /// <param name="ds">DataSet containing the data to be written to the Excel.</param>
        /// <param name="excelFilename">Name of file to be written.</param>
        /// <returns>True if successful, false if something went wrong.</returns>
        public static bool CreateExcelDocument_ExtraRowsNextToHeader(DataSet ds, MemoryStream workbookName, string sheetName, bool isHeader, string headerText, Dictionary<string, string> objDictionary)
        {
            try
            {
                using (SpreadsheetDocument document = SpreadsheetDocument.Create(workbookName, SpreadsheetDocumentType.Workbook))
                {
                    WriteExcelFile_ExtraRowsNextToHeader(ds, document, sheetName, isHeader, headerText, objDictionary);
                }
                return true;
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
                return false;
            }
        }

        private static void WriteExcelFile_ExtraRowsNextToHeader(DataSet ds, SpreadsheetDocument spreadsheet, string sheetName, bool isHeader, string headerText, Dictionary<string, string> objDictionary)
        {
            //  Create the Excel file contents.  This function is used when creating an Excel file either writing 
            //  to a file, or writing to a MemoryStream.
            spreadsheet.AddWorkbookPart();
            spreadsheet.WorkbookPart.Workbook = new DocumentFormat.OpenXml.Spreadsheet.Workbook();

            // which prevents crashes in Excel 2010
            spreadsheet.WorkbookPart.Workbook.Append(new BookViews(new WorkbookView()));

            //  If we don't add a "WorkbookStylesPart", OLEDB will refuse to connect to this .xlsx file !
            WorkbookStylesPart workbookStylesPart = spreadsheet.WorkbookPart.AddNewPart<WorkbookStylesPart>("rIdStyles");

            Stylesheet stylesheet = new Stylesheet();
            workbookStylesPart.Stylesheet = stylesheet;


            //  Loop through each of the DataTables in our DataSet, and create a new Excel Worksheet for each.
            uint worksheetNumber = 1;
            Sheets sheets = spreadsheet.WorkbookPart.Workbook.AppendChild<Sheets>(new Sheets());
            CreateExcelFile.AddBasicStyles(spreadsheet);
            int index = 0;

            foreach (DataTable dt in ds.Tables)
            {
                //  For each worksheet you want to create
                // string worksheetName = dt.TableName;
                string worksheetName = sheetName;

                //  Create worksheet part, and add it to the sheets collection in workbook
                WorksheetPart newWorksheetPart = spreadsheet.WorkbookPart.AddNewPart<WorksheetPart>();
                Sheet sheet = new Sheet() { Id = spreadsheet.WorkbookPart.GetIdOfPart(newWorksheetPart), SheetId = worksheetNumber, Name = worksheetName };
                DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet;
                // If you want to define the Column Widths for a Worksheet, you need to do this *before* appending the SheetData
                // http://social.msdn.microsoft.com/Forums/en-US/oxmlsdk/thread/1d93eca8-2949-4d12-8dd9-15cc24128b10/

                sheets.Append(sheet);

                //  Append this worksheet's data to our Workbook, using OpenXmlWriter, to prevent memory problems
                WriteDataTableToExcelWorksheet_ExtraRowsNextToHeader(dt, newWorksheetPart, isHeader, headerText, objDictionary);
                worksheet = spreadsheet.WorkbookPart.WorksheetParts.ElementAt(index).Worksheet;

                //Set Column Width
                //Begin
                SetColumnWidth(dt, worksheet);
                //End


                // Merge header
                //Begin
                if (isHeader)
                {
                    //Merging cells for header
                    MergeCells mergeCells;

                    if (worksheet.Elements<MergeCells>().Count() > 0)
                        mergeCells = worksheet.Elements<MergeCells>().First();
                    else
                    {
                        mergeCells = new MergeCells();
                        // Insert a MergeCells object into the specified position.
                        if (worksheet.Elements<CustomSheetView>().Count() > 0)
                            worksheet.InsertAfter(mergeCells, worksheet.Elements<CustomSheetView>().First());
                        else
                        {
                            worksheet.InsertAfter(mergeCells, worksheet.Elements<SheetData>().First());
                        }
                    }

                    MergeCell mergeCell_1 = new MergeCell()
                    {
                        Reference = new StringValue("A1" + ":" + GetExcelColumnName(dt.Columns.Count - 1) + "1")
                    };
                    MergeCell mergeCell_2 = new MergeCell()
                    {
                        Reference = new StringValue("A2" + ":" + GetExcelColumnName(dt.Columns.Count - 1) + "2")
                    };
                    //MergeCell mergeCell_3 = new MergeCell()
                    //{
                    //    Reference = new StringValue("A3" + ":" + GetExcelColumnName(dt.Columns.Count - 1) + "3")
                    //};

                    mergeCells.Append(mergeCell_1);
                    mergeCells.Append(mergeCell_2);
                    // mergeCells.Append(mergeCell_3);
                }
                //End mergin header
                // End Merging  cell
                worksheetNumber++;
                index++;

            } //for each ds

            spreadsheet.WorkbookPart.Workbook.Save();
        }

        private static void WriteDataTableToExcelWorksheet_ExtraRowsNextToHeader(DataTable dt, WorksheetPart worksheetPart, bool isHeader, string headerText, Dictionary<string, string> objDictionary)
        {
            OpenXmlWriter writer = OpenXmlWriter.Create(worksheetPart, Encoding.ASCII);
            writer.WriteStartElement(new Worksheet());
            writer.WriteStartElement(new SheetData());

            string cellValue = "";

            //  Create a Header Row in our Excel file, containing one header for each Column of data in our DataTable.
            //
            //  We'll also create an array, showing which type each column of data is (Text or Numeric), so when we come to write the actual
            //  cells of data, we'll know if to write Text values or Numeric cell values.
            int numberOfColumns = dt.Columns.Count;
            bool[] IsNumericColumn_RounderValues = new bool[numberOfColumns];
            bool[] IsNumericColumn_DecimalValues = new bool[numberOfColumns];
            bool[] IsDateColumn = new bool[numberOfColumns];

            string[] excelColumnNames = new string[numberOfColumns];
            for (int n = 0; n < numberOfColumns; n++)
                excelColumnNames[n] = GetExcelColumnName(n);

            //
            //  Create the Header row in our Excel Worksheet
            //

            uint rowIndex;

            //Create Header
            //Begin
            if (isHeader)
            {
                rowIndex = 4;
                writer.WriteStartElement(new Row { RowIndex = 1 });
                ushort styleindex = 2;
                // first argument for address of the cell 2.header text, 3.openxml writter 4.styleindex
                // styleindex 2  -> font size 14 and bold 
                AppendTextCell("A1", headerText, ref writer, styleindex);
                writer.WriteEndElement();   //  End of header "Row"


                int iteration = 1;
                writer.WriteStartElement(new Row { RowIndex = 3 });

                string[] Sheetname = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

                foreach (KeyValuePair<string, string> pair in objDictionary)
                {

                    // first argument for address of the cell 2.header text, 3.openxml writter 4.styleindex
                    // styleindex 2  -> font size 14 and bold 
                    AppendTextCell(Sheetname[(iteration - 1)] + "3", pair.Key + " : ", ref writer, 3);
                    AppendTextCell(Sheetname[(iteration)] + "3", pair.Value, ref writer, 4);
                    //  End of header "Row"
                    iteration = iteration + 2;
                }
                writer.WriteEndElement();

            }
            //End // Create header
            else
            {
                rowIndex = 1;
            }


            writer.WriteStartElement(new Row { RowIndex = rowIndex });
            for (int colInx = 0; colInx < numberOfColumns; colInx++)
            {
                DataColumn col = dt.Columns[colInx];
                AppendTextCell(excelColumnNames[colInx] + rowIndex, col.ColumnName, ref writer, 1);

                IsNumericColumn_RounderValues[colInx] = (col.DataType.FullName == "System.Int32") || (col.DataType.FullName == "System.Single");
                IsNumericColumn_DecimalValues[colInx] = (col.DataType.FullName == "System.Decimal") || (col.DataType.FullName == "System.Double");
                IsDateColumn[colInx] = (col.DataType.FullName == "System.DateTime");

            }
            writer.WriteEndElement();   //  End of header "Row"

            //
            //  Now, step through each row of data in our DataTable...
            //
            double cellNumericValue = 0;
            foreach (DataRow dr in dt.Rows)
            {
                // ...create a new row, and append a set of this row's data to it.
                ++rowIndex;

                writer.WriteStartElement(new Row { RowIndex = rowIndex });

                for (int colInx = 0; colInx < numberOfColumns; colInx++)
                {
                    cellValue = dr.ItemArray[colInx].ToString();
                    cellValue = ReplaceHexadecimalSymbols(cellValue);

                    // Create cell with data (interger or sigle rounded values)
                    if (IsNumericColumn_RounderValues[colInx])
                    {
                        //  For numeric cells, make sure our input data IS a number, then write it out to the Excel file.
                        //  If this numeric value is NULL, then don't write anything to the Excel file.
                        cellNumericValue = 0;
                        if (double.TryParse(cellValue, out cellNumericValue))
                        {
                            cellValue = cellNumericValue.ToString();
                            AppendNumericCell(excelColumnNames[colInx] + rowIndex.ToString(), cellValue, ref writer, 0);
                        }
                    }
                    // Create cell with data (decimeal values)
                    else if (IsNumericColumn_DecimalValues[colInx])
                    {
                        //  For numeric cells, make sure our input data IS a number, then write it out to the Excel file.
                        //  If this numeric value is NULL, then don't write anything to the Excel file.
                        cellNumericValue = 0;
                        if (double.TryParse(cellValue, out cellNumericValue))
                        {
                            cellValue = cellNumericValue.ToString();
                            //here style index =3 for 2 place decimal values with comma separator
                            AppendNumericCell(excelColumnNames[colInx] + rowIndex.ToString(), cellValue, ref writer, 3);
                        }
                    }
                    else if (IsDateColumn[colInx])
                    {
                        //  This is a date value.
                        DateTime dtValue;
                        string strValue = "";
                        if (DateTime.TryParse(cellValue, out dtValue))
                            strValue = dtValue.ToShortDateString();
                        AppendTextCell(excelColumnNames[colInx] + rowIndex.ToString(), strValue, ref writer, 0);
                    }
                    else
                    {
                        //  For text cells, just write the input data straight out to the Excel file.
                        AppendTextCell(excelColumnNames[colInx] + rowIndex.ToString(), cellValue, ref writer, 0);
                    }
                }

                writer.WriteEndElement(); //  End of Row
            }

            writer.WriteEndElement(); //  End of SheetData
            writer.WriteEndElement(); //  End of worksheet

            writer.Close();
        }

        #endregion


    }
}