﻿using OHES.eFit.ActionFilters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit.Controllers
{
    [Authorize]
    public class HomeMenuController : Controller
    {
        //
        // GET: /HomeMenu/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult homeIndex()
        {
            return View();
        }
	}
}