﻿using OHES.eFit.Data.Repository;
using OHES.eFit.OpenXML;
using OHES.eFit.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OHES.eFit.Data.Utility;
using OHES.eFit.App_Start;

namespace OHES.eFit.Controllers
{
    [Authorize]
    [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
    public class CertifiedTrainersController : Controller
    {
         ICertifiedTrainersRepository _CertifiedTrainersRepository;

         public CertifiedTrainersController()
         {
             _CertifiedTrainersRepository = new CertifiedTrainersRepository();
         }
        
        // GET: CertifiedTrainers
        public ActionResult Index()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1,2,3,4")]
        public ActionResult Active()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1,2,3,4")]
        public ActionResult DueForRenewal()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1,2,3,4")]
        public ActionResult Expired()
        {
            return View();
        }

        public ActionResult ExportCertifiedActiveTrainers()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var CompanyName = Request["CompanyName"].ToString().Trim();
                var disName = Request["disName"].ToString().Trim(); 
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (disName == "undefined")
                { disName = ""; }
                else { disName = Request["disName"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                else { }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CertifiedTrainersRepository.ExportActiveTrainers(CompanyName,disName, TrainingDate, searchText, companyTypeId, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                if (companyTypeId == 3)
                {
                    datatab.Columns.Remove("RefNo");
                    datatab.Columns.Remove("TrainerPicFileId");
                    datatab.Columns[0].ColumnName = "Training Date";
                    datatab.Columns[1].ColumnName = "Company Name";
                    datatab.Columns[2].ColumnName = "Certified Trainer";
                    datatab.Columns[3].ColumnName = "No Of Years";
                    datatab.Columns[4].ColumnName = "3M Trainer";
                    datatab.Columns["IC"].ColumnName = "ID No.";
                    datatab.Columns["Model"].ColumnName = "Model";
                    datatab.Columns["ContactPerson"].ColumnName = "Contact Person";
                    datatab.Columns["ContactNo"].ColumnName = "Contact No";
                }
                else
                {
                    datatab.Columns.Remove("RefNo");
                    datatab.Columns.Remove("TrainerPicFileId");
                    datatab.Columns[0].ColumnName = "Training Date";
                    datatab.Columns[1].ColumnName = "Company Name";
                    datatab.Columns[2].ColumnName = "Certified Trainer";
                    datatab.Columns[3].ColumnName = "No Of Years";
                    datatab.Columns[4].ColumnName = "3M Trainer";
                    datatab.Columns[7].ColumnName = "Dept";
                    datatab.Columns[8].ColumnName = "ID No.";
                    datatab.Columns[9].ColumnName = "Model";
                    datatab.Columns[10].ColumnName = "Contact Person";
                    datatab.Columns[11].ColumnName = "Contact No";
                    datatab.Columns.Remove("TrainerCompanyName");
                }
                
                using (MemoryStream memstr = new MemoryStream())
                {                   

                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "CertifiedActiveTrainerDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "ActiveTrainer";
                    bool isHeader = true;
                    string headerText = "Active Trainers Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }
        public ActionResult ExportCertifiedDueOfRenewalTrainers()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); 
                var CompanyName = Request["CompanyName"].ToString().Trim();
                var disName = Request["disName"].ToString().Trim(); 
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (disName == "undefined")
                { disName = ""; }
                else { disName = Request["disName"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CertifiedTrainersRepository.ExportDueOfRenewalTrainers(CompanyName, disName,TrainingDate, searchText, companyTypeId, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                if (companyTypeId == 3)
                {
                    datatab.Columns.Remove("RefNo");
                    datatab.Columns.Remove("TrainerPicFileId");
                    datatab.Columns[0].ColumnName = "Training Date";
                    datatab.Columns[1].ColumnName = "Company Name";
                    datatab.Columns[2].ColumnName = "Certified Trainer";
                    datatab.Columns[3].ColumnName = "No Of Years";
                    datatab.Columns[4].ColumnName = "3M Trainer";
                    datatab.Columns["IC"].ColumnName = "ID No.";
                    datatab.Columns["Model"].ColumnName = "Model";
                    datatab.Columns["ContactPerson"].ColumnName = "Contact Person";
                    datatab.Columns["ContactNo"].ColumnName = "Contact No";
                }
                else
                {
                    datatab.Columns.Remove("RefNo");
                    datatab.Columns.Remove("TrainerPicFileId");
                    datatab.Columns[0].ColumnName = "Training Date";
                    datatab.Columns[1].ColumnName = "Company Name";
                    datatab.Columns[2].ColumnName = "Certified Trainer";
                    datatab.Columns[3].ColumnName = "No Of Years";
                    datatab.Columns[4].ColumnName = "3M Trainer";
                    datatab.Columns[7].ColumnName = "Dept";
                    datatab.Columns[8].ColumnName = "ID No.";
                    datatab.Columns[9].ColumnName = "Model";
                    datatab.Columns[10].ColumnName = "Contact Person";
                    datatab.Columns[11].ColumnName = "Contact No";
                    datatab.Columns.Remove("TrainerCompanyName");
                }
               
                using (MemoryStream memstr = new MemoryStream())
                {                  

                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "CertifiedDueOfRenewalTrainerDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "DueOfRenewalTrainer";
                    bool isHeader = true;
                    string headerText = "Due For Renewal Trainers Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }
        public ActionResult ExportCertifiedExpiredTrainers()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); 
                var CompanyName = Request["CompanyName"].ToString().Trim();
                var disName = Request["disName"].ToString().Trim(); 
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (disName == "undefined")
                { disName = ""; }
                else { disName = Request["disName"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CertifiedTrainersRepository.ExportExpiredTrainers(CompanyName, disName,TrainingDate, searchText, companyTypeId, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                if (companyTypeId == 3)
                {
                    datatab.Columns.Remove("RefNo");
                    datatab.Columns.Remove("TrainerPicFileId");
                    datatab.Columns[0].ColumnName = "Training Date";
                    datatab.Columns[1].ColumnName = "Company Name";
                    datatab.Columns[2].ColumnName = "Certified Trainer";
                    datatab.Columns[3].ColumnName = "No Of Years";
                    datatab.Columns[4].ColumnName = "3M Trainer";
                    datatab.Columns["IC"].ColumnName = "ID No.";
                    datatab.Columns["Model"].ColumnName = "Model";
                    datatab.Columns["ContactPerson"].ColumnName = "Contact Person";
                    datatab.Columns["ContactNo"].ColumnName = "Contact No";
                }
                else
                {
                    datatab.Columns.Remove("RefNo");
                    datatab.Columns.Remove("TrainerPicFileId");
                    datatab.Columns[0].ColumnName = "Training Date";
                    datatab.Columns[1].ColumnName = "Company Name";
                    datatab.Columns[2].ColumnName = "Certified Trainer";
                    datatab.Columns[3].ColumnName = "No Of Years";
                    datatab.Columns[4].ColumnName = "3M Trainer";
                    datatab.Columns[7].ColumnName = "Dept";
                    datatab.Columns[8].ColumnName = "ID No.";
                    datatab.Columns[9].ColumnName = "Model";
                    datatab.Columns[10].ColumnName = "Contact Person";
                    datatab.Columns[11].ColumnName = "Contact No";
                    datatab.Columns.Remove("TrainerCompanyName");
                }

                using (MemoryStream memstr = new MemoryStream())
                {                 

                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "CertifiedExpiredTrainerDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "ExpiredTrainer";
                    bool isHeader = true;
                    string headerText = "Expired Trainers Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }
	}
}