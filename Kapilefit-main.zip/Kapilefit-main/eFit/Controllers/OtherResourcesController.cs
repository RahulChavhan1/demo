﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit.Controllers
{
    [Authorize]
    public class OtherResourcesController : Controller
    {
        //
        // GET: /OtherResources/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult RelatedLinks()
        {
            return View();
        }
	}
}