﻿using OHES.eFit.ActionFilters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit.Controllers
{
    [ReAuthorizeFilter]
    public class GeneralController : Controller
    {
        //
        // GET: /General/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ContactUs()
        {
            return View();
        }
        public ActionResult FAQ()
        {
            return View();
        }
	}
}