﻿using OHES.eFit.Data.DataModel;
using OHES.eFit.Data.Repository;
using OHES.eFit.Data.Utility;
using OHES.eFit.OpenXML;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using OHES.eFit.App_Start;

namespace OHES.eFit.Controllers
{
    [Authorize]
    [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
    public class eFitToolAdminController : Controller
    {
        
        IeFitToolAdminRepository _eFitToolAdminRepository;

        public eFitToolAdminController()
        {
            _eFitToolAdminRepository = new eFitToolAdminRepository();
        }
        //
        // GET: /eFitToolAdmin/
        public ActionResult Index()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1")]
        public ActionResult UploadForm()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1")]
        public ActionResult UploadStatusCheck()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1")]
        public ActionResult TrainersRecordSummary()
        {
            return View();
        }

        public ActionResult UploadTrainerPhoto()
        {
            return View();
        }

        public ActionResult DeleteTrainerPhoto()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1")]
        public ActionResult QuickLinks()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1")]
        public ActionResult AddQuickLinks()
        {
            return View();
        }

        public ActionResult QuickLinksList()
        {
            return View();
        }
        
        public ActionResult adminLanding()
        {
            return View();
        }


        public ActionResult RetrieveImage(Guid fileId)
        {
            try
            {
                byte[] cover = _eFitToolAdminRepository.GetImageFromDataBase(fileId);
                if (cover != null)
                {
                    return File(cover, "image/jpg");
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
                return null;
            }
        }

        [AllowAnonymous]
        public FileContentResult RetrieveImageCertificate()
        {
            string fileid = Request["fileId"];
            Guid fileID = new Guid(fileid);
            byte[] cover = _eFitToolAdminRepository.GetImageFromDataBase(fileID);
            if (cover != null)
            {
                return File(cover, "image/jpg");
            }
            else
            {
                return null;
            }

        }


        #region Import

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult ImportUploadShipments(HttpPostedFileBase uploadedFile)
        {
            string msg = "";          
            ActionStatus statusLog = new ActionStatus();
            try
            {
                if (uploadedFile != null)
                {
                    List<TrainingAttendanceVM> UploadShipments = new List<TrainingAttendanceVM>();
                    JavascriptModel jsmodel = new JavascriptModel();
                    if (uploadedFile.ContentLength > 0)
                    {
                        List<TrainingAttendanceVM> status1 = new List<TrainingAttendanceVM>();
                        bool status = true;

                        string sConnectionString = "";
                        string sFileName = uploadedFile.FileName.Split("\\".ToCharArray()).Last();
                        string[] fileRename = sFileName.Split('.');
                        //sFileName = fileRename[0] + "." + fileRename[1];
                        string filePath = Path.Combine(HttpContext.Server.MapPath("../Uploads"), Path.GetFileName(sFileName));
                        uploadedFile.SaveAs(filePath);
                        DataSet ds = new DataSet();

                        //Validating File
                        if (fileRename[1] != "xls" && fileRename[1] != "xlsx")
                        {
                            msg = "Invalid";
                            return Content(new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(
                           new
                           {
                               status1 = "",
                               msg = msg,
                           }
                           ));
                        }
                        #region Connection String
                        if (sFileName.EndsWith("xls"))
                        {
                            sConnectionString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("../Uploads/") + sFileName + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";");
                        }
                        else if (sFileName.EndsWith("xlsx"))
                        {

                            sConnectionString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Server.MapPath("../Uploads/") + sFileName + ";Extended Properties=\"Excel 12.0;HDR=Yes\";");
                        }

                        #endregion

                        //LogError.AppLog("con string : " + sConnectionString);
                        try
                        {
                            using (OleDbConnection conn = new System.Data.OleDb.OleDbConnection(sConnectionString))
                            {

                                conn.Open();
                                using (DataTable dtExcelSchema = conn.GetSchema("Tables"))
                                {
                                    string sheetName = "";

                                    if (sFileName.EndsWith("xls"))
                                    {
                                        sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                                    }
                                    else if (sFileName.EndsWith("xlsx"))
                                    {
                                        int rowCount = dtExcelSchema.Rows.Count;
                                        int index = rowCount - 1;
                                        sheetName = dtExcelSchema.Rows[index]["TABLE_NAME"].ToString();
                                    }

                                    string query = "SELECT * FROM [" + sheetName + "]";
                                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                                    adapter.Fill(ds, "UploadShipments");
                                    #region Adding Datarow
                                    if (ds.Tables.Count > 0)
                                    {
                                        IEnumerable<DataRow> newRows = ds.Tables[0].AsEnumerable().Skip(18);
                                        DataTable dt = newRows.CopyToDataTable();

                                        ////Validating Template
                                        //if (dt.Columns[0].ColumnName == "Type of Training")
                                        //{

                                        //}
                                        //else
                                        //{
                                        //    msg = "InvalidTem";
                                        //    return Content(new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(
                                        //   new
                                        //   {
                                        //       status1 = "",
                                        //       msg = msg,
                                        //   }
                                        //   ));
                                        //}

                                        dt.Columns[0].ColumnName = "Name of Trainee";
                                        dt.Columns[1].ColumnName = "Designation";
                                        dt.Columns[2].ColumnName = "Dept";
                                        dt.Columns[3].ColumnName = "ID No";
                                        dt.Columns[4].ColumnName = "Model";
                                        dt.Columns[5].ColumnName = "Outcome";
                                        dt.Columns[6].ColumnName = "Signature";


                                        if (dt.Rows.Count > 0)
                                        {
                                            DataTable exportList = dt;
                                            int y = 1;
                                            foreach (DataRow drow in exportList.Rows)
                                            {
                                                TrainingAttendanceVM uploadTrinee = new TrainingAttendanceVM();
                                                try
                                                {
                                                    if (y > 0)
                                                    {

                                                        string nameOfTrainee = getSafeValue(drow["Name of Trainee"].ToString(), 50);
                                                        string designation = getSafeValue(drow["Designation"].ToString(), 50);
                                                        string dept = getSafeValue(drow["Dept"].ToString(), 50);
                                                        string IDNo = getSafeValue(drow["ID No"].ToString(), 50);
                                                        string model = getSafeValue(drow["Model"].ToString(), 50);//
                                                        string outcome = getSafeValue(drow["Outcome"].ToString(), 50);//;
                                                        string Signature = getSafeValue(drow["Signature"].ToString(), 50);//;

                                                        uploadTrinee.dept = dept;
                                                        uploadTrinee.designation = designation;
                                                        uploadTrinee.IDNo = IDNo;
                                                        uploadTrinee.model = model;
                                                        uploadTrinee.nameOfTrainee = nameOfTrainee;
                                                        uploadTrinee.outcome = outcome;
                                                    }
                                                    y++;

                                                }

                                                catch (Exception ex)
                                                {
                                                    Utility.LogException(ex);
                                                }
                                                if (uploadTrinee.nameOfTrainee != "")
                                                {
                                                    UploadShipments.Add(uploadTrinee);
                                                }
                                            }
                                            if (UploadShipments.Count > 0 && status)
                                            {
                                                status1 = UploadShipments;
                                            }
                                            else if (status)
                                            {
                                                status = false;
                                                msg = "Empty File";
                                            }

                                        }
                                    #endregion

                                    }

                                }


                            }


                            //return Content(status1, "application/json");
                            return Content(new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(
                            new
                            {
                                status1 = UploadShipments,
                                msg = "success",
                                fileN = fileRename[0]
                            }
                            ));
                        }
                        catch (Exception ex)
                        {

                            Utility.LogException(ex);
                            //return Content("dfdsf", "application/json");
                            return Content(new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(
                             new
                             {
                                 status1 = "",
                                 msg = "Invalid",
                             }));
                        }


                    }
                    return null;
                }
                else
                {
                    msg = "NoFile";
                    return Content(new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(
                           new
                           {
                               status1 = "",
                               msg = msg,
                           }
                           ));
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
                //return Content("dfdsf", "application/json");
                return Content(new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(
                             new
                             {
                                 status1 = "",
                                 msg = "Invalid",
                             }));
            }
        }

       

        private string getSafeValue(string data, int len)
        {
            if (!string.IsNullOrEmpty(data))
            {
                return data.Trim().Length > len ? data.Trim().Substring(0, len) : data.Trim();
            }
            return string.Empty;
        }

        #endregion

        public ActionResult ExportLinksSummary()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _eFitToolAdminRepository.ExportLinksSummary(searchText, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("SNo");
                using (MemoryStream memstr = new MemoryStream())
                {
                   
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "QuickLinkSummaryDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "QuickLinkSummary";
                    bool isHeader = true;
                    string headerText = "Quick Links Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }


    }



}