﻿using OHES.eFit.Data.Repository;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Security;
using OHES.eFit.Data.DataModel;
using FormsAuthenticationExtensions;

namespace OHES.eFit.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/
        LoginRepository _LoginRepository = new LoginRepository();
        
        public ActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult doAuthorize()
        {
           
            bool status = false;
            string returtoUrl = "";
           // string userId = "a3bt7zz"; //User.Identity.Name;
            string userId = "A6HNDZZ";
            string[] userArr = userId.Split('\\');
            if (userArr.Length == 2)
            {
                userId = userArr[1];
            }
            if (string.IsNullOrEmpty(userId))
            {
                userId = Session["UserId"] == null ? "" : Session["UserId"].ToString();
            }           
            if (string.IsNullOrEmpty(userId))
            {
                status = false;
                returtoUrl = "Login/accessdenied";//WebConfigurationManager.AppSettings["vsrmUrl"].ToString();
            }

            else
            {
                returtoUrl = Request.Params["returnURL"];               
                if (string.IsNullOrEmpty(returtoUrl))
                {
                    returtoUrl = "#/homemenu/HomeOption/General";
                }

                User LoginVM = _LoginRepository.getAuthorization(userId);
                if (!string.IsNullOrEmpty(LoginVM.UserID))
                {
                    Session["UserId"] = userId;
                    Dictionary<string, string> ticketData = new Dictionary<string, string>
                    {
                        {"LoginName",LoginVM.UserName},
                        {"LoginID",LoginVM.UserID},
                        {"LoginTypeID",LoginVM.companyTypeId.ToString()},
                        {"RoleID",LoginVM.RoleID.ToString()},
                        {"UserCompanyName",LoginVM.CompanyName},
                        {"CompanyID",LoginVM.CompanyID.ToString()}
                    };
                    Session["ticketData"] = ticketData;
                    Session["RoleID"] = LoginVM.RoleID.ToString();                 
                    status = true;                    
                }
                else
                {
                   
                    status = true;
                    returtoUrl = "Login/accessdenied";
                }

            }
            return Json(new { success = status, returnUrl = returtoUrl }, JsonRequestBehavior.AllowGet);
        }

        [AllowAnonymous]
        public ActionResult accessDenied()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult unauthorize()
        {
            return View();
        }

        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
        public ActionResult LogOut(string id)
        {
            FormsAuthentication.SignOut();
            Session.Clear();

            return Json(new LogoutStatus { Message = "LogedOut" }, JsonRequestBehavior.AllowGet);
        }
	}
}