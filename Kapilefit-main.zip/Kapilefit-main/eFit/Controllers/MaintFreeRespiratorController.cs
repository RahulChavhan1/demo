﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit.Controllers
{
    [Authorize]
    public class MaintFreeRespiratorController : Controller
    {
        //
        // GET: /MaintFreeRespirator/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Series8000()
        {
            return View();
        }

        public ActionResult FittingInstructions()
        {
            return View();
        }

        public ActionResult PoweredSupplies()
        {
            return View();
        }
	}
}