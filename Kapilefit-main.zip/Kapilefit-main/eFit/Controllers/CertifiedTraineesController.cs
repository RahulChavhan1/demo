﻿using OHES.eFit.Data.Repository;
using OHES.eFit.OpenXML;
using OHES.eFit.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OHES.eFit.Data.Utility;
using System.Web.Configuration;


namespace OHES.eFit.Controllers
{
    [Authorize]
    [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
    public class CertifiedTraineesController : Controller
    {
        string ServerURL = WebConfigurationManager.AppSettings["baseURL"];

         ICertifiedTraineesRepository _CertifiedTraineesRepository;
         public CertifiedTraineesController()
        {
            _CertifiedTraineesRepository = new CertifiedTraineesRepository();
        }


        //
        // GET: /CertifiedTrainees/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Active()
        {
            return View();
        }

        public ActionResult DueForRenewal()
        {
            return View();
        }

        public ActionResult Expired()
        {
            return View();
        }

        public ActionResult ExportCertifiedActiveTrainees()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var CompanyName = Request["CompanyName"].ToString().Trim();
                var disName = Request["disName"].ToString().Trim(); 
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }

                if (disName == "undefined")
                { disName = ""; }
                else { disName = Request["disName"].ToString().Trim(); }

                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                else { TrainingDate = Request["TrainingDate"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CertifiedTraineesRepository.ExportActiveTrainees(CompanyName, disName, TrainingDate, searchText, companyTypeId, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                //datatab.Columns.Remove("TrainerPicFileId");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "No Of Years";
                datatab.Columns[3].ColumnName = "Trainee Name";
                datatab.Columns[6].ColumnName = "ID No.";
                datatab.Columns[7].ColumnName = "Model";
                datatab.Columns[8].ColumnName = "Contact Person";
                datatab.Columns[9].ColumnName = "Contact No";
                datatab.Columns[10].ColumnName = "Trainer Name";
                using (MemoryStream memstr = new MemoryStream())
                {                  

                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "CertifiedActiveTraineeDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "ActiveTrainee";
                    bool isHeader = true;
                    string headerText = "Active Trainees Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {

                Utility.LogException(ex);
            }
            return View();
        }

        public ActionResult ExportCertifiedDueOfRenewalTrainees()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var CompanyName = Request["CompanyName"].ToString().Trim();
                var disName = Request["disName"].ToString().Trim(); 
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (disName == "undefined")
                { disName = ""; }
                else { disName = Request["disName"].ToString().Trim(); }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                else { TrainingDate = Request["TrainingDate"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CertifiedTraineesRepository.ExportDueOfRenewalTrainees(CompanyName, disName, TrainingDate, searchText, companyTypeId, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                //datatab.Columns.Remove("TrainerPicFileId");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "No Of Years";
                datatab.Columns[3].ColumnName = "Trainee Name";
                datatab.Columns[6].ColumnName = "ID No.";
                datatab.Columns[7].ColumnName = "Model";
                datatab.Columns[8].ColumnName = "Contact Person";
                datatab.Columns[9].ColumnName = "Contact No";
                datatab.Columns[10].ColumnName = "Trainer Name";
                
                using (MemoryStream memstr = new MemoryStream())
                {
                 
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "CertifiedDueOfRenewalTraineeDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "DueOfRenewalTrainee";
                    bool isHeader = true;
                    string headerText = "Due For Renewal Trainees Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }
        public ActionResult ExportCertifiedExpiredTrainees()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var CompanyName = Request["CompanyName"].ToString().Trim();
                var disName = Request["disName"].ToString().Trim(); 
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (disName == "undefined")
                { disName = ""; }
                else { disName = Request["disName"].ToString().Trim(); }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                else { TrainingDate = Request["TrainingDate"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CertifiedTraineesRepository.ExportExpiredTrainees(CompanyName, disName, TrainingDate, searchText, companyTypeId, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                //datatab.Columns.Remove("TrainerPicFileId");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "No Of Years";
                datatab.Columns[3].ColumnName = "Trainee Name";
                datatab.Columns[6].ColumnName = "ID No.";
                datatab.Columns[7].ColumnName = "Model";
                datatab.Columns[8].ColumnName = "Contact Person";
                datatab.Columns[9].ColumnName = "Contact No";
                datatab.Columns[10].ColumnName = "Trainer Name";
               
                using (MemoryStream memstr = new MemoryStream())
                {
                  

                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "CertifiedExpiredTraineeDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "ExpiredTrainee";
                    bool isHeader = true;
                    string headerText = "Expired Trainees Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            } 
            catch (Exception ex)
            {

                Utility.LogException(ex);
            }
            return View();
        }

        [AllowAnonymous]
        public ActionResult PrintByAppendTrainees(Nullable<Guid> GuidId)
        {
            ActionStatus saveResult = new ActionStatus();

            string url = ServerURL + "PrintCertificate/CertificateToPrintTrainees?GuidId=" + GuidId;

           

            var pdfBuffer = PFDGenerator.GetPDFFromURL(url, null, 0, "", 20, "A4", "portrait", true, false, false);

            Response.Clear();
            MemoryStream ms = new MemoryStream(pdfBuffer);
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "inline;filename=" + "PrintCertificate" + ".pdf");
            Response.Buffer = true;
            ms.WriteTo(Response.OutputStream);
            Response.End();

            return new FileStreamResult(ms, "application/pdf");
        }

        [AllowAnonymous]
        public ActionResult PrintByAppendTrainers(Nullable<Guid> GuidId)
        {
            ActionStatus saveResult = new ActionStatus();

            string url = ServerURL + "PrintCertificate/CertificateToPrintTrainers?GuidId=" + GuidId;   
            var pdfBuffer = PFDGenerator.GetPDFFromURL(url, null, 0, "", 20, "A4", "portrait", true, false, false);
            Response.Clear();
            MemoryStream ms = new MemoryStream(pdfBuffer);
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "inline;filename=" + "PrintCertificate" + ".pdf");
            Response.Buffer = true;
            ms.WriteTo(Response.OutputStream);
            Response.End();

            return new FileStreamResult(ms, "application/pdf");
        }
        
	}
}