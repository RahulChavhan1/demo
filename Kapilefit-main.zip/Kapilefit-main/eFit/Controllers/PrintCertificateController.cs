﻿using OHES.eFit.Data.Repository;
using OHES.eFit.OpenXML;
using OHES.eFit.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Configuration;
using OHES.eFit.Data.Utility;

using System.Xml;

using System.Text;


namespace OHES.eFit.Controllers
{
    public class PrintCertificateController : Controller
    {
        string ServerURL = WebConfigurationManager.AppSettings["baseURL"];

        ICertifiedTraineesRepository _CertifiedTraineesRepository;
        IeFitToolAdminRepository _eFitToolAdminRepository;


        public PrintCertificateController()
        {
            _CertifiedTraineesRepository = new CertifiedTraineesRepository();
            _eFitToolAdminRepository = new eFitToolAdminRepository();
        }

        // GET: /PrintCertificate/
        //Trainees Certificate
        [AllowAnonymous]
        public ActionResult CertificateToPrintTrainees(Nullable<Guid> GuidId)
        {

            ViewBag.CertificateToPrint = CerificateToConvertPDFTrainees(GuidId);
            return View();
        }
        [AllowAnonymous]
        public string CerificateToConvertPDFTrainees(Nullable<Guid> GuidId)
        {
            string typeOfCer = string.Empty;
            StringBuilder HTMLGen = new StringBuilder();
            StringBuilder HTML_Header = new StringBuilder();

            try
            {
                List<TempPrint> data = new List<TempPrint>();
                if (GuidId != null)
                {
                    data = _CertifiedTraineesRepository.getPrintDetails(GuidId);
                }
                int i = 0;
                int j = data.Count();
                foreach (var item in data)
                {
                    //String[] datas = item.PrintData.Split('+');
                    
                    
                    //if (datas.Count() > 0)
                    //{
                        //foreach (var items in datas)
                        //{
                            i++;
                            if (item.PrintData != "")
                            {
                                String[] datasItems = item.PrintData.Split('|');
                                var RefNo = datasItems[0];
                                var TraineeName = datasItems[1];
                                var CompanyName = datasItems[2];
                                var IC = datasItems[3];
                                var date = datasItems[4];
                                var model = datasItems[5];                               

                                HTMLGen.Append("<div style='width:1000px;margin:0px auto;FONT-FAMILY: Verdana;COLOR: #373c43;'>");//1
                                HTMLGen.Append("<div style='margin-top:150px;'>");//1-1
                                HTMLGen.Append("<img style='margin-left:10px;width: 65px;padding: 0px;border-radius: 0px;position: inherit;transform: none;' src='" + ServerURL + "Content/images/3M_Logo.png'/>");
                                HTMLGen.Append("<span style='font-size: 30px; font-weight: bold;margin-top:20px;display:block;'>Respirator Fit Test Certificate</span>");
                                HTMLGen.Append("</div>");//1-1
                                HTMLGen.Append("<div style='background:#dfdfdf; padding: 10px 50px 1px 50px; margin-top: 50px;'>");//2
                                HTMLGen.Append("<span style='font-size: 30px;'>This is to certify that</span>");
                                HTMLGen.Append("<ul style='list-style:none;margin-left:-40px;margin-top:80px;FONT-FAMILY: Verdana;'>");
                                HTMLGen.Append("<li style='font-size: 20px; font-weight: bold;font-family:Verdana;border-bottom: 1px ridge #ff3366; margin: 5px 0px; padding-bottom: 3px'>" + TraineeName + "</li>");
                                HTMLGen.Append("<li style='font-size: 20px; font-weight: bold;font-family:Verdana;border-bottom: 1px ridge #ff3366; margin: 5px 0px; padding-bottom: 3px'>ID No. : " + IC + "</li>");
                                HTMLGen.Append("<li style='font-size: 20px; font-weight: bold;font-family:Verdana;border-bottom: 1px ridge #ff3366; margin: 5px 0px; padding-bottom: 3px'>Company : " + CompanyName + "</li>");
                                HTMLGen.Append("</ul>");
                                HTMLGen.Append("<p style='font-size: 23px;FONT-FAMILY: Verdana; margin: 28px 0px'>has been trained on the proper Use, case Limitations and Maintenance of 3M brand Respirator(s)</p>");
                                HTMLGen.Append("<ul style='font-size: 23px;list-style:none;margin-left:-40px;FONT-FAMILY: Verdana;line-height:40px;'>");
                                HTMLGen.Append("<li style='display:block;margin:40px 0px;'><input style='float:left;margin-right:15px;margin-top:15px;' checked='checked' disabled='disabled' type='checkbox'/><p style='padding-left:15px'>has passed a 3M FT-10/FT-30 Qualitative Fit Test using the following 3M brand/model Respirator(s):<span style='font-weight:bold;border-bottom: 1px ridge #ff3366;width: 565px;float:right;font-size:24px;height:30px;'>" + model + "</span></p></li>");
                                HTMLGen.Append("<li style='display:block;margin:40px 0px;'><input style='float:left;margin-right:15px;margin-top:15px;' disabled='disabled' type='checkbox'/><p>could not be Fit Tested due to:<span style='width: 505px;height:30px; float: right;border-bottom: 1px ridge #ff3366'></span></p></li>");
                                HTMLGen.Append("<li style='display:block;margin:40px 0px;'><input style='float:left;margin-right:15px;margin-top:15px;' disabled='disabled' type='checkbox'/><p>other Personal Protective Equipment (PPE) worn during Fit Test<span style='float:left;border-bottom: 1px ridge #ff3366;float:right;width: 96%;height:30px;'></span></p></li>");
                                HTMLGen.Append("<li style='display:block;margin-top:60px;'><input style='float:left;margin-right:15px;margin-top:15px;' disabled='disabled' type='checkbox'/><p>comments<span style='width: 735px;height:30px; float: right;border-bottom: 1px ridge #ff3366;'></span></p></li>");
                                HTMLGen.Append("</ul>");
                                HTMLGen.Append("<div style='width: 100%; margin-bottom: 10px; margin-top: 235px;'>");//3
                                HTMLGen.Append("<div style='margin-top:15px;'>");//3-1
                                HTMLGen.Append("<div style='border-bottom: 1px ridge #ff3366;width: 460px;'></div>");//3-1-1
                                HTMLGen.Append("<span style='font-size:12px;margin-top:5px;display:block;'>This is a computer generated document. No signature is required</span>");
                                HTMLGen.Append("</div>");//3-1
                                HTMLGen.Append("<div style='float: right;margin-top: -45px;'>");//3-2
                                HTMLGen.Append("<span style='font-size: 20px;FONT-FAMILY: Verdana;font-weight: bold;border-bottom: 1px ridge #ff3366;padding-right: 15px;'>" + date + "</span>");
                                HTMLGen.Append("<span style='display: block;font-size: 16px;margin-top: 5px;'>Training Date</span>");
                                HTMLGen.Append("</div>");//3-2
                                HTMLGen.Append("</div>");//3
                                HTMLGen.Append("<div style='margin-top:10px;'>");//4
                                HTMLGen.Append("<span style='font-size: 16px;'>3M Personal Safety Division</span>");
                                HTMLGen.Append("<p style='font-size: 14px; margin-top: 25px;'>This certificate is valid for one (1) year from the date of training, applicable to 3M brand Respirators only</p>");
                                HTMLGen.Append("</div>");//4
                                HTMLGen.Append("</div>");//2
                                HTMLGen.Append("</div>");//1

                                if (i < j)
                                {
                                    HTMLGen.Append("<div style='page-break-after: always'></div>");
                                }
                            }
                        //}
                    //}



                }

            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return HTMLGen.ToString(); // Json(new { aaData = HTMLGen.ToString() }, JsonRequestBehavior.AllowGet);
        }


        //Trainers Certificate
        [AllowAnonymous]
        public ActionResult CertificateToPrintTrainers(Nullable<Guid> GuidId)
        {

            ViewBag.CertificateToPrint = CerificateToConvertPDFTrainers(GuidId);
            return View();
        }

        [AllowAnonymous]
        public string CerificateToConvertPDFTrainers(Nullable<Guid> GuidId)
        {
            string typeOfCer = string.Empty;
            StringBuilder HTMLGen = new StringBuilder();
            StringBuilder HTML_Header = new StringBuilder();

            try {
                List<TempPrint> data = new List<TempPrint>();
                if (GuidId != null)
                {
                    data = _CertifiedTraineesRepository.getPrintDetails(GuidId);
                }
                int i = 0;
                int j = data.Count();
                
                //foreach (var item in data)
                //{
                //    String[] datas = item.PrintData.Split('+');
                   
                //    if (datas.Count() > 0)
                //    {
                        foreach (var item in data)
                        {
                            i++;
                            if (item.PrintData != "")
                            {
                                String[] datasItems = item.PrintData.Split('|');
                                var RefNo = datasItems[0];
                                var TraineeName = datasItems[1];
                                var CompanyName = datasItems[2];
                                //var IC = datasItems[3];
                                var date = datasItems[4];
                                var fileId = datasItems[5];

                                HTMLGen.Append("<div style='width:1000px;margin:0px auto;FONT-FAMILY: Verdana;'>");//1
                                HTMLGen.Append("<div style='margin-top:150px;'>");//1-1
                                HTMLGen.Append("<img style='margin-left:10px;width: 65px;padding: 0px;border-radius: 0px;position: inherit;transform: none;' src='" + ServerURL + "Content/images/3M_Logo.png'/>");
                                HTMLGen.Append("<span style='font-size: 30px; font-weight: bold;margin-top:20px;display:block'>Respirator Fit Test Trainer Certificate</span>");
                                if (fileId != "")
                                {
                                    HTMLGen.Append("<div style='width:100px;height:100px;float:right;margin-top:70px;margin-right:20px;'><img style='width:100px;height:100px;' src='" + ServerURL + "eFitToolAdmin/RetrieveImageCertificate?fileId=" + fileId + "'/></div>");
                                }
                                HTMLGen.Append("</div>");//1-1
                                HTMLGen.Append("<div style='background:#dcdcdc; padding: 10px 55px; margin-top: 50px;'>");//2
                                HTMLGen.Append("<span style='font-size: 30px;'>This is to certify that</span>");                                

                                HTMLGen.Append("<ul style='list-style:none;margin-left:-40px;margin-top:110px;'>");
                                HTMLGen.Append("<li style='font-size: 20px; font-weight: bold;font-family:Verdana; margin: 5px 0px; padding-bottom: 3px'><span style='margin-right:45px'>Name</span>:<span style='width:760px;border-bottom: 1px ridge #ff3344;display:inline-block;padding-left:5px;'>" + TraineeName + "</span></li>");
                                HTMLGen.Append("<li style='font-size: 20px; font-weight: bold;font-family:Verdana; margin: 60px 0px; padding-bottom: 3px'>Company :<span style='width:760px;border-bottom: 1px ridge #ff3344;display:inline-block;padding-left:5px;'> " + CompanyName + "</span></li></ul>");
                                HTMLGen.Append("<p style='font-size: 24px;FONT-FAMILY: Verdana; margin-top: 45px'>has been trained on the proper protocol to be followed when Fit Testing 3M Brand Respirators using 3M Qualitative Fit Test Apparatus (bitter or sweet solution).</p>");
                                HTMLGen.Append("<div style='width: 100%; margin-bottom: 10px; margin-top: 235px;'>");//3
                                HTMLGen.Append("<div style='margin-top:15px;'>");//3-1
                                HTMLGen.Append("<div style='border-bottom: 1px ridge #ff3344;width: 460px;'></div>");//3-1-1
                                HTMLGen.Append("<span style='font-size:12px;margin-top:5px;display:block;'>This is a computer generated document. No signature is required</span>");
                                HTMLGen.Append("</div>");//3-1
                                HTMLGen.Append("<div style='float: right;margin-top: -45px;'>");//3-2
                                HTMLGen.Append("<span style='font-size: 20px;FONT-FAMILY: Verdana;font-weight: bold;border-bottom: 1px ridge #ff3344;padding-right: 15px;'>" + date + "</span>");
                                HTMLGen.Append("<span style='display: block;font-size: 18px;margin-top: 5px;'>Training Date</span>");
                                HTMLGen.Append("</div>");//3-2
                                HTMLGen.Append("</div>");//3
                                HTMLGen.Append("<div style='padding-bottom:5px;margin-top:10px;'>");//4
                                HTMLGen.Append("<span style='font-size: 16px;'>3M Personal Safety Division</span>");
                                HTMLGen.Append("<p style='font-size: 14px; margin-top: 25px;'>This certificate is valid for one (1) year from training date applicable to 3M brand Respirators only. Renewal is subject to 3M approval</p>");
                                HTMLGen.Append("</div>");//4
                                HTMLGen.Append("</div>");//2
                                HTMLGen.Append("</div>");//1

                                if (i < j)
                                {
                                    HTMLGen.Append("<div style='page-break-after: always'></div>");
                                }

                            }
                        }
                    //}



                //}

                

            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return HTMLGen.ToString(); // Json(new { aaData = HTMLGen.ToString() }, JsonRequestBehavior.AllowGet);

        }


	}
}