﻿using OHES.eFit.ActionFilters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit.Controllers
{
    [Authorize]
    public class HomeOptionController : Controller
    {
        //
        // GET: /HomeOption/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult General()
        {
        
          return View();
        }

        public ActionResult RespiratoryProtection()
        {
            return View();
        }
        public ActionResult TechUpdates()
        {
            return View();
        }
        public ActionResult NewProductsIntro()
        {
            return View();
        }
	}
}