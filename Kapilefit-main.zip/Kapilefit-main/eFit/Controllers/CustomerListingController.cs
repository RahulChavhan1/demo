﻿using OHES.eFit.Data.Repository;
using OHES.eFit.OpenXML;
using OHES.eFit.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OHES.eFit.Data.Utility;
using FormsAuthenticationExtensions;
using System.Web.Security;
using OHES.eFit.App_Start;

namespace OHES.eFit.Controllers
{
    [Authorize]
    [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
    public class CustomerListingController : Controller
    {

        ICustomerListingRepository _CustomerListingRepository;
        public CustomerListingController()
        {
            _CustomerListingRepository = new CustomerListingRepository();
        }
        //
        // GET: /CustomerListing/
        public ActionResult Index()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1,2")]
        public ActionResult Distributors()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1,2,3")]
        public ActionResult GovtCompanies()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1,2,3")]
        public ActionResult PrivateCompanies()
        {
            return View();
        }

        public ActionResult ExportDistributors()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined" || searchText == "null")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CustomerListingRepository.ExportDistributors(searchText, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];

                datatab.Columns.RemoveAt(0);
                datatab.Columns.Remove("DistributorNames");
                datatab.Columns[0].ColumnName = "Distributor Name";
                datatab.Columns[2].ColumnName = "Postal Code";
                datatab.Columns[3].ColumnName = "Contact Person";
                datatab.Columns[5].ColumnName = "Contact No";

                using (MemoryStream memstr = new MemoryStream())
                {                    

                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "DistributorsDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "Distributors";
                    bool isHeader = true;
                    string headerText = "Distributors Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

        public ActionResult ExportCompanies()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim(); 
                string sortColumn = Request["sortColumn"].ToString().Trim(); 
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                Int64 companyId = Convert.ToInt64(Request["companyId"].ToString().Trim());
                if (searchText == "undefined" || searchText == "null")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CustomerListingRepository.ExportCompanies(searchText, tRecords, companyId, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.RemoveAt(0);
                datatab.Columns[0].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Postal Code";
                datatab.Columns[3].ColumnName = "Contact Person";
                datatab.Columns[5].ColumnName = "Contact No";
                datatab.Columns[6].ColumnName = "Distributor Name";
                using (MemoryStream memstr = new MemoryStream())
                {
                
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "CompaniesDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "Companies";
                    bool isHeader = true;
                    string headerText = "Private Company Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
                
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }


        public ActionResult ExportTrainers()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 disId = Convert.ToInt64(Request["disId"].ToString().Trim());
                Int64 adminID = Convert.ToInt64(Request["adminID"].ToString().Trim());

                Int64 tRecords = 0;
                Int64 companyPriId = Convert.ToInt64(Request["companyPriId"].ToString().Trim());
                if (searchText == "undefined" || searchText == "null")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CustomerListingRepository.ExportTrainers(adminID,disId,searchText, tRecords, companyPriId, sortColumn, sortOrder);
                var datatab = data.Tables[0];              
                datatab.Columns.Remove("RefNo");
                datatab.Columns.Remove("CompanyName");
                datatab.Columns.Remove("TrainerCompanyID");
                datatab.Columns.Remove("Address");
                datatab.Columns.Remove("PostalCode");
                datatab.Columns.Remove("ContactPerson");
                datatab.Columns.Remove("Designation");
                datatab.Columns.Remove("ContactNo");
                datatab.Columns.Remove("CompanyID");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "No.Of Trainees";
                datatab.Columns[2].ColumnName = "Training Type";
                datatab.Columns[3].ColumnName = "Trainer Company";
                datatab.Columns[4].ColumnName = "Topics Covered";
                datatab.Columns[5].ColumnName = "Training Company";
                datatab.Columns[6].ColumnName = "Trainer Name";
               
                using (MemoryStream memstr = new MemoryStream())
                {
                 
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TrainersDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "Trainers";
                    bool isHeader = true;
                    string headerText = "Trainers List Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

        public ActionResult ExportTrainees()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();

                string trainingdate = string.Empty;
                string trainerName = string.Empty;
                string companyName = string.Empty;
                Int64 disId = Convert.ToInt64(Request["disId"].ToString().Trim());
                Int64 adminID = Convert.ToInt64(Request["adminID"].ToString().Trim());
                Int64 tRecords = 0;
                Int64 companyPriId = Convert.ToInt64(Request["companyPriId"].ToString().Trim());
                string trainerId = Request["trainerId"].ToString().Trim();
                if (searchText == "undefined" || searchText == "null")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CustomerListingRepository.ExportTrainees(adminID,disId, searchText, tRecords, companyPriId, trainerId, sortColumn, sortOrder);
                var datatab = data.Tables[0];

                //Get Header Values
                int count = 0;
                foreach (DataRow dr in datatab.Rows)
                {
                    
                    if (count == 0)
                    {
                        trainingdate = dr["TrainingDate"] == DBNull.Value ? "" : dr["TrainingDate"].ToString();
                        trainerName = dr["TrainerName"] == DBNull.Value ? "" : dr["TrainerName"].ToString();
                        companyName = dr["CompanyName"] == DBNull.Value ? "" : dr["CompanyName"].ToString();
                        count++;
                    }
                }

                datatab.Columns.RemoveAt(0);
                datatab.Columns.Remove("RefNo");
                datatab.Columns.Remove("CompanyName");
                datatab.Columns.Remove("CompanyType");
                datatab.Columns.Remove("Address");
                datatab.Columns.Remove("PostalCode");
                datatab.Columns.Remove("Cmp_ContactPerson");
                datatab.Columns.Remove("Cmp_Designation");
                datatab.Columns.Remove("Cmp_ContactNo");
                datatab.Columns.Remove("TrainingDate");
                datatab.Columns.Remove("TrainerName");
                datatab.Columns.Remove("TrainerCompany");
                datatab.Columns.Remove("TrainingType");
                datatab.Columns.Remove("TopicsCovered");
                datatab.Columns.Remove("Email");
                datatab.Columns[0].ColumnName = "Trainee Name";
                datatab.Columns[2].ColumnName = "Department";
                datatab.Columns[3].ColumnName = "ID No.";       
                using (MemoryStream memstr = new MemoryStream())
                {
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TraineesDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "Trainees";
                    bool isHeader = true;
                    string headerText = "Trainees List Summary";

                    Dictionary<string, string> objDictionary = new Dictionary<string, string>();
                    objDictionary.Add("Training Date", trainingdate);
                    objDictionary.Add("Trainer Name", trainerName);
                    objDictionary.Add("Company Name", companyName);

                    CreateExcelFile.CreateExcelDocument_ExtraRowsNextToHeader(dt, memstr, sheetName, isHeader, headerText, objDictionary);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }



        public ActionResult ExportPrivateCompanies()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                string disName = Request["disCompanyName"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined" || searchText == "null")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (disName == "undefined" || disName == "null")
                { disName = ""; }
                else { disName = Request["disCompanyName"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CustomerListingRepository.ExportPrivateCompanies(searchText, tRecords, sortColumn, sortOrder, disName);
                var datatab = data.Tables[0];
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Distributor Name";
                datatab.Columns[4].ColumnName = "Postal Code";
                datatab.Columns[5].ColumnName = "Contact Person";
                datatab.Columns[7].ColumnName = "Contact No";
                
                datatab.Columns.RemoveAt(0);
                using (MemoryStream memstr = new MemoryStream())
                {
                  
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "PrivateCompanyDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "PrivateCompany";
                    bool isHeader = true;
                    string headerText = "Private Company Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }
        public ActionResult ExportGovtCompanies()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                string disName = Request["disCompanyName"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined" || searchText == "null")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (disName == "undefined" || disName == "null")
                { disName = ""; }
                else { disName = Request["disCompanyName"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _CustomerListingRepository.ExportGovtCommpanies(searchText, tRecords, sortColumn, sortOrder, disName);
                var datatab = data.Tables[0];
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Distributor Name";
                datatab.Columns[4].ColumnName = "Postal Code";
                datatab.Columns[5].ColumnName = "Contact Person";
                datatab.Columns[7].ColumnName = "Contact No";
                datatab.Columns.RemoveAt(0);
                using (MemoryStream memstr = new MemoryStream())
                {
                   
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "GovtCompanyDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "GovtCompanies";
                    bool isHeader = true;
                    string headerText = "Government Company Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

        [HttpGet]
        public int GetRoleId()
        {       
            int RoleID =Convert.ToInt32(Session["RoleID"]);

            return RoleID;
        }
    }
}