﻿using OHES.eFit.Data.Repository;
using OHES.eFit.OpenXML;
using OHES.eFit.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OHES.eFit.Data.Utility;

namespace OHES.eFit.Controllers
{
    [Authorize]
    [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
    public class StatusInquiryController : Controller
    {
        IStatusInquiryRepository _StatusInquiryRepository;
        public StatusInquiryController()
        {
            _StatusInquiryRepository = new StatusInquiryRepository();
        }
        //Get StatusInquiry List
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult TraineeListing()
        {
            return View();
        }
        public ActionResult TrainerListing()
        {
            return View();
        }
        public ActionResult ExporttraineeList()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string CompanyName = Request["CompanyName"].ToString().Trim();
                var Name = Request["Name"].ToString().Trim(); ;
                var NRIC = Request["NRIC"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string CompanyTypeID = Request["CompanyTypeID"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                int CompID = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (Name == "undefined")
                { Name = ""; }
                else { Name = Request["Name"].ToString().Trim(); }
                if (NRIC == "undefined")
                { NRIC = ""; }
                else { NRIC = Request["NRIC"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                if (CompanyTypeID == "undefined")
                { }
                else { CompID = Convert.ToInt16(Request["CompanyTypeID"].ToString().Trim()); }
                var data = _StatusInquiryRepository.ExporttraineeList(CompanyName, CompID, searchText, Name, NRIC, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Trainee Name";
                datatab.Columns[3].ColumnName = "No Of Years";
                datatab.Columns[6].ColumnName = "ID No.";
                datatab.Columns[8].ColumnName = "Contact Person";
                datatab.Columns[9].ColumnName = "Contact No";
                datatab.Columns[10].ColumnName = "Trainer Name";
                datatab.Columns[11].ColumnName = "Ref No";
                using (MemoryStream memstr = new MemoryStream())
                {
                   
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TraineeListDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "TraineeList";
                    bool isHeader = true;
                    string headerText = "Trainee List Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);
                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }

            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

        public ActionResult ExporttrainerListPC()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string CompanyName = Request["CompanyName"].ToString().Trim();
                var Name = Request["Name"].ToString().Trim(); ;
                var NRIC = Request["NRIC"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string CompanyTypeID = Request["CompanyTypeID"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                int CompID = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (Name == "undefined")
                { Name = ""; }
                else { Name = Request["Name"].ToString().Trim(); }
                if (NRIC == "undefined")
                { NRIC = ""; }
                else { NRIC = Request["NRIC"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                if (CompanyTypeID == "undefined")
                { }
                else { CompID = Convert.ToInt16(Request["CompanyTypeID"].ToString().Trim()); }
                var data = _StatusInquiryRepository.ExporttrainerListPC(CompanyName, CompID, searchText, Name, NRIC, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("TrainerPicFileId");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Trainee Name";
                datatab.Columns[3].ColumnName = "No Of Years";
                datatab.Columns[6].ColumnName = "ID No.";
                datatab.Columns[8].ColumnName = "Contact Person";
                datatab.Columns[9].ColumnName = "Contact No";
                datatab.Columns[10].ColumnName = "Trainer Name";
                datatab.Columns[11].ColumnName = "Ref No";
                using (MemoryStream memstr = new MemoryStream())
                {
                  
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TrainerListDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "TrainerList";
                    bool isHeader = true;
                    string headerText = "Trainer List Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }


        public ActionResult ExporttrainerList()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var CompanyName = Request["CompanyName"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _StatusInquiryRepository.ExporttrainerList(searchText, tRecords, CompanyName);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                datatab.Columns.Remove("TrainingDate");
                datatab.Columns.Remove("TopicsCovered");
                datatab.Columns.Remove("TrainerCompanyName");
                datatab.Columns.Remove("Email");
                datatab.Columns.Remove("TrainingTypeID");
                using (MemoryStream memstr = new MemoryStream())
                {
                   
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TrainerListDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "TrainerList";
                    bool isHeader = true;
                    string headerText = "Trainer List Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

        public ActionResult ExportAdmintrainerList()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim();
                var CompanyName = Request["CompanyName"].ToString().Trim();
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                else { TrainingDate = Request["TrainingDate"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _StatusInquiryRepository.ExportAdmintrainerList(searchText, tRecords, CompanyName, TrainingDate, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                datatab.Columns.Remove("Email");
                datatab.Columns.Remove("TrainingTypeID");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Training Type Name";
                datatab.Columns[3].ColumnName = "Topics Covered";
                datatab.Columns[4].ColumnName = "Trainer Company Name";
                datatab.Columns[5].ColumnName = "Trainer Name";
                using (MemoryStream memstr = new MemoryStream())
                {
                  
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TrainersRecord" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "TrainersRecordSummary";
                    bool isHeader = true;
                    string headerText = "Training Record Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

        public ActionResult ExportAdmintrainerSummary()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var trainingType = Request["TTID"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                var CompanyName = Request["CompanyName"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                if (trainingType == "undefined")
                { trainingType = "0"; }
                else { trainingType = Request["TTID"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                int tTID = Convert.ToInt16(trainingType);
                var data = _StatusInquiryRepository.ExportAdmintrainerSummary(CompanyName, TrainingDate, tTID, searchText, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                datatab.Columns.Remove("FileName");
                datatab.Columns.Remove("CompanyId");
                datatab.Columns.Remove("TRFDate");
                datatab.Columns.Remove("TRFDateS");
                datatab.Columns.Remove("TopicsCovered");
                datatab.Columns.Remove("TrainerCompanyID");
                datatab.Columns.Remove("CompanyTypeId");
                datatab.Columns.Remove("TrainerPicFileId");
                datatab.Columns.Remove("TotalRecords");
                datatab.Columns.Remove("TotalRecordsExp");
                datatab.Columns.Remove("TrainingTypeID");

                datatab.Columns[0].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Trainer Company Name";
                datatab.Columns[1].ColumnName = "Trainer Name";
                datatab.Columns[3].ColumnName = "Email ID";
                using (MemoryStream memstr = new MemoryStream())
                {
                 
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TrainersSummary" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "TrainersSummary";
                    bool isHeader = true;
                    string headerText = "Trainers Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);


                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }


    }
}

