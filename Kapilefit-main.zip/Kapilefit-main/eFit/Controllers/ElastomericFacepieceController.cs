﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit.Controllers
{
    [Authorize]
    public class ElastomericFacepieceController : Controller
    {
        //
        // GET: /ElastomericFacepiece/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult HalfFacepiece6000()
        {
            return View();
        }

        public ActionResult FullFacepiece6000()
        {
            return View();
        }

        public ActionResult HalfFacepiece7000()
        {
            return View();
        }

        public ActionResult FullFacepiece7000()
        {
            return View();
        }

        public ActionResult EnglishWearltright()
        {
            return View();
        }

        public ActionResult MandrinWearltright()
        {
            return View();
        }

        public ActionResult ChemicalCartridges()
        {
            return View();
        }

        public ActionResult ParticulateFilter()
        {
            return View();
        }

        public ActionResult FiltersAdapters()
        {
            return View();
        }

	}
}