﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OHES.eFit.Controllers
{
    [Authorize]
    public class MSDSController : Controller
    {
        //
        // GET: /MSDS/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult FT11()
        {
            return View();
        }
        public ActionResult FT12()
        {
            return View();
        }
        public ActionResult FT31()
        {
            return View();
        }
        public ActionResult FT32()
        {
            return View();
        }
	}
}