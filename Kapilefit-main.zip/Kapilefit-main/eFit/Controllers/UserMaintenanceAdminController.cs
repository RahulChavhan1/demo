﻿using OHES.eFit.Data.Repository;
using OHES.eFit.OpenXML;
using OHES.eFit.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OHES.eFit.Data.Utility;
using OHES.eFit.ActionFilters;
using OHES.eFit.App_Start;

namespace OHES.eFit.Controllers
{
    [Authorize]
    [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
    public class UserMaintenanceAdminController : Controller
    {
        IUserMaintenanceAdminRepository _UserMaintenanceAdminRepository;
        public UserMaintenanceAdminController()
        {
            _UserMaintenanceAdminRepository = new UserMaintenanceAdminRepository();
        }
        //
        // GET: /UserMaintenanceAdmin/
        public ActionResult Index()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1")]
        public ActionResult NewUser()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1")]
        public ActionResult NewUserList()
        {
            return View();
        }

        public ActionResult PasswordMaintenance()
        {
            return View();
        }
        public ActionResult ExportUserSummary()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                var data = _UserMaintenanceAdminRepository.ExportUserSummary(searchText, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("CompanyID");
                datatab.Columns.Remove("Password");
                datatab.Columns.Remove("RoleID");
                datatab.Columns.Remove("Locked");
                datatab.Columns.Remove("UpdatedBy");
                datatab.Columns.Remove("UpdatedDate");
                datatab.Columns[0].ColumnName = "User ID";
                datatab.Columns[1].ColumnName = "Username";
                datatab.Columns[2].ColumnName = "Email ID";
                datatab.Columns[3].ColumnName = "Company Name";
                using (MemoryStream memstr = new MemoryStream())
                {
                
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "UsersSummaryDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "UsersSummary";
                    bool isHeader = true;
                    string headerText = "Users Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;
                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

	}
}