﻿using OHES.eFit.Data.Repository;
using OHES.eFit.OpenXML;
using OHES.eFit.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OHES.eFit.Data.Utility;
using OHES.eFit.App_Start;

namespace OHES.eFit.Controllers
{
    [Authorize]
    [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
    public class DocManagerController : Controller
    {
        IDocMangerRepository _DocMangerRepository;

        public DocManagerController()
        {
            _DocMangerRepository = new DocMangerRepository();
        }

        //
        // GET: /DocManager/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult FitTestRecord()
        {
            return View();
        }

        public ActionResult PrintCertificate()
        {
            return View();
        }

        [RolesAuthorizationFilter(AllowRoles = "1,2,3,4")]
        public ActionResult TrainTrainer()
        {
            return View();
        }

        public ActionResult DownloadeFitForm()
        {
            return View();
        }


        public ActionResult ExportCertifiedActiveTrainees()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var CompanyName = Request["CompanyName"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();

                Int64 tRecords = 0;

                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }


                if (CompanyName == "undefined")
                { CompanyName = ""; }
                else { CompanyName = Request["CompanyName"].ToString().Trim(); }

                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }


                var data = _DocMangerRepository.ExportActiveTrainees(CompanyName, searchText, tRecords);
                var datatab = data.Tables[0];
                using (MemoryStream memstr = new MemoryStream())
                {                  
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "ActiveTraineeDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "ActiveTrainee";
                    bool isHeader = true;
                    string headerText = "Active Trainees Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);

                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;

                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }

            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }

        public ActionResult ExportTrainTheTrainer()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var trainingType = Request["TTID"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                var CompanyName = Request["CompanyName"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();

                Int64 tRecords = 0;

                if (searchText == "undefined")
                { searchText = ""; }
                else { searchText = Request["searchText"].ToString().Trim(); }


                if (trainingType == "undefined")
                { trainingType = "0"; }
                else { trainingType = Request["TTID"].ToString().Trim(); }

                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                int tTID = Convert.ToInt16(trainingType);
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                if (CompanyName == "undefined")
                { CompanyName = ""; }

                var data = _DocMangerRepository.ExportTrainingTrainer(tTID, CompanyName, TrainingDate, searchText, companyTypeId, tRecords, sortColumn, sortOrder);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                datatab.Columns.Remove("TopicsCovered");
                datatab.Columns.Remove("TrainingTypeID");
                datatab.Columns.Remove("TrainerPicFileId");
                datatab.Columns.Remove("Type");
                datatab.Columns.Remove("CompanyID");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Trainer Name";
                datatab.Columns[3].ColumnName = "Trainer Company Name";
                if (datatab.Columns.Contains("TrainerCompanyID"))
                datatab.Columns.Remove("TrainerCompanyID");
                using (MemoryStream memstr = new MemoryStream())
                {                    
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TrainingTrainerDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "TrainTrainer";
                    bool isHeader = true;
                    string headerText = "Train the Trainer Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);


                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;

                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }


        public ActionResult ExportTrainerFittestRecord()
        {
            try
            {
                var searchText = Request["searchText"].ToString().Trim(); ;
                var trainingType = Request["TTID"].ToString().Trim();
                string TotalRecords = Request["TotalRecords"].ToString().Trim();
                var TrainingDate = Request["TrainingDate"].ToString().Trim();
                int companyTypeId = Convert.ToInt32(Request["CompanyTypeId"].ToString().Trim());
                var CompanyName = Request["CompanyName"].ToString().Trim();
                string sortColumn = Request["sortColumn"].ToString().Trim();
                string sortOrder = Request["sortOrder"].ToString().Trim();
                Int64 tRecords = 0;
                if (searchText == "undefined")
                { searchText = ""; }
                if (trainingType == "undefined")
                { trainingType = "0"; }
                else { trainingType = Request["TTID"].ToString().Trim(); }
                if (TotalRecords == "undefined")
                { }
                else { tRecords = Convert.ToInt64(Request["TotalRecords"].ToString().Trim()); }
                if (sortColumn == "undefined" || sortColumn == "null")
                { sortColumn = ""; }
                else { sortColumn = Request["sortColumn"].ToString().Trim(); }
                if (sortOrder == "undefined" || sortOrder == "null")
                { sortOrder = ""; }
                else { sortOrder = Request["sortOrder"].ToString().Trim(); }
                if (TrainingDate == "undefined")
                { TrainingDate = ""; }
                if (CompanyName == "undefined")
                { CompanyName = ""; }
                int tTID = Convert.ToInt16(trainingType);

                var data = _DocMangerRepository.ExportTrainerFittestRecord(CompanyName, TrainingDate, tTID, searchText, companyTypeId, tRecords, sortColumn, sortOrder,User.Identity.Name);
                var datatab = data.Tables[0];
                datatab.Columns.Remove("RefNo");
                datatab.Columns.Remove("TopicsCovered");
                datatab.Columns.Remove("TrainingTypeID");
                datatab.Columns.Remove("TrainerPicFileId");
                datatab.Columns.Remove("Type");
                datatab.Columns.Remove("CompanyID");
                datatab.Columns[0].ColumnName = "Training Date";
                datatab.Columns[1].ColumnName = "Company Name";
                datatab.Columns[2].ColumnName = "Trainer Name";
                datatab.Columns[3].ColumnName = "Trainer Company Name";
                if (datatab.Columns.Contains("TrainerCompanyID"))
                datatab.Columns.Remove("TrainerCompanyID");
                using (MemoryStream memstr = new MemoryStream())
                {
                   
                    DataTable dt = new DataTable();
                    dt = datatab.Copy();
                    string fileName = "TrainerFitTestRecordDetails" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx"; ;
                    string sheetName = "TrainerFittestRecord";
                    bool isHeader = true;
                    string headerText = "Trainer Fit Test Record Summary";
                    CreateExcelFile.CreateExcelDocument(dt, memstr, sheetName, isHeader, headerText);


                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.Unicode;

                    Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                    Response.AddHeader("Content-Length", memstr.Length.ToString());
                    Response.ContentType = "application/vnd.xlsx";
                    memstr.WriteTo(Response.OutputStream);
                    Response.End();

                }
            }
            catch (Exception ex)
            {
                Utility.LogException(ex);
            }
            return View();
        }
	}
}