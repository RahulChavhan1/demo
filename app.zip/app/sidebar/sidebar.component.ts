import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  constructor() { }
  items : any
  contentshow=false;

  display(){
    if(!this.contentshow){
      this.contentshow=true;
    }else{
      this.contentshow=false;
    }
  }

  ngOnInit() {
    this.items = [
      {
        label: 'Navigation Panel',
      },
      {
        label: 'General',
        items: [
          {
            icon: 'pi pi-chevron-right',
            label: 'Services & Programs',
          },
        ],
      },
      {
        label: '3M Fit Testing Devices',
        items: [
          {
            icon: 'pi pi-chevron-right',
            label: '3M Fit Testing Devices',
          },
        ],
      },
      {
        label: 'MSDS',
        items: [
          {
            icon: 'pi pi-chevron-right',
            label: 'FT - 11',
          },
          {
            icon: 'pi pi-chevron-right',
            label: 'FT - 12',
          },
          {
            icon: 'pi pi-chevron-right',
            label: 'FT - 31',
          },
          {
            icon: 'pi pi-chevron-right',
            label: 'FT - 32',
          },
        ],
      },
      {
        icon: 'pi pi-chevron-right',
        label: 'Regulation & Standards',
      },
      {
        label: 'Other Resources',
        items: [
          {
            icon: 'pi pi-chevron-right',
            label: 'Respiratory Selection Guide',
          },
        ],
      },
    ];
  }
}
